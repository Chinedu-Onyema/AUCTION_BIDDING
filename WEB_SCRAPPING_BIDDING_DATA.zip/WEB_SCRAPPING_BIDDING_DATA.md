# DATA EXTRACTION / MINNING / SCRAPING WITH BEAUTIFUL SOUP


```python
# To be begin data extraction i imported the beautiful soup & request library  
from bs4 import BeautifulSoup
import requests
```


```python
# pasted the URL of the webpage i want to extract
url = 'https://auction.nigeriatradehub.gov.ng/previous_auction.php'
page = requests.get(url)
soup = BeautifulSoup(page.text, 'html.parser')
```


```python
print(soup)
```

    <script>document.addEventListener("contextmenu", function(e) {    e.preventDefault();});</script><!DOCTYPE html>
    
    <html lang="en">
    <head>
    <title>Previous Auction</title>
    <meta charset="utf-8"/>
    <meta content="IE=edge" http-equiv="X-UA-Compatible"/>
    <meta content="eAuction" name="description"/>
    <meta content="width=device-width, initial-scale=1" name="viewport"/>
    <!-- Jquery Toast css -->
    <link href="assets/libs/jquery-toast-plugin/jquery.toast.min.css" rel="stylesheet" type="text/css"/>
    <!-- SweetAlert2 -->
    <link href="assets/sweetalert2-theme-bootstrap-4/bootstrap-4.min.css" rel="stylesheet"/>
    <!-- Toastr -->
    <link href="assets/toastr/toastr.min.css" rel="stylesheet"/>
    <link href="styles/bootstrap4/bootstrap.min.css" rel="stylesheet" type="text/css"/>
    <link href="plugins/font-awesome-4.7.0/css/font-awesome.min.css" rel="stylesheet" type="text/css"/>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" rel="stylesheet"/>
    <link href="plugins/OwlCarousel2-2.2.1/owl.carousel.css" rel="stylesheet" type="text/css"/>
    <link href="plugins/OwlCarousel2-2.2.1/owl.theme.default.css" rel="stylesheet" type="text/css"/>
    <link href="plugins/OwlCarousel2-2.2.1/animate.css" rel="stylesheet" type="text/css"/>
    <link href="plugins/video-js/video-js.css" rel="stylesheet" type="text/css"/>
    <link href="styles/main_styles.css" rel="stylesheet" type="text/css"/>
    <link href="styles/responsive.css" rel="stylesheet" type="text/css"/>
    <style type="text/css">
    	* {
    
        font-family:"Ruluko";
    
    }
    main{
        background: #447878 !important;
        text-align: center;
        padding: 150px 20px !important;
    }
    h3 {
        margin: 20px;
        color:white;
    }
    
    .days {
        padding:6px;
        background-color:#747c2a;
        border-radius: 25% 10%;
        display:inline-block;
        color: #f99548;
        font-size:14px;
        margin: 2px;
        text-shadow: 0px 0px 2px #222;
        font-weight: bold;
        text-align: center;
    }
    
    .hours {
        padding:6px;
        background-color:#747c2a;
        border-radius: 25% 10%;
        display:inline-block;
        color: #f99548;
        font-size:14px;
        margin: 2px;
        text-shadow: 0px 0px 2px #222;
        font-weight: bold;
        text-align: center;
    }
    
    .minutes {
        padding:6px;
        background-color:#747c2a;
        border-radius: 25% 10%;
        display:inline-block;
        color: #f99548;
        font-size:14px;
        margin: 2px;
        text-shadow: 0px 0px 2px #222;
        font-weight: bold;
        text-align: center;
    }
    
    .seconds {
        padding:6px;
        background-color:#747c2a;
        border-radius: 25% 10%;
        display:inline-block;
        color: #f99548;
        font-size:14px;
        margin: 2px;
        text-shadow: 0px 0px 2px #222;
        font-weight: bold;
        text-align: center;
    }
    
    
    .smallText{
        font-weight:400;
    	padding-top: 5px;
    	font-size: 16px;
    }
    
    .bg-secondary{
    	background-color: #dee2d4!important;
    }
    </style>
    </head>
    <body>
    <!-- onload="$('#modalTriggerBtn').click();" -->
    <div class="super_container">
    <!-- Header -->
    <header class="header">
    <!-- Top Bar -->
    <div class="top_bar">
    <div class="top_bar_container">
    <div class="container">
    <div class="row">
    <div class="col">
    <div class="top_bar_content d-flex flex-row align-items-center justify-content-start">
    <ul class="top_bar_contact_list">
    <li class="text-white">
    <!--<div class="question">Is your TIN validated?</div>-->
    <a href="https://apps.firs.gov.ng/tinverification/" style="color: white;">Click here to know if your TIN is Validated</a>
    </li>
    <li>
    <div>07037891156</div>
    </li>
    <li>
    <div>pro@customs.gov.ng</div>
    </li>
    <li>
    <div>pro2@customs.gov.ng</div>
    </li>
    <li>
    <div>info@customs.gov.ng</div>
    </li>
    </ul>
    <div class="top_bar_login ml-auto">
    <ul>
    <li><a href="signup.php">Register</a></li>
    <li><a href="login.php">Login</a></li>
    </ul>
    </div>
    </div>
    </div>
    </div>
    </div>
    </div>
    </div>
    <!-- Header Content -->
    <div class="header_container">
    <div class="container">
    <div class="row">
    <div class="col">
    <div class="header_content d-flex flex-row align-items-center justify-content-start">
    <div class="logo_container">
    <a href="#">
    <div class="logo_content d-flex flex-row align-items-end justify-content-start">
    <div class="logo_img"><img alt="" height="80px" src="images/logo-customs.png" width="100px"/></div>
    <div class="logo_text"></div>
    </div>
    </a>
    </div>
    <nav class="main_nav_contaner ml-auto">
    <ul class="main_nav">
    <li class=""><a href="index.php">Home</a></li>
    <li class=""><a href="current_auction.php">Current Auctions</a></li>
    <li class="active"><a href="previous_auction.php">Previous Auctions</a></li>
    <li class=""><a href="future_auction.php">Future Auctions</a></li>
    <li><a data-target="#exampleModalLong" data-toggle="modal" href="#">Terms and Conditions</a></li>
    <!-- <li><a href="contact.html">contact</a></li> -->
    </ul>
    <!-- <div class="search_button"><i class="fa fa-search" aria-hidden="true"></i></div> -->
    <!-- Hamburger -->
    <div class="hamburger menu_mm">
    <i aria-hidden="true" class="fa fa-bars menu_mm"></i>
    </div>
    </nav>
    </div>
    </div>
    </div>
    </div>
    </div>
    <!-- Header Search Panel -->
    <!--<div class="header_search_container">-->
    <!--	<div class="container">-->
    <!--		<div class="row">-->
    <!--			<div class="col">-->
    <!--				<div class="header_search_content d-flex flex-row align-items-center justify-content-end">-->
    <!--					<form action="#" class="header_search_form">-->
    <!--						<input type="search" class="search_input" placeholder="Search" required="required">-->
    <!--						<button class="header_search_button d-flex flex-column align-items-center justify-content-center">-->
    <!--							<i class="fa fa-search" aria-hidden="true"></i>-->
    <!--						</button>-->
    <!--					</form>-->
    <!--				</div>-->
    <!--			</div>-->
    <!--		</div>-->
    <!--	</div>			-->
    <!--</div>			-->
    </header>
    <!-- Menu -->
    <div class="menu d-flex flex-column align-items-end justify-content-start text-right menu_mm trans_400">
    <div class="menu_close_container"><div class="menu_close"><div></div><div></div></div></div>
    <!--<div class="search">-->
    <!--	<form action="#" class="header_search_form menu_mm">-->
    <!--		<input type="search" class="search_input menu_mm" placeholder="Search" required="required">-->
    <!--		<button class="header_search_button d-flex flex-column align-items-center justify-content-center menu_mm">-->
    <!--			<i class="fa fa-search menu_mm" aria-hidden="true"></i>-->
    <!--		</button>-->
    <!--	</form>-->
    <!--</div>-->
    <nav class="menu_nav">
    <ul class="menu_mm">
    <!-- <li class="menu_mm"><a href="index.php">Home</a></li>
    				<li class="menu_mm"><a href="current_auction.php">Current Auction</a></li>
    				<li class="menu_mm"><a href="previous_auction.php">Previous Auction</a></li>
    				<li class="menu_mm"><a href="#">Future Auction</a></li>
    				<li class="menu_mm"><a href="#">Terms and Condition</a></li> -->
    <li class="menu_mm"><a href="index.php">Home</a></li>
    <li class="menu_mm"><a href="current_auction.php">Current Auctions</a></li>
    <li class="menu_mm active"><a href="previous_auction.php">Previous Auctions</a></li>
    <li class="menu_mm"><a href="future_auction.php">Future Auctions</a></li>
    <li class="menu_mm"><a data-target="#exampleModalLong" data-toggle="modal" href="#">Terms and Conditions</a></li>
    <ul>
    <li><a href="signup.php">Register</a></li>
    <li><a href="login.php">Login</a></li>
    </ul>
    </ul>
    </nav>
    <div class="menu_extra">
    <div class="menu_phone"><span class="menu_title">phone:</span>07037891156</div>
    <div class="menu_social">
    <span class="menu_title">follow us</span>
    <ul>
    <li><a href="#"><i aria-hidden="true" class="fa fa-pinterest"></i></a></li>
    <li><a href="#"><i aria-hidden="true" class="fa fa-facebook"></i></a></li>
    <li><a href="#"><i aria-hidden="true" class="fa fa-instagram"></i></a></li>
    <li><a href="#"><i aria-hidden="true" class="fa fa-twitter"></i></a></li>
    </ul>
    </div>
    </div>
    </div>
    <script>
                    // location.href = 'https://auction.nigeriatradehub.gov.ng/index.php';
                </script>
    <!-- Home -->
    <div class="home" style="height:260px;">
    <div class="home_slider_container">
    <!-- Home Slider -->
    <div class="owl-carousel owl-theme home_slider">
    <!-- Slider Item -->
    <div class="owl-item">
    <!-- Background image artist https://unsplash.com/@benwhitephotography -->
    <div class="home_slider_background" style="background-image:url(images/banner1.jpg)">
    <div style="background-image: linear-gradient(to right, rgba(023,111,0,.7), rgba(122,0,0,.5)); height:100%; width:100%;">
    </div>
    </div>
    <div class="home_container">
    <div class="container">
    <div class="row">
    <div class="col">
    <div class="home_content text-center">
    <div class="home_log home_logo_text" style="margin-top:80px;">
    <span class="e" style="font-size:60px;">Previous</span><span class="auction" style="font-size:60px;"> Auctions</span>
    </div>
    <div class="home_buttons">
    </div>
    </div>
    </div>
    </div>
    </div>
    </div>
    </div>
    </div>
    </div>
    </div>
    <div class="courses pb-0">
    <div class="container-fluid">
    <div class="row">
    <div class="col-lg-10 offset-lg-1">
    <div class="section_title text-center">
    <div class="text-center d-flex justify-content-center">
    										No Ongoing Auction
    
    									</div>
    </div>
    </div>
    </div>
    </div>
    </div>
    <div class="courses">
    <div class="container-fluid px-5">
    <div class="row mt-1 mx-1">
    <div class="card col-md-3 my-3">
    <img alt="Front View" class="card-img-top" height="220px;" src="vehicleImage/toyota camry 2006.jpg"/>
    <div class="card-body p-0">
    <div class="course_header d-flex flex-row align-items-center justify-content-start small">
    <div class="course_tag">
    <a href="previous_vehicle_details.php?refNo=1&amp;itemType=Vehicle">NCS/PTML/OVT/01/24/1</a>
    </div>
    <div class="course_price ml-auto">
    								Price 
    								<span> ₦892,000.00</span><br/>
    </div>
    </div>
    <h5 class="card-title">
    					        
    					        TOYOTA CAMRY HYBRID LE 4DR SEDAN 2006					    </h5>
    <p class="card-text small">
    <i class="fa fa-star-half-alt"></i> 
    							Used <br/>
    <i class="fa fa-dumbbell"></i> 
    							4T1BE32K86U111063							<!--<i class="fa fa-map-marker-alt"></i> -->
    </p>
    <div class="course_footer d-flex align-items-center justify-content-start small">
    <a class="d-inline-block col text-dark" data-bs-toggle="tooltip" data-original-title="Transmission" data-placement="bottom" href="javascript:void(0);">
    <i class="fa fa-car"></i>
    <span class="">Automatic</span>
    </a>
    <a class="d-inline-block col text-dark" data-bs-toggle="tooltip" data-original-title="Millage" data-placement="bottom" href="javascript:void(0);">
    <i class="fa fa-road"></i> <span class="">0.00KM</span></a>
    <a class="d-inline-block col text-dark" data-bs-toggle="tooltip" data-original-title="FuelType" data-placement="bottom" href="javascript:void(0);">
    <i class="fa fa-solid fa-gas-pump"></i> <span class="">Petrol</span></a>
    </div>
    </div>
    </div>
    <div class="card col-md-3 my-3">
    <img alt="Front View" class="card-img-top" height="220px;" src="vehicleImage/akura 2004.jpg"/>
    <div class="card-body p-0">
    <div class="course_header d-flex flex-row align-items-center justify-content-start small">
    <div class="course_tag">
    <a href="previous_vehicle_details.php?refNo=2&amp;itemType=Vehicle">NCS/PTML/OVT/01/24/2</a>
    </div>
    <div class="course_price ml-auto">
    								Price 
    								<span> ₦500,000.00</span><br/>
    </div>
    </div>
    <h5 class="card-title">
    					        
    					        ACURA TL 2004					    </h5>
    <p class="card-text small">
    <i class="fa fa-star-half-alt"></i> 
    							Used <br/>
    <i class="fa fa-dumbbell"></i> 
    							19UUA66214A013030							<!--<i class="fa fa-map-marker-alt"></i> -->
    </p>
    <div class="course_footer d-flex align-items-center justify-content-start small">
    <a class="d-inline-block col text-dark" data-bs-toggle="tooltip" data-original-title="Transmission" data-placement="bottom" href="javascript:void(0);">
    <i class="fa fa-car"></i>
    <span class="">Automatic</span>
    </a>
    <a class="d-inline-block col text-dark" data-bs-toggle="tooltip" data-original-title="Millage" data-placement="bottom" href="javascript:void(0);">
    <i class="fa fa-road"></i> <span class="">0.00KM</span></a>
    <a class="d-inline-block col text-dark" data-bs-toggle="tooltip" data-original-title="FuelType" data-placement="bottom" href="javascript:void(0);">
    <i class="fa fa-solid fa-gas-pump"></i> <span class="">Petrol</span></a>
    </div>
    </div>
    </div>
    <div class="card col-md-3 my-3">
    <img alt="Front View" class="card-img-top" height="220px;" src="vehicleImage/Honda 2004.jpg"/>
    <div class="card-body p-0">
    <div class="course_header d-flex flex-row align-items-center justify-content-start small">
    <div class="course_tag">
    <a href="previous_vehicle_details.php?refNo=3&amp;itemType=Vehicle">NCS/PTML/OVT/01/24/3</a>
    </div>
    <div class="course_price ml-auto">
    								Price 
    								<span> ₦420,000.00</span><br/>
    </div>
    </div>
    <h5 class="card-title">
    					        
    					        HONDA ACCORD EX 1.5T 4DR SEDAN 2004					    </h5>
    <p class="card-text small">
    <i class="fa fa-star-half-alt"></i> 
    							Used <br/>
    <i class="fa fa-dumbbell"></i> 
    							1HGCM66554A098192							<!--<i class="fa fa-map-marker-alt"></i> -->
    </p>
    <div class="course_footer d-flex align-items-center justify-content-start small">
    <a class="d-inline-block col text-dark" data-bs-toggle="tooltip" data-original-title="Transmission" data-placement="bottom" href="javascript:void(0);">
    <i class="fa fa-car"></i>
    <span class="">Automatic</span>
    </a>
    <a class="d-inline-block col text-dark" data-bs-toggle="tooltip" data-original-title="Millage" data-placement="bottom" href="javascript:void(0);">
    <i class="fa fa-road"></i> <span class="">0.00KM</span></a>
    <a class="d-inline-block col text-dark" data-bs-toggle="tooltip" data-original-title="FuelType" data-placement="bottom" href="javascript:void(0);">
    <i class="fa fa-solid fa-gas-pump"></i> <span class="">Petrol</span></a>
    </div>
    </div>
    </div>
    <div class="card col-md-3 my-3">
    <img alt="Front View" class="card-img-top" height="220px;" src="vehicleImage/1 (1).jpg"/>
    <div class="card-body p-0">
    <div class="course_header d-flex flex-row align-items-center justify-content-start small">
    <div class="course_tag">
    <a href="previous_vehicle_details.php?refNo=4&amp;itemType=Vehicle">NCS/PTML/OVT/01/24/4</a>
    </div>
    <div class="course_price ml-auto">
    								Price 
    								<span> ₦800,000.00</span><br/>
    </div>
    </div>
    <h5 class="card-title">
    					        
    					        TOYOTA COROLLA L 4DR SEDAN 2007					    </h5>
    <p class="card-text small">
    <i class="fa fa-star-half-alt"></i> 
    							Used <br/>
    <i class="fa fa-dumbbell"></i> 
    							2T1BR32E27C777272							<!--<i class="fa fa-map-marker-alt"></i> -->
    </p>
    <div class="course_footer d-flex align-items-center justify-content-start small">
    <a class="d-inline-block col text-dark" data-bs-toggle="tooltip" data-original-title="Transmission" data-placement="bottom" href="javascript:void(0);">
    <i class="fa fa-car"></i>
    <span class="">Automatic</span>
    </a>
    <a class="d-inline-block col text-dark" data-bs-toggle="tooltip" data-original-title="Millage" data-placement="bottom" href="javascript:void(0);">
    <i class="fa fa-road"></i> <span class="">0.00KM</span></a>
    <a class="d-inline-block col text-dark" data-bs-toggle="tooltip" data-original-title="FuelType" data-placement="bottom" href="javascript:void(0);">
    <i class="fa fa-solid fa-gas-pump"></i> <span class="">Petrol</span></a>
    </div>
    </div>
    </div>
    <div class="card col-md-3 my-3">
    <img alt="Front View" class="card-img-top" height="220px;" src="vehicleImage/1 (2).jpg"/>
    <div class="card-body p-0">
    <div class="course_header d-flex flex-row align-items-center justify-content-start small">
    <div class="course_tag">
    <a href="previous_vehicle_details.php?refNo=5&amp;itemType=Vehicle">NCS/PTML/OVT/01/24/5</a>
    </div>
    <div class="course_price ml-auto">
    								Price 
    								<span> ₦715,000.00</span><br/>
    </div>
    </div>
    <h5 class="card-title">
    					        
    					        PEUGEOT 307 2008					    </h5>
    <p class="card-text small">
    <i class="fa fa-star-half-alt"></i> 
    							Used <br/>
    <i class="fa fa-dumbbell"></i> 
    							VF33CNFUL84568049							<!--<i class="fa fa-map-marker-alt"></i> -->
    </p>
    <div class="course_footer d-flex align-items-center justify-content-start small">
    <a class="d-inline-block col text-dark" data-bs-toggle="tooltip" data-original-title="Transmission" data-placement="bottom" href="javascript:void(0);">
    <i class="fa fa-car"></i>
    <span class="">Automatic</span>
    </a>
    <a class="d-inline-block col text-dark" data-bs-toggle="tooltip" data-original-title="Millage" data-placement="bottom" href="javascript:void(0);">
    <i class="fa fa-road"></i> <span class="">0.00KM</span></a>
    <a class="d-inline-block col text-dark" data-bs-toggle="tooltip" data-original-title="FuelType" data-placement="bottom" href="javascript:void(0);">
    <i class="fa fa-solid fa-gas-pump"></i> <span class="">Petrol</span></a>
    </div>
    </div>
    </div>
    <div class="card col-md-3 my-3">
    <img alt="Front View" class="card-img-top" height="220px;" src="vehicleImage/1 (3).jpg"/>
    <div class="card-body p-0">
    <div class="course_header d-flex flex-row align-items-center justify-content-start small">
    <div class="course_tag">
    <a href="previous_vehicle_details.php?refNo=6&amp;itemType=Vehicle">NCS/PTML/OVT/01/24/6</a>
    </div>
    <div class="course_price ml-auto">
    								Price 
    								<span> ₦410,000.00</span><br/>
    </div>
    </div>
    <h5 class="card-title">
    					        
    					        VOLKSWAGEN POLO 70 TSI TRENDLINE 2001					    </h5>
    <p class="card-text small">
    <i class="fa fa-star-half-alt"></i> 
    							Used <br/>
    <i class="fa fa-dumbbell"></i> 
    							WVWZZZ6NZ1Y237873							<!--<i class="fa fa-map-marker-alt"></i> -->
    </p>
    <div class="course_footer d-flex align-items-center justify-content-start small">
    <a class="d-inline-block col text-dark" data-bs-toggle="tooltip" data-original-title="Transmission" data-placement="bottom" href="javascript:void(0);">
    <i class="fa fa-car"></i>
    <span class="">Automatic</span>
    </a>
    <a class="d-inline-block col text-dark" data-bs-toggle="tooltip" data-original-title="Millage" data-placement="bottom" href="javascript:void(0);">
    <i class="fa fa-road"></i> <span class="">0.00KM</span></a>
    <a class="d-inline-block col text-dark" data-bs-toggle="tooltip" data-original-title="FuelType" data-placement="bottom" href="javascript:void(0);">
    <i class="fa fa-solid fa-gas-pump"></i> <span class="">Petrol</span></a>
    </div>
    </div>
    </div>
    <div class="card col-md-3 my-3">
    <img alt="Front View" class="card-img-top" height="220px;" src="vehicleImage/1 (4).jpg"/>
    <div class="card-body p-0">
    <div class="course_header d-flex flex-row align-items-center justify-content-start small">
    <div class="course_tag">
    <a href="previous_vehicle_details.php?refNo=7&amp;itemType=Vehicle">NCS/PTML/OVT/01/24/7</a>
    </div>
    <div class="course_price ml-auto">
    								Price 
    								<span> ₦467,000.00</span><br/>
    </div>
    </div>
    <h5 class="card-title">
    					        
    					        BMW 330I 4DR REAR-WHEEL DRIVE SEDAN 2011					    </h5>
    <p class="card-text small">
    <i class="fa fa-star-half-alt"></i> 
    							Used <br/>
    <i class="fa fa-dumbbell"></i> 
    							WBAKF9C59BE262301							<!--<i class="fa fa-map-marker-alt"></i> -->
    </p>
    <div class="course_footer d-flex align-items-center justify-content-start small">
    <a class="d-inline-block col text-dark" data-bs-toggle="tooltip" data-original-title="Transmission" data-placement="bottom" href="javascript:void(0);">
    <i class="fa fa-car"></i>
    <span class="">Automatic</span>
    </a>
    <a class="d-inline-block col text-dark" data-bs-toggle="tooltip" data-original-title="Millage" data-placement="bottom" href="javascript:void(0);">
    <i class="fa fa-road"></i> <span class="">0.00KM</span></a>
    <a class="d-inline-block col text-dark" data-bs-toggle="tooltip" data-original-title="FuelType" data-placement="bottom" href="javascript:void(0);">
    <i class="fa fa-solid fa-gas-pump"></i> <span class="">Petrol</span></a>
    </div>
    </div>
    </div>
    <div class="card col-md-3 my-3">
    <img alt="Front View" class="card-img-top" height="220px;" src="vehicleImage/1 (5).jpg"/>
    <div class="card-body p-0">
    <div class="course_header d-flex flex-row align-items-center justify-content-start small">
    <div class="course_tag">
    <a href="previous_vehicle_details.php?refNo=8&amp;itemType=Vehicle">NCS/PTML/OVT/01/24/8</a>
    </div>
    <div class="course_price ml-auto">
    								Price 
    								<span> ₦531,001.00</span><br/>
    </div>
    </div>
    <h5 class="card-title">
    					        
    					        MAZDA PREMACY 2003					    </h5>
    <p class="card-text small">
    <i class="fa fa-star-half-alt"></i> 
    							Used <br/>
    <i class="fa fa-dumbbell"></i> 
    							JMZCP19F231338331							<!--<i class="fa fa-map-marker-alt"></i> -->
    </p>
    <div class="course_footer d-flex align-items-center justify-content-start small">
    <a class="d-inline-block col text-dark" data-bs-toggle="tooltip" data-original-title="Transmission" data-placement="bottom" href="javascript:void(0);">
    <i class="fa fa-car"></i>
    <span class="">Manual</span>
    </a>
    <a class="d-inline-block col text-dark" data-bs-toggle="tooltip" data-original-title="Millage" data-placement="bottom" href="javascript:void(0);">
    <i class="fa fa-road"></i> <span class="">0.00KM</span></a>
    <a class="d-inline-block col text-dark" data-bs-toggle="tooltip" data-original-title="FuelType" data-placement="bottom" href="javascript:void(0);">
    <i class="fa fa-solid fa-gas-pump"></i> <span class="">Petrol</span></a>
    </div>
    </div>
    </div>
    <div class="card col-md-3 my-3">
    <img alt="Front View" class="card-img-top" height="220px;" src="vehicleImage/1 (8).jpg"/>
    <div class="card-body p-0">
    <div class="course_header d-flex flex-row align-items-center justify-content-start small">
    <div class="course_tag">
    <a href="previous_vehicle_details.php?refNo=11&amp;itemType=Vehicle">NCS/PTML/OVT/01/24/11</a>
    </div>
    <div class="course_price ml-auto">
    								Price 
    								<span> ₦2,100,000.00</span><br/>
    </div>
    </div>
    <h5 class="card-title">
    					        
    					        HONDA ACCORD EX 4DR SEDAN 2014					    </h5>
    <p class="card-text small">
    <i class="fa fa-star-half-alt"></i> 
    							Used <br/>
    <i class="fa fa-dumbbell"></i> 
    							1HGCR3F82EA037331							<!--<i class="fa fa-map-marker-alt"></i> -->
    </p>
    <div class="course_footer d-flex align-items-center justify-content-start small">
    <a class="d-inline-block col text-dark" data-bs-toggle="tooltip" data-original-title="Transmission" data-placement="bottom" href="javascript:void(0);">
    <i class="fa fa-car"></i>
    <span class="">Automatic</span>
    </a>
    <a class="d-inline-block col text-dark" data-bs-toggle="tooltip" data-original-title="Millage" data-placement="bottom" href="javascript:void(0);">
    <i class="fa fa-road"></i> <span class="">0.00KM</span></a>
    <a class="d-inline-block col text-dark" data-bs-toggle="tooltip" data-original-title="FuelType" data-placement="bottom" href="javascript:void(0);">
    <i class="fa fa-solid fa-gas-pump"></i> <span class="">Petrol</span></a>
    </div>
    </div>
    </div>
    <div class="card col-md-3 my-3">
    <img alt="Front View" class="card-img-top" height="220px;" src="vehicleImage/PTML 576.jpg"/>
    <div class="card-body p-0">
    <div class="course_header d-flex flex-row align-items-center justify-content-start small">
    <div class="course_tag">
    <a href="previous_vehicle_details.php?refNo=12&amp;itemType=Vehicle">NCS/PTML/OVT/01/24/12</a>
    </div>
    <div class="course_price ml-auto">
    								Price 
    								<span> ₦651,000.00</span><br/>
    </div>
    </div>
    <h5 class="card-title">
    					        
    					        HONDA ACCORD EX 1.5T 4DR SEDAN 2006					    </h5>
    <p class="card-text small">
    <i class="fa fa-star-half-alt"></i> 
    							Used <br/>
    <i class="fa fa-dumbbell"></i> 
    							1HGCM56856A178616							<!--<i class="fa fa-map-marker-alt"></i> -->
    </p>
    <div class="course_footer d-flex align-items-center justify-content-start small">
    <a class="d-inline-block col text-dark" data-bs-toggle="tooltip" data-original-title="Transmission" data-placement="bottom" href="javascript:void(0);">
    <i class="fa fa-car"></i>
    <span class="">Automatic</span>
    </a>
    <a class="d-inline-block col text-dark" data-bs-toggle="tooltip" data-original-title="Millage" data-placement="bottom" href="javascript:void(0);">
    <i class="fa fa-road"></i> <span class="">0.00KM</span></a>
    <a class="d-inline-block col text-dark" data-bs-toggle="tooltip" data-original-title="FuelType" data-placement="bottom" href="javascript:void(0);">
    <i class="fa fa-solid fa-gas-pump"></i> <span class="">Petrol</span></a>
    </div>
    </div>
    </div>
    <div class="card col-md-3 my-3">
    <img alt="Front View" class="card-img-top" height="220px;" src="vehicleImage/IMG-20240115-WA0021.jpg"/>
    <div class="card-body p-0">
    <div class="course_header d-flex flex-row align-items-center justify-content-start small">
    <div class="course_tag">
    <a href="previous_vehicle_details.php?refNo=13&amp;itemType=Vehicle">NCS/PTML/OVT/01/24/13</a>
    </div>
    <div class="course_price ml-auto">
    								Price 
    								<span> ₦400,900.00</span><br/>
    </div>
    </div>
    <h5 class="card-title">
    					        
    					        HONDA CIVIC EX 4DR SEDAN 2004					    </h5>
    <p class="card-text small">
    <i class="fa fa-star-half-alt"></i> 
    							Used <br/>
    <i class="fa fa-dumbbell"></i> 
    							1HGEM219X4L011483							<!--<i class="fa fa-map-marker-alt"></i> -->
    </p>
    <div class="course_footer d-flex align-items-center justify-content-start small">
    <a class="d-inline-block col text-dark" data-bs-toggle="tooltip" data-original-title="Transmission" data-placement="bottom" href="javascript:void(0);">
    <i class="fa fa-car"></i>
    <span class="">Automatic</span>
    </a>
    <a class="d-inline-block col text-dark" data-bs-toggle="tooltip" data-original-title="Millage" data-placement="bottom" href="javascript:void(0);">
    <i class="fa fa-road"></i> <span class="">0.00KM</span></a>
    <a class="d-inline-block col text-dark" data-bs-toggle="tooltip" data-original-title="FuelType" data-placement="bottom" href="javascript:void(0);">
    <i class="fa fa-solid fa-gas-pump"></i> <span class="">Petrol</span></a>
    </div>
    </div>
    </div>
    <div class="card col-md-3 my-3">
    <img alt="Front View" class="card-img-top" height="220px;" src="vehicleImage/PTML 574.jpg"/>
    <div class="card-body p-0">
    <div class="course_header d-flex flex-row align-items-center justify-content-start small">
    <div class="course_tag">
    <a href="previous_vehicle_details.php?refNo=14&amp;itemType=Vehicle">NCS/PTML/OVT/01/24/14</a>
    </div>
    <div class="course_price ml-auto">
    								Price 
    								<span> ₦2,750,000.00</span><br/>
    </div>
    </div>
    <h5 class="card-title">
    					        
    					        LEXUS GS 300 BASE 4DR REAR-WHEEL DRIVE SEDAN 2006					    </h5>
    <p class="card-text small">
    <i class="fa fa-star-half-alt"></i> 
    							Used <br/>
    <i class="fa fa-dumbbell"></i> 
    							JTHCH96S360012332							<!--<i class="fa fa-map-marker-alt"></i> -->
    </p>
    <div class="course_footer d-flex align-items-center justify-content-start small">
    <a class="d-inline-block col text-dark" data-bs-toggle="tooltip" data-original-title="Transmission" data-placement="bottom" href="javascript:void(0);">
    <i class="fa fa-car"></i>
    <span class="">Automatic</span>
    </a>
    <a class="d-inline-block col text-dark" data-bs-toggle="tooltip" data-original-title="Millage" data-placement="bottom" href="javascript:void(0);">
    <i class="fa fa-road"></i> <span class="">0.00KM</span></a>
    <a class="d-inline-block col text-dark" data-bs-toggle="tooltip" data-original-title="FuelType" data-placement="bottom" href="javascript:void(0);">
    <i class="fa fa-solid fa-gas-pump"></i> <span class="">Petrol</span></a>
    </div>
    </div>
    </div>
    <div class="card col-md-3 my-3">
    <img alt="Front View" class="card-img-top" height="220px;" src="vehicleImage/PTML 573.jpg"/>
    <div class="card-body p-0">
    <div class="course_header d-flex flex-row align-items-center justify-content-start small">
    <div class="course_tag">
    <a href="previous_vehicle_details.php?refNo=15&amp;itemType=Vehicle">NCS/PTML/OVT/01/24/15</a>
    </div>
    <div class="course_price ml-auto">
    								Price 
    								<span> ₦610,000.00</span><br/>
    </div>
    </div>
    <h5 class="card-title">
    					        
    					        BMW 325XI 2006					    </h5>
    <p class="card-text small">
    <i class="fa fa-star-half-alt"></i> 
    							Used <br/>
    <i class="fa fa-dumbbell"></i> 
    							WBAVD13556KV06571							<!--<i class="fa fa-map-marker-alt"></i> -->
    </p>
    <div class="course_footer d-flex align-items-center justify-content-start small">
    <a class="d-inline-block col text-dark" data-bs-toggle="tooltip" data-original-title="Transmission" data-placement="bottom" href="javascript:void(0);">
    <i class="fa fa-car"></i>
    <span class="">Automatic</span>
    </a>
    <a class="d-inline-block col text-dark" data-bs-toggle="tooltip" data-original-title="Millage" data-placement="bottom" href="javascript:void(0);">
    <i class="fa fa-road"></i> <span class="">0.00KM</span></a>
    <a class="d-inline-block col text-dark" data-bs-toggle="tooltip" data-original-title="FuelType" data-placement="bottom" href="javascript:void(0);">
    <i class="fa fa-solid fa-gas-pump"></i> <span class="">Petrol</span></a>
    </div>
    </div>
    </div>
    <div class="card col-md-3 my-3">
    <img alt="Front View" class="card-img-top" height="220px;" src="vehicleImage/PTML 570.jpg"/>
    <div class="card-body p-0">
    <div class="course_header d-flex flex-row align-items-center justify-content-start small">
    <div class="course_tag">
    <a href="previous_vehicle_details.php?refNo=17&amp;itemType=Vehicle">NCS/PH I/OVT/01/24/17</a>
    </div>
    <div class="course_price ml-auto">
    								Price 
    								<span> ₦405,500.00</span><br/>
    </div>
    </div>
    <h5 class="card-title">
    					        
    					        VOLVO S80 2010					    </h5>
    <p class="card-text small">
    <i class="fa fa-star-half-alt"></i> 
    							Used <br/>
    <i class="fa fa-dumbbell"></i> 
    							YV1960AS9A1116244							<!--<i class="fa fa-map-marker-alt"></i> -->
    </p>
    <div class="course_footer d-flex align-items-center justify-content-start small">
    <a class="d-inline-block col text-dark" data-bs-toggle="tooltip" data-original-title="Transmission" data-placement="bottom" href="javascript:void(0);">
    <i class="fa fa-car"></i>
    <span class="">Automatic</span>
    </a>
    <a class="d-inline-block col text-dark" data-bs-toggle="tooltip" data-original-title="Millage" data-placement="bottom" href="javascript:void(0);">
    <i class="fa fa-road"></i> <span class="">0.00KM</span></a>
    <a class="d-inline-block col text-dark" data-bs-toggle="tooltip" data-original-title="FuelType" data-placement="bottom" href="javascript:void(0);">
    <i class="fa fa-solid fa-gas-pump"></i> <span class="">Petrol</span></a>
    </div>
    </div>
    </div>
    <div class="card col-md-3 my-3">
    <img alt="Front View" class="card-img-top" height="220px;" src="vehicleImage/PTML 569.jpg"/>
    <div class="card-body p-0">
    <div class="course_header d-flex flex-row align-items-center justify-content-start small">
    <div class="course_tag">
    <a href="previous_vehicle_details.php?refNo=18&amp;itemType=Vehicle">NCS/PTML/OVT/01/24/18</a>
    </div>
    <div class="course_price ml-auto">
    								Price 
    								<span> ₦550,000.00</span><br/>
    </div>
    </div>
    <h5 class="card-title">
    					        
    					        MERCEDES-BENZ C240 2005					    </h5>
    <p class="card-text small">
    <i class="fa fa-star-half-alt"></i> 
    							Used <br/>
    <i class="fa fa-dumbbell"></i> 
    							WDBRF81J95F631019							<!--<i class="fa fa-map-marker-alt"></i> -->
    </p>
    <div class="course_footer d-flex align-items-center justify-content-start small">
    <a class="d-inline-block col text-dark" data-bs-toggle="tooltip" data-original-title="Transmission" data-placement="bottom" href="javascript:void(0);">
    <i class="fa fa-car"></i>
    <span class="">Automatic</span>
    </a>
    <a class="d-inline-block col text-dark" data-bs-toggle="tooltip" data-original-title="Millage" data-placement="bottom" href="javascript:void(0);">
    <i class="fa fa-road"></i> <span class="">0.00KM</span></a>
    <a class="d-inline-block col text-dark" data-bs-toggle="tooltip" data-original-title="FuelType" data-placement="bottom" href="javascript:void(0);">
    <i class="fa fa-solid fa-gas-pump"></i> <span class=""></span></a>
    </div>
    </div>
    </div>
    <div class="card col-md-3 my-3">
    <img alt="Front View" class="card-img-top" height="220px;" src="vehicleImage/PTML 565.jpg"/>
    <div class="card-body p-0">
    <div class="course_header d-flex flex-row align-items-center justify-content-start small">
    <div class="course_tag">
    <a href="previous_vehicle_details.php?refNo=21&amp;itemType=Vehicle">NCS/PTML/OVT/01/24/21</a>
    </div>
    <div class="course_price ml-auto">
    								Price 
    								<span> ₦500,000.00</span><br/>
    </div>
    </div>
    <h5 class="card-title">
    					        
    					        PEUGEOT 406 2001					    </h5>
    <p class="card-text small">
    <i class="fa fa-star-half-alt"></i> 
    							Used <br/>
    <i class="fa fa-dumbbell"></i> 
    							VF38BRFNA18007629							<!--<i class="fa fa-map-marker-alt"></i> -->
    </p>
    <div class="course_footer d-flex align-items-center justify-content-start small">
    <a class="d-inline-block col text-dark" data-bs-toggle="tooltip" data-original-title="Transmission" data-placement="bottom" href="javascript:void(0);">
    <i class="fa fa-car"></i>
    <span class="">Automatic</span>
    </a>
    <a class="d-inline-block col text-dark" data-bs-toggle="tooltip" data-original-title="Millage" data-placement="bottom" href="javascript:void(0);">
    <i class="fa fa-road"></i> <span class="">0.00KM</span></a>
    <a class="d-inline-block col text-dark" data-bs-toggle="tooltip" data-original-title="FuelType" data-placement="bottom" href="javascript:void(0);">
    <i class="fa fa-solid fa-gas-pump"></i> <span class="">Petrol</span></a>
    </div>
    </div>
    </div>
    <div class="card col-md-3 my-3">
    <img alt="Front View" class="card-img-top" height="220px;" src="vehicleImage/PTML 568.jpg"/>
    <div class="card-body p-0">
    <div class="course_header d-flex flex-row align-items-center justify-content-start small">
    <div class="course_tag">
    <a href="previous_vehicle_details.php?refNo=19&amp;itemType=Vehicle">NCS/PTML/OVT/01/24/19</a>
    </div>
    <div class="course_price ml-auto">
    								Price 
    								<span> ₦600,000.00</span><br/>
    </div>
    </div>
    <h5 class="card-title">
    					        
    					        HONDA ACCORD EX 1.5T 4DR SEDAN 2007					    </h5>
    <p class="card-text small">
    <i class="fa fa-star-half-alt"></i> 
    							Used <br/>
    <i class="fa fa-dumbbell"></i> 
    							1HGCM665X7A090545							<!--<i class="fa fa-map-marker-alt"></i> -->
    </p>
    <div class="course_footer d-flex align-items-center justify-content-start small">
    <a class="d-inline-block col text-dark" data-bs-toggle="tooltip" data-original-title="Transmission" data-placement="bottom" href="javascript:void(0);">
    <i class="fa fa-car"></i>
    <span class="">Automatic</span>
    </a>
    <a class="d-inline-block col text-dark" data-bs-toggle="tooltip" data-original-title="Millage" data-placement="bottom" href="javascript:void(0);">
    <i class="fa fa-road"></i> <span class="">0.00KM</span></a>
    <a class="d-inline-block col text-dark" data-bs-toggle="tooltip" data-original-title="FuelType" data-placement="bottom" href="javascript:void(0);">
    <i class="fa fa-solid fa-gas-pump"></i> <span class="">Petrol</span></a>
    </div>
    </div>
    </div>
    <div class="card col-md-3 my-3">
    <img alt="Front View" class="card-img-top" height="220px;" src="vehicleImage/PTML 567.jpg"/>
    <div class="card-body p-0">
    <div class="course_header d-flex flex-row align-items-center justify-content-start small">
    <div class="course_tag">
    <a href="previous_vehicle_details.php?refNo=20&amp;itemType=Vehicle">NCS/PTML/OVT/01/24/20</a>
    </div>
    <div class="course_price ml-auto">
    								Price 
    								<span> ₦455,000.00</span><br/>
    </div>
    </div>
    <h5 class="card-title">
    					        
    					        TOYOTA CAMRY L 4DR FRONT-WHEEL DRIVE SEDAN 2002					    </h5>
    <p class="card-text small">
    <i class="fa fa-star-half-alt"></i> 
    							Used <br/>
    <i class="fa fa-dumbbell"></i> 
    							JTDBE32K420028817							<!--<i class="fa fa-map-marker-alt"></i> -->
    </p>
    <div class="course_footer d-flex align-items-center justify-content-start small">
    <a class="d-inline-block col text-dark" data-bs-toggle="tooltip" data-original-title="Transmission" data-placement="bottom" href="javascript:void(0);">
    <i class="fa fa-car"></i>
    <span class="">Automatic</span>
    </a>
    <a class="d-inline-block col text-dark" data-bs-toggle="tooltip" data-original-title="Millage" data-placement="bottom" href="javascript:void(0);">
    <i class="fa fa-road"></i> <span class="">0.00KM</span></a>
    <a class="d-inline-block col text-dark" data-bs-toggle="tooltip" data-original-title="FuelType" data-placement="bottom" href="javascript:void(0);">
    <i class="fa fa-solid fa-gas-pump"></i> <span class="">Petrol</span></a>
    </div>
    </div>
    </div>
    <div class="card col-md-3 my-3">
    <img alt="Front View" class="card-img-top" height="220px;" src="vehicleImage/PTML 564.jpg"/>
    <div class="card-body p-0">
    <div class="course_header d-flex flex-row align-items-center justify-content-start small">
    <div class="course_tag">
    <a href="previous_vehicle_details.php?refNo=22&amp;itemType=Vehicle">NCS/PTML/OVT/01/24/22</a>
    </div>
    <div class="course_price ml-auto">
    								Price 
    								<span> ₦1,800,000.00</span><br/>
    </div>
    </div>
    <h5 class="card-title">
    					        
    					        TOYOTA YARIS SEDAN L 4DR SEDAN 2007					    </h5>
    <p class="card-text small">
    <i class="fa fa-star-half-alt"></i> 
    							Used <br/>
    <i class="fa fa-dumbbell"></i> 
    							JTDJT923175085645							<!--<i class="fa fa-map-marker-alt"></i> -->
    </p>
    <div class="course_footer d-flex align-items-center justify-content-start small">
    <a class="d-inline-block col text-dark" data-bs-toggle="tooltip" data-original-title="Transmission" data-placement="bottom" href="javascript:void(0);">
    <i class="fa fa-car"></i>
    <span class="">Automatic</span>
    </a>
    <a class="d-inline-block col text-dark" data-bs-toggle="tooltip" data-original-title="Millage" data-placement="bottom" href="javascript:void(0);">
    <i class="fa fa-road"></i> <span class="">0.00KM</span></a>
    <a class="d-inline-block col text-dark" data-bs-toggle="tooltip" data-original-title="FuelType" data-placement="bottom" href="javascript:void(0);">
    <i class="fa fa-solid fa-gas-pump"></i> <span class=""></span></a>
    </div>
    </div>
    </div>
    <div class="card col-md-3 my-3">
    <img alt="Front View" class="card-img-top" height="220px;" src="vehicleImage/PTML 562.jpg"/>
    <div class="card-body p-0">
    <div class="course_header d-flex flex-row align-items-center justify-content-start small">
    <div class="course_tag">
    <a href="previous_vehicle_details.php?refNo=24&amp;itemType=Vehicle">NCS/PTML/OVT/01/24/24</a>
    </div>
    <div class="course_price ml-auto">
    								Price 
    								<span> ₦540,000.00</span><br/>
    </div>
    </div>
    <h5 class="card-title">
    					        
    					        MERCEDES-BENZ C180 2006					    </h5>
    <p class="card-text small">
    <i class="fa fa-star-half-alt"></i> 
    							Used <br/>
    <i class="fa fa-dumbbell"></i> 
    							WDB2030351F066544							<!--<i class="fa fa-map-marker-alt"></i> -->
    </p>
    <div class="course_footer d-flex align-items-center justify-content-start small">
    <a class="d-inline-block col text-dark" data-bs-toggle="tooltip" data-original-title="Transmission" data-placement="bottom" href="javascript:void(0);">
    <i class="fa fa-car"></i>
    <span class="">Automatic</span>
    </a>
    <a class="d-inline-block col text-dark" data-bs-toggle="tooltip" data-original-title="Millage" data-placement="bottom" href="javascript:void(0);">
    <i class="fa fa-road"></i> <span class="">0.00KM</span></a>
    <a class="d-inline-block col text-dark" data-bs-toggle="tooltip" data-original-title="FuelType" data-placement="bottom" href="javascript:void(0);">
    <i class="fa fa-solid fa-gas-pump"></i> <span class="">Petrol</span></a>
    </div>
    </div>
    </div>
    <div class="card col-md-3 my-3">
    <img alt="Front View" class="card-img-top" height="220px;" src="vehicleImage/PTML 558.jpg"/>
    <div class="card-body p-0">
    <div class="course_header d-flex flex-row align-items-center justify-content-start small">
    <div class="course_tag">
    <a href="previous_vehicle_details.php?refNo=25&amp;itemType=Vehicle">NCS/PTML/OVT/01/24/25</a>
    </div>
    <div class="course_price ml-auto">
    								Price 
    								<span> ₦425,000.00</span><br/>
    </div>
    </div>
    <h5 class="card-title">
    					        
    					        MERCEDES-BENZ C180 2002					    </h5>
    <p class="card-text small">
    <i class="fa fa-star-half-alt"></i> 
    							Used <br/>
    <i class="fa fa-dumbbell"></i> 
    							WDB2032461F351760							<!--<i class="fa fa-map-marker-alt"></i> -->
    </p>
    <div class="course_footer d-flex align-items-center justify-content-start small">
    <a class="d-inline-block col text-dark" data-bs-toggle="tooltip" data-original-title="Transmission" data-placement="bottom" href="javascript:void(0);">
    <i class="fa fa-car"></i>
    <span class="">Automatic</span>
    </a>
    <a class="d-inline-block col text-dark" data-bs-toggle="tooltip" data-original-title="Millage" data-placement="bottom" href="javascript:void(0);">
    <i class="fa fa-road"></i> <span class="">0.00KM</span></a>
    <a class="d-inline-block col text-dark" data-bs-toggle="tooltip" data-original-title="FuelType" data-placement="bottom" href="javascript:void(0);">
    <i class="fa fa-solid fa-gas-pump"></i> <span class=""></span></a>
    </div>
    </div>
    </div>
    <div class="card col-md-3 my-3">
    <img alt="Front View" class="card-img-top" height="220px;" src="vehicleImage/PTML 554.jpg"/>
    <div class="card-body p-0">
    <div class="course_header d-flex flex-row align-items-center justify-content-start small">
    <div class="course_tag">
    <a href="previous_vehicle_details.php?refNo=26&amp;itemType=Vehicle">NCS/PTML/OVT/01/24/26</a>
    </div>
    <div class="course_price ml-auto">
    								Price 
    								<span> ₦401,000.00</span><br/>
    </div>
    </div>
    <h5 class="card-title">
    					        
    					        NISSAN 37OZ BASE 2DR COUPE 2009					    </h5>
    <p class="card-text small">
    <i class="fa fa-star-half-alt"></i> 
    							Used <br/>
    <i class="fa fa-dumbbell"></i> 
    							3N1AB61E59L668598							<!--<i class="fa fa-map-marker-alt"></i> -->
    </p>
    <div class="course_footer d-flex align-items-center justify-content-start small">
    <a class="d-inline-block col text-dark" data-bs-toggle="tooltip" data-original-title="Transmission" data-placement="bottom" href="javascript:void(0);">
    <i class="fa fa-car"></i>
    <span class="">Automatic</span>
    </a>
    <a class="d-inline-block col text-dark" data-bs-toggle="tooltip" data-original-title="Millage" data-placement="bottom" href="javascript:void(0);">
    <i class="fa fa-road"></i> <span class="">0.00KM</span></a>
    <a class="d-inline-block col text-dark" data-bs-toggle="tooltip" data-original-title="FuelType" data-placement="bottom" href="javascript:void(0);">
    <i class="fa fa-solid fa-gas-pump"></i> <span class="">Petrol</span></a>
    </div>
    </div>
    </div>
    <div class="card col-md-3 my-3">
    <img alt="Front View" class="card-img-top" height="220px;" src="vehicleImage/PTML 552.jpg"/>
    <div class="card-body p-0">
    <div class="course_header d-flex flex-row align-items-center justify-content-start small">
    <div class="course_tag">
    <a href="previous_vehicle_details.php?refNo=27&amp;itemType=Vehicle">NCS/PTML/OVT/01/24/27</a>
    </div>
    <div class="course_price ml-auto">
    								Price 
    								<span> ₦870,000.00</span><br/>
    </div>
    </div>
    <h5 class="card-title">
    					        
    					        TOYOTA CAMRY L 4DR FRONT-WHEEL DRIVE SEDAN 2004					    </h5>
    <p class="card-text small">
    <i class="fa fa-star-half-alt"></i> 
    							Used <br/>
    <i class="fa fa-dumbbell"></i> 
    							4T1BE32K24U886231							<!--<i class="fa fa-map-marker-alt"></i> -->
    </p>
    <div class="course_footer d-flex align-items-center justify-content-start small">
    <a class="d-inline-block col text-dark" data-bs-toggle="tooltip" data-original-title="Transmission" data-placement="bottom" href="javascript:void(0);">
    <i class="fa fa-car"></i>
    <span class="">Automatic</span>
    </a>
    <a class="d-inline-block col text-dark" data-bs-toggle="tooltip" data-original-title="Millage" data-placement="bottom" href="javascript:void(0);">
    <i class="fa fa-road"></i> <span class="">0.00KM</span></a>
    <a class="d-inline-block col text-dark" data-bs-toggle="tooltip" data-original-title="FuelType" data-placement="bottom" href="javascript:void(0);">
    <i class="fa fa-solid fa-gas-pump"></i> <span class="">Petrol</span></a>
    </div>
    </div>
    </div>
    <div class="card col-md-3 my-3">
    <img alt="Front View" class="card-img-top" height="220px;" src="vehicleImage/PTML 549.jpg"/>
    <div class="card-body p-0">
    <div class="course_header d-flex flex-row align-items-center justify-content-start small">
    <div class="course_tag">
    <a href="previous_vehicle_details.php?refNo=28&amp;itemType=Vehicle">NCS/PTML/OVT/01/24/28</a>
    </div>
    <div class="course_price ml-auto">
    								Price 
    								<span> ₦750,000.00</span><br/>
    </div>
    </div>
    <h5 class="card-title">
    					        
    					        HONDA ACCORD EX-L 1.5T 4DR SEDAN 2010					    </h5>
    <p class="card-text small">
    <i class="fa fa-star-half-alt"></i> 
    							Used <br/>
    <i class="fa fa-dumbbell"></i> 
    							1HGCP2F79AA137475							<!--<i class="fa fa-map-marker-alt"></i> -->
    </p>
    <div class="course_footer d-flex align-items-center justify-content-start small">
    <a class="d-inline-block col text-dark" data-bs-toggle="tooltip" data-original-title="Transmission" data-placement="bottom" href="javascript:void(0);">
    <i class="fa fa-car"></i>
    <span class="">Automatic</span>
    </a>
    <a class="d-inline-block col text-dark" data-bs-toggle="tooltip" data-original-title="Millage" data-placement="bottom" href="javascript:void(0);">
    <i class="fa fa-road"></i> <span class="">0.00KM</span></a>
    <a class="d-inline-block col text-dark" data-bs-toggle="tooltip" data-original-title="FuelType" data-placement="bottom" href="javascript:void(0);">
    <i class="fa fa-solid fa-gas-pump"></i> <span class="">Petrol</span></a>
    </div>
    </div>
    </div>
    <div class="card col-md-3 my-3">
    <img alt="Front View" class="card-img-top" height="220px;" src="vehicleImage/PTML 546.jpg"/>
    <div class="card-body p-0">
    <div class="course_header d-flex flex-row align-items-center justify-content-start small">
    <div class="course_tag">
    <a href="previous_vehicle_details.php?refNo=29&amp;itemType=Vehicle">NCS/PTML/OVT/01/24/29</a>
    </div>
    <div class="course_price ml-auto">
    								Price 
    								<span> ₦550,000.00</span><br/>
    </div>
    </div>
    <h5 class="card-title">
    					        
    					        DODGE CARAVAN 2010					    </h5>
    <p class="card-text small">
    <i class="fa fa-star-half-alt"></i> 
    							Used <br/>
    <i class="fa fa-dumbbell"></i> 
    							2D4RN5DX9AR124758							<!--<i class="fa fa-map-marker-alt"></i> -->
    </p>
    <div class="course_footer d-flex align-items-center justify-content-start small">
    <a class="d-inline-block col text-dark" data-bs-toggle="tooltip" data-original-title="Transmission" data-placement="bottom" href="javascript:void(0);">
    <i class="fa fa-car"></i>
    <span class="">Automatic</span>
    </a>
    <a class="d-inline-block col text-dark" data-bs-toggle="tooltip" data-original-title="Millage" data-placement="bottom" href="javascript:void(0);">
    <i class="fa fa-road"></i> <span class="">0.00KM</span></a>
    <a class="d-inline-block col text-dark" data-bs-toggle="tooltip" data-original-title="FuelType" data-placement="bottom" href="javascript:void(0);">
    <i class="fa fa-solid fa-gas-pump"></i> <span class="">Petrol</span></a>
    </div>
    </div>
    </div>
    <div class="card col-md-3 my-3">
    <img alt="Front View" class="card-img-top" height="220px;" src="vehicleImage/PTML 540.jpg"/>
    <div class="card-body p-0">
    <div class="course_header d-flex flex-row align-items-center justify-content-start small">
    <div class="course_tag">
    <a href="previous_vehicle_details.php?refNo=30&amp;itemType=Vehicle">NCS///01/24/30</a>
    </div>
    <div class="course_price ml-auto">
    								Price 
    								<span> ₦421,678.00</span><br/>
    </div>
    </div>
    <h5 class="card-title">
    					        
    					        DODGE CALIBER 2007					    </h5>
    <p class="card-text small">
    <i class="fa fa-star-half-alt"></i> 
    							Used <br/>
    <i class="fa fa-dumbbell"></i> 
    							1B3HE78K77D338275							<!--<i class="fa fa-map-marker-alt"></i> -->
    </p>
    <div class="course_footer d-flex align-items-center justify-content-start small">
    <a class="d-inline-block col text-dark" data-bs-toggle="tooltip" data-original-title="Transmission" data-placement="bottom" href="javascript:void(0);">
    <i class="fa fa-car"></i>
    <span class="">Automatic</span>
    </a>
    <a class="d-inline-block col text-dark" data-bs-toggle="tooltip" data-original-title="Millage" data-placement="bottom" href="javascript:void(0);">
    <i class="fa fa-road"></i> <span class="">0.00KM</span></a>
    <a class="d-inline-block col text-dark" data-bs-toggle="tooltip" data-original-title="FuelType" data-placement="bottom" href="javascript:void(0);">
    <i class="fa fa-solid fa-gas-pump"></i> <span class="">Petrol</span></a>
    </div>
    </div>
    </div>
    <div class="card col-md-3 my-3">
    <img alt="Front View" class="card-img-top" height="220px;" src="vehicleImage/PTML 539.jpg"/>
    <div class="card-body p-0">
    <div class="course_header d-flex flex-row align-items-center justify-content-start small">
    <div class="course_tag">
    <a href="previous_vehicle_details.php?refNo=31&amp;itemType=Vehicle">NCS/PTML/OVT/01/24/31</a>
    </div>
    <div class="course_price ml-auto">
    								Price 
    								<span> ₦590,000.00</span><br/>
    </div>
    </div>
    <h5 class="card-title">
    					        
    					        OPEL ZAFIRA 2000					    </h5>
    <p class="card-text small">
    <i class="fa fa-star-half-alt"></i> 
    							Used <br/>
    <i class="fa fa-dumbbell"></i> 
    							W0L0TGF75Y2210603							<!--<i class="fa fa-map-marker-alt"></i> -->
    </p>
    <div class="course_footer d-flex align-items-center justify-content-start small">
    <a class="d-inline-block col text-dark" data-bs-toggle="tooltip" data-original-title="Transmission" data-placement="bottom" href="javascript:void(0);">
    <i class="fa fa-car"></i>
    <span class="">Manual</span>
    </a>
    <a class="d-inline-block col text-dark" data-bs-toggle="tooltip" data-original-title="Millage" data-placement="bottom" href="javascript:void(0);">
    <i class="fa fa-road"></i> <span class="">0.00KM</span></a>
    <a class="d-inline-block col text-dark" data-bs-toggle="tooltip" data-original-title="FuelType" data-placement="bottom" href="javascript:void(0);">
    <i class="fa fa-solid fa-gas-pump"></i> <span class="">Petrol</span></a>
    </div>
    </div>
    </div>
    <div class="card col-md-3 my-3">
    <img alt="Front View" class="card-img-top" height="220px;" src="vehicleImage/PTML 174.jpg"/>
    <div class="card-body p-0">
    <div class="course_header d-flex flex-row align-items-center justify-content-start small">
    <div class="course_tag">
    <a href="previous_vehicle_details.php?refNo=32&amp;itemType=Vehicle">NCS/PTML/OVT/01/24/32</a>
    </div>
    <div class="course_price ml-auto">
    								Price 
    								<span> ₦410,000.00</span><br/>
    </div>
    </div>
    <h5 class="card-title">
    					        
    					        VOLVO V40 2005					    </h5>
    <p class="card-text small">
    <i class="fa fa-star-half-alt"></i> 
    							Used <br/>
    <i class="fa fa-dumbbell"></i> 
    							KMHPM81CP5U215763							<!--<i class="fa fa-map-marker-alt"></i> -->
    </p>
    <div class="course_footer d-flex align-items-center justify-content-start small">
    <a class="d-inline-block col text-dark" data-bs-toggle="tooltip" data-original-title="Transmission" data-placement="bottom" href="javascript:void(0);">
    <i class="fa fa-car"></i>
    <span class="">Automatic</span>
    </a>
    <a class="d-inline-block col text-dark" data-bs-toggle="tooltip" data-original-title="Millage" data-placement="bottom" href="javascript:void(0);">
    <i class="fa fa-road"></i> <span class="">0.00KM</span></a>
    <a class="d-inline-block col text-dark" data-bs-toggle="tooltip" data-original-title="FuelType" data-placement="bottom" href="javascript:void(0);">
    <i class="fa fa-solid fa-gas-pump"></i> <span class="">Petrol</span></a>
    </div>
    </div>
    </div>
    <div class="card col-md-3 my-3">
    <img alt="Front View" class="card-img-top" height="220px;" src="vehicleImage/PTML 535.jpg"/>
    <div class="card-body p-0">
    <div class="course_header d-flex flex-row align-items-center justify-content-start small">
    <div class="course_tag">
    <a href="previous_vehicle_details.php?refNo=33&amp;itemType=Vehicle">NCS/PTML/OVT/01/24/33</a>
    </div>
    <div class="course_price ml-auto">
    								Price 
    								<span> ₦413,000.00</span><br/>
    </div>
    </div>
    <h5 class="card-title">
    					        
    					        MAZDA PREMACY 2006					    </h5>
    <p class="card-text small">
    <i class="fa fa-star-half-alt"></i> 
    							Used <br/>
    <i class="fa fa-dumbbell"></i> 
    							JMZCP19F201151989							<!--<i class="fa fa-map-marker-alt"></i> -->
    </p>
    <div class="course_footer d-flex align-items-center justify-content-start small">
    <a class="d-inline-block col text-dark" data-bs-toggle="tooltip" data-original-title="Transmission" data-placement="bottom" href="javascript:void(0);">
    <i class="fa fa-car"></i>
    <span class="">Automatic</span>
    </a>
    <a class="d-inline-block col text-dark" data-bs-toggle="tooltip" data-original-title="Millage" data-placement="bottom" href="javascript:void(0);">
    <i class="fa fa-road"></i> <span class="">0.00KM</span></a>
    <a class="d-inline-block col text-dark" data-bs-toggle="tooltip" data-original-title="FuelType" data-placement="bottom" href="javascript:void(0);">
    <i class="fa fa-solid fa-gas-pump"></i> <span class="">Petrol</span></a>
    </div>
    </div>
    </div>
    <div class="card col-md-3 my-3">
    <img alt="Front View" class="card-img-top" height="220px;" src="vehicleImage/PTML 169.jpg"/>
    <div class="card-body p-0">
    <div class="course_header d-flex flex-row align-items-center justify-content-start small">
    <div class="course_tag">
    <a href="previous_vehicle_details.php?refNo=34&amp;itemType=Vehicle">NCS/PTML/OVT/01/24/34</a>
    </div>
    <div class="course_price ml-auto">
    								Price 
    								<span> ₦470,000.00</span><br/>
    </div>
    </div>
    <h5 class="card-title">
    					        
    					        NISSAN ALTIMA 2.0 SR 4DR FRONT-WHEEL DRIVE SEDAN 2009					    </h5>
    <p class="card-text small">
    <i class="fa fa-star-half-alt"></i> 
    							Used <br/>
    <i class="fa fa-dumbbell"></i> 
    							1N4AL21E59N541732							<!--<i class="fa fa-map-marker-alt"></i> -->
    </p>
    <div class="course_footer d-flex align-items-center justify-content-start small">
    <a class="d-inline-block col text-dark" data-bs-toggle="tooltip" data-original-title="Transmission" data-placement="bottom" href="javascript:void(0);">
    <i class="fa fa-car"></i>
    <span class="">Automatic</span>
    </a>
    <a class="d-inline-block col text-dark" data-bs-toggle="tooltip" data-original-title="Millage" data-placement="bottom" href="javascript:void(0);">
    <i class="fa fa-road"></i> <span class="">0.00KM</span></a>
    <a class="d-inline-block col text-dark" data-bs-toggle="tooltip" data-original-title="FuelType" data-placement="bottom" href="javascript:void(0);">
    <i class="fa fa-solid fa-gas-pump"></i> <span class="">Petrol</span></a>
    </div>
    </div>
    </div>
    <div class="card col-md-3 my-3">
    <img alt="Front View" class="card-img-top" height="220px;" src="vehicleImage/PTML 534.jpg"/>
    <div class="card-body p-0">
    <div class="course_header d-flex flex-row align-items-center justify-content-start small">
    <div class="course_tag">
    <a href="previous_vehicle_details.php?refNo=35&amp;itemType=Vehicle">NCS/PTML/OVT/01/24/35</a>
    </div>
    <div class="course_price ml-auto">
    								Price 
    								<span> ₦500,000.00</span><br/>
    </div>
    </div>
    <h5 class="card-title">
    					        
    					        OPEL ZAFIRA 2000					    </h5>
    <p class="card-text small">
    <i class="fa fa-star-half-alt"></i> 
    							Used <br/>
    <i class="fa fa-dumbbell"></i> 
    							W0L0TGF7542006165							<!--<i class="fa fa-map-marker-alt"></i> -->
    </p>
    <div class="course_footer d-flex align-items-center justify-content-start small">
    <a class="d-inline-block col text-dark" data-bs-toggle="tooltip" data-original-title="Transmission" data-placement="bottom" href="javascript:void(0);">
    <i class="fa fa-car"></i>
    <span class="">Automatic</span>
    </a>
    <a class="d-inline-block col text-dark" data-bs-toggle="tooltip" data-original-title="Millage" data-placement="bottom" href="javascript:void(0);">
    <i class="fa fa-road"></i> <span class="">0.00KM</span></a>
    <a class="d-inline-block col text-dark" data-bs-toggle="tooltip" data-original-title="FuelType" data-placement="bottom" href="javascript:void(0);">
    <i class="fa fa-solid fa-gas-pump"></i> <span class="">Petrol</span></a>
    </div>
    </div>
    </div>
    <div class="card col-md-3 my-3">
    <img alt="Front View" class="card-img-top" height="220px;" src="vehicleImage/PTML 532.jpg"/>
    <div class="card-body p-0">
    <div class="course_header d-flex flex-row align-items-center justify-content-start small">
    <div class="course_tag">
    <a href="previous_vehicle_details.php?refNo=36&amp;itemType=Vehicle">NCS/PTML/OVT/01/24/36</a>
    </div>
    <div class="course_price ml-auto">
    								Price 
    								<span> ₦413,000.00</span><br/>
    </div>
    </div>
    <h5 class="card-title">
    					        
    					        MITSUBISHI SPACE WAGON 2001					    </h5>
    <p class="card-text small">
    <i class="fa fa-star-half-alt"></i> 
    							Used <br/>
    <i class="fa fa-dumbbell"></i> 
    							JMBLNN84W1Z001380							<!--<i class="fa fa-map-marker-alt"></i> -->
    </p>
    <div class="course_footer d-flex align-items-center justify-content-start small">
    <a class="d-inline-block col text-dark" data-bs-toggle="tooltip" data-original-title="Transmission" data-placement="bottom" href="javascript:void(0);">
    <i class="fa fa-car"></i>
    <span class="">Automatic</span>
    </a>
    <a class="d-inline-block col text-dark" data-bs-toggle="tooltip" data-original-title="Millage" data-placement="bottom" href="javascript:void(0);">
    <i class="fa fa-road"></i> <span class="">0.00KM</span></a>
    <a class="d-inline-block col text-dark" data-bs-toggle="tooltip" data-original-title="FuelType" data-placement="bottom" href="javascript:void(0);">
    <i class="fa fa-solid fa-gas-pump"></i> <span class="">Petrol</span></a>
    </div>
    </div>
    </div>
    </div>
    <!--<nav aria-label="Page navigation example ">-->
    <!--  <ul class="pagination justify-content-center mt-3">-->
    <!--    <li class="page-item disabled">-->
    <!--      <a class="page-link" href="#" tabindex="-1">Previous</a>-->
    <!--    </li>-->
    <!--    <li class="page-item"><a class="page-link" href="#">1</a></li>-->
    <!--    <li class="page-item"><a class="page-link" href="#">2</a></li>-->
    <!--    <li class="page-item"><a class="page-link" href="#">3</a></li>-->
    <!--    <li class="page-item"><a class="page-link" href="#">4</a></li>-->
    <!--    <li class="page-item"><a class="page-link" href="#">5</a></li>-->
    <!--    <li class="page-item">-->
    <!--      <a class="page-link" href="#">Next</a>-->
    <!--    </li>-->
    <!--  </ul>-->
    <!--</nav>-->
    <div class="container mt-5">
    <!-- Pagination -->
    <nav aria-label="Page navigation">
    <ul class="pagination justify-content-center mt-4">
    <li class="page-item active">
    <a class="page-link" href="?page=1">1</a>
    </li>
    <li class="page-item">
    <a class="page-link" href="?page=2">2</a>
    </li>
    <li class="page-item">
    <a class="page-link" href="?page=3">3</a>
    </li>
    <li class="page-item">
    <a class="page-link" href="?page=4">4</a>
    </li>
    <li class="page-item">
    <a class="page-link" href="?page=5">5</a>
    </li>
    <li class="page-item">
    <a class="page-link" href="?page=6">6</a>
    </li>
    <li class="page-item">
    <a class="page-link" href="?page=7">7</a>
    </li>
    <li class="page-item">
    <a class="page-link" href="?page=8">8</a>
    </li>
    <li class="page-item">
    <a class="page-link" href="?page=9">9</a>
    </li>
    <li class="page-item">
    <a class="page-link" href="?page=10">10</a>
    </li>
    <li class="page-item">
    <a class="page-link" href="?page=11">11</a>
    </li>
    <li class="page-item">
    <a class="page-link" href="?page=12">12</a>
    </li>
    <li class="page-item">
    <a class="page-link" href="?page=13">13</a>
    </li>
    <li class="page-item">
    <a class="page-link" href="?page=14">14</a>
    </li>
    <li class="page-item">
    <a class="page-link" href="?page=15">15</a>
    </li>
    <li class="page-item">
    <a class="page-link" href="?page=16">16</a>
    </li>
    <li class="page-item">
    <a class="page-link" href="?page=17">17</a>
    </li>
    <li class="page-item">
    <a class="page-link" href="?page=18">18</a>
    </li>
    <li class="page-item">
    <a class="page-link" href="?page=19">19</a>
    </li>
    <li class="page-item">
    <a class="page-link" href="?page=20">20</a>
    </li>
    <li class="page-item">
    <a class="page-link" href="?page=21">21</a>
    </li>
    <li class="page-item">
    <a class="page-link" href="?page=22">22</a>
    </li>
    <li class="page-item">
    <a class="page-link" href="?page=23">23</a>
    </li>
    <li class="page-item">
    <a class="page-link" href="?page=24">24</a>
    </li>
    <li class="page-item">
    <a class="page-link" href="?page=25">25</a>
    </li>
    <li class="page-item">
    <a class="page-link" href="?page=26">26</a>
    </li>
    <li class="page-item">
    <a class="page-link" href="?page=27">27</a>
    </li>
    <li class="page-item">
    <a class="page-link" href="?page=28">28</a>
    </li>
    <li class="page-item">
    <a class="page-link" href="?page=29">29</a>
    </li>
    <li class="page-item">
    <a class="page-link" href="?page=30">30</a>
    </li>
    <li class="page-item">
    <a class="page-link" href="?page=31">31</a>
    </li>
    <li class="page-item">
    <a class="page-link" href="?page=32">32</a>
    </li>
    <li class="page-item">
    <a class="page-link" href="?page=33">33</a>
    </li>
    <li class="page-item">
    <a class="page-link" href="?page=34">34</a>
    </li>
    <li class="page-item">
    <a class="page-link" href="?page=35">35</a>
    </li>
    <li class="page-item">
    <a class="page-link" href="?page=36">36</a>
    </li>
    <li class="page-item">
    <a class="page-link" href="?page=37">37</a>
    </li>
    <li class="page-item">
    <a class="page-link" href="?page=38">38</a>
    </li>
    </ul>
    </nav>
    </div>
    </div>
    </div>
    </div>
    <!-- Join -->
    <!-- <div class="join">
    		<div class="container">
    			<div class="row">
    				<div class="col-lg-10 offset-lg-1">
    					<div class="section_title text-center"><h2>Join Our Platform Today</h2></div>
    					<div class="section_subtitle">Suspendisse tincidunt magna eget massa hendrerit efficitur. Ut euismod pellentesque imperdiet. Cras laoreet gravida lectus, at viverra lorem venenatis in. Aenean id varius quam. Nullam bibendum interdum dui, ac tempor lorem convallis ut</div>
    				</div>
    			</div>
    		</div>
    		<div class="button join_button"><a href="#">register now<div class="button_arrow"><i class="fa fa-angle-right" aria-hidden="true"></i></div></a></div>
    	</div>
     -->
    <!-- Footer -->
    <!-- Modal -->
    <div aria-hidden="true" aria-labelledby="exampleModalLongTitle" class="modal fade" id="exampleModalLong" role="dialog" tabindex="-1">
    <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content">
    <div class="modal-header">
    <h5 class="modal-title" id="exampleModalLongTitle">Terms and Conditions</h5>
    <button aria-label="Close" class="close" data-dismiss="modal" type="button">
    <span aria-hidden="true">×</span>
    </button>
    </div>
    <div class="modal-body p-5">
    <div class="">
    <ol>
    <li>Applicant must have a valid TIN issued by FIRS with an active e-mail account.</li>
    <li>An Applicant shall pay a non-refundable fee of One Thousand Naira (₦1,000) as administrative.</li>
    <li>An Item is auctioned "as is" as such request for replacement or refund shall not be entertained. </li>
    <li>The successful bidder shall make payment within five (5) working days. </li>
    <li>If the winner fails to pay and clear within the stipulate timeline, the won item will be returned back to the pool  and the Winner account will be BLCOKED.</li>
    <li> The successful Winners has three (3) days to make payment and seven (7) days from the date of payment to remove the item bidded for or forfeit the item won. </li>
    <li>Any auction item not removed from the warehouse within TEN (10) days from the date of payment shall revert to its pre-bidding status. </li>
    <li><b> Take note for overtime cargo, that </b> the successful bidder shall in addition pay 7.5% VAT,  25% charges for Shipping Line and Terminal operators respectively.</li>
    <li> Bidders shall not be allowed to bid for more than 2 items per bidding window.</li>
    <li> A bidder can place a bid of up to 10% of the current highest bid for a particular item at any given time during  the  auction.</li>
    <li> For claiming items, the winner shall present; 
                      <ol> a)	A valid copy of paid assessment and bank receipt (optional in case of e-payment);</ol>
    <ol>b)	A notarized letter in case owner sends representative. (Where owner is present uploaded photo on registration will do.); </ol>
    <ol>c) Provide proper identification with notarized letter and International passport, Driver’s license, Voters card or National I.D. </ol>
    </li>
    <li><b> The dwell time for this Online Auction Sale shall be Six (6) hours. </b></li>
    <li> Third party claims shall not be entertained. </li>
    <li>Officers of the Nigeria Customs Service are excluded from participating this Auction. </li>
    <li> Owner of seized item is excluded from bidding for the same. </li>
    <li> Owner of overtime item with evidence of payment of duty and other charges has priority over a successful bidder of the same provided the item has not been exited out of the Customs control.</li>
    <li> Conditions and Terms of this auction are to be carefully considered by an interested person before acceptance. </li>
    <li> Applicant undertakes to abide by the conditions and terms of this auction. </li>
    <li> I hereby accept the terms and conditions stated above. </li>
    </ol>
    </div>
    </div>
    <div class="modal-footer">
    <!-- <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            <button type="button" class="btn btn-primary">Save changes</button> -->
    </div>
    </div>
    </div>
    </div>
    <div aria-hidden="true" aria-labelledby="bid" class="modal fade" id="bid" role="dialog" tabindex="-1">
    <div class="modal-dialog" role="document">
    <div class="modal-content">
    <div class="modal-header">
    <h5 class="modal-title" id="exampleModalLongTitle">Bid</h5>
    <button aria-label="Close" class="close" data-dismiss="modal" type="button">
    <span aria-hidden="true">×</span>
    </button>
    </div>
    <div class="modal-body p-4 text-center">
                    
                Kindly login to place your Bid. <a class="" href="login.php">Click Here To Login</a> OR <a href="signup.php">SignUp Here</a>
    </div>
    <div class="modal-footer">
    <!-- <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            <button type="button" class="btn btn-primary">Save changes</button> -->
    </div>
    </div>
    </div>
    </div>
    <div aria-hidden="true" aria-labelledby="bid" class="modal fade" id="fund" role="dialog" tabindex="-1">
    <div class="modal-dialog" role="document">
    <div class="modal-content">
    <div class="modal-header">
    <h5 class="modal-title" id="exampleModalLongTitle">Wallet Funding</h5>
    <button aria-label="Close" class="close" data-dismiss="modal" type="button">
    <span aria-hidden="true">×</span>
    </button>
    </div>
    <div class="modal-body p-5">
    <form action="backend.php" method="post">
    <div class="form-group text-left">
    <label for="amount">Amount</label>
    <input class="form-control" id="amount" max="50000" min="1000" name="fundAmount" placeholder="Enter Amount" type="number"/>
    <input name="userId" type="hidden" value=""/>
    </div>
    <div class="row justify-content-between mt-4">
    <button class="button home_button col-md-12 text-white" type="submit">Fund</button>
    </div>
    <p class="text-center">
    <small>
    <span class="text-danger">Disclaimer:</span> The Nigeria Customs Service is not liable for failed wallet funding transactions; users experiencing uncredited transactions 
                            are advised to validate the transaction through the "Transactions" menu or contact their bank.
                      </small>
    </p>
    </form>
    </div>
    <div class="modal-footer">
    <!-- <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            <button type="button" class="btn btn-primary">Save changes</button> -->
    </div>
    </div>
    </div>
    </div>
    <footer class="footer">
    <div class="container">
    <div class="row">
    <!-- About -->
    <div class="col-lg-3 footer_col">
    <div class="footer_about">
    <div class="logo_container">
    <a href="#">
    <div class="logo_content d-flex flex-row align-items-end justify-content-start">
    <!-- <div class="logo_img"><img src="images/logo.png" alt=""></div> -->
    <div class="footer_logo"><span class="e" style="font-size:40px;">e-</span><span class="auction" style="font-size:40px;">Auction</span></div>
    </div>
    </a>
    </div>
    <div class="footer_about_text">
    <p>This is the official e-Auction portal of the Nigeria Customs Service.</p>
    </div>
    <div class="copyright"><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
    Copyright ©<script>document.write(new Date().getFullYear());</script> All rights reserved | ICT-MODERNIZATION  <a href="https://customs.gov.ng" target="_blank">NCS</a>
    <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. --></div>
    </div>
    </div>
    <div class="col-lg-3 footer_col">
    <div class="footer_links">
    <div class="footer_title">Quick menu</div>
    <ul class="footer_list">
    <li><a href="index.php">Home</a></li>
    <li><a href="current_auction.php">Current Auctions</a></li>
    <li><a href="previous_auction.php">Previous Auctions</a></li>
    <li><a href="future_auction.php">Future Auctions</a></li>
    <li><a data-target="#exampleModalLong" data-toggle="modal" href="#">Terms and Conditions</a></li>
    <li><a href="index.php#requirements">Requirements</a></li>
    </ul>
    </div>
    </div>
    <div class="col-lg-3 footer_col">
    <div class="footer_links">
    <div class="footer_title">Useful Links</div>
    <ul class="footer_list">
    <li><a href="https://trade.gov.ng/tools/traders-guide">Trader's Guide</a></li>
    <li><a href="https://trade.gov.ng/custom-pages/prohibited-items-list-during-import">Import Prohibition List</a></li>
    <li><a href="https://trade.gov.ng/custom-pages/prohibited-items-list-during-export">Export Prohibition List</a></li>
    <li><a href="https://trade.gov.ng/custom-pages/guidelines-and-procedures">Guidelines and Procedures</a></li>
    </ul>
    </div>
    </div>
    <div class="col-lg-3 footer_col">
    <div class="footer_contact">
    <div class="footer_title">Contact Us</div>
    <div class="footer_contact_info">
    <div class="footer_contact_item">
    <div class="footer_contact_title">Address:</div>
    <div class="footer_contact_line">Abidjan Street,Wuse, P.M.B. 26, Zone 3 FCT Abuja</div>
    </div>
    <div class="footer_contact_item">
    <div class="footer_contact_title">Phone:</div>
    <div class="footer_contact_line"> 07037891156</div>
    </div>
    <div class="footer_contact_item">
    <div class="footer_contact_title">Email:</div>
    <div class="footer_contact_line">pro@customs.gov.ng</div>
    </div>
    </div>
    </div>
    </div>
    </div>
    </div>
    </footer>
    
    <script src="js/jquery-3.2.1.min.js"></script>
    <script src="styles/bootstrap4/popper.js"></script>
    <script src="styles/bootstrap4/bootstrap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/parsley.js/2.9.2/parsley.min.js"></script>
    <script src="plugins/greensock/TweenMax.min.js"></script>
    <script src="plugins/greensock/TimelineMax.min.js"></script>
    <script src="plugins/scrollmagic/ScrollMagic.min.js"></script>
    <script src="plugins/greensock/animation.gsap.min.js"></script>
    <script src="plugins/greensock/ScrollToPlugin.min.js"></script>
    <script src="plugins/OwlCarousel2-2.2.1/owl.carousel.js"></script>
    <script src="plugins/easing/easing.js"></script>
    <script src="plugins/video-js/video.min.js"></script>
    <script src="plugins/video-js/Youtube.min.js"></script>
    <script src="plugins/parallax-js-master/parallax.min.js"></script>
    <script src="js/custom.js"></script>
    <script src="js/easy-number-separator.js"></script>
    <!-- Tost-->
    <script src="assets/libs/jquery-toast-plugin/jquery.toast.min.js"></script>
    <!-- toastr init js-->
    <script src="assets/js/pages/toastr.init.js"></script>
    <!-- App js -->
    <!-- ChartJS --><!-- SweetAlert2 -->
    <script src="assets/sweetalert2/sweetalert2.min.js"></script>
    <!-- Toastr -->
    <script src="assets/toastr/toastr.min.js"></script>
    <!-- SweetAlert2 -->
    <script>
    	$(document).ready(function() {
    		//console.log( "ready!" );
    		setTimeout(function() {
    		$('#auto-close').trigger('click');
    	}, 1000);
    });
    	
        $('.btn-bid').click(function(){
        var vehicleId = $(this).attr('data-vehicleId');
        var currentBid = $(this).attr('data-currentBid');
        var windowRef = $(this).attr('data-windowRef');
        var listingId = $(this).attr('data-listingId');
        $('#bidVehicleId').val(vehicleId);
        $('#currentBid').val(currentBid);
        $('#windowRef').val(windowRef);
        $('#listingId').val(listingId);
        
    
    });
    </script>
    </body>
    </html>
    


```python
# Scraped the first items from the first nodes on the webpage
from bs4 import BeautifulSoup
import requests

# for the URL
url = 'https://auction.nigeriatradehub.gov.ng/previous_auction.php'
page = requests.get(url)
soup = BeautifulSoup(page.text, 'html.parser')

# For the items and reference numbers extraction
link_tag = soup.find('div', class_='course_tag').find('a', href=True)
url = link_tag['href']
reference_number = link_tag.text.strip()

# For the bidding prices extraction
price_tag = soup.find('div', class_='course_price').find('span')
price = price_tag.text.strip()

# For the item title extraction
title_tag = soup.find('h5', class_='card-title')
car_title = title_tag.text.strip()

# For the item condition and VIN
details_tag = soup.find('p', class_='card-text')
details = details_tag.find_all('br')

# -1 for condition and 0 for VIN
condition = details_tag.text.split('<br/>')[-1].strip()
vin = details_tag.text.split('<br/>')[0].strip().split()[-1]


# Extraction of the transmission, mileage, and fuel type [0] for transmission, [1] for mileage, [2] for fuel type 
footer_tags = soup.find_all('a', class_='d-inline-block col text-dark')
transmission = footer_tags[0].find('span').text.strip() if len(footer_tags) > 0 else 'N/A'
mileage = footer_tags[1].find('span').text.strip() if len(footer_tags) > 1 else 'N/A'
fuel_type = footer_tags[2].find('span').text.strip() if len(footer_tags) > 2 else 'N/A'

# Output the extracted information
print(f"URL: {url}")
print(f"Reference Number: {reference_number}")
print(f"Price: {price}")
print(f"Car Title: {car_title}")
print(f"Condition: {condition}")
print(f"VIN: {vin}")
print(f"Transmission: {transmission}")
print(f"Mileage: {mileage}")
print(f"Fuel Type: {fuel_type}")

```

    URL: previous_vehicle_details.php?refNo=1&itemType=Vehicle
    Reference Number: NCS/PTML/OVT/01/24/1
    Price: ₦892,000.00
    Car Title: TOYOTA CAMRY HYBRID LE 4DR SEDAN 2006
    Condition: Used 
     
    							4T1BE32K86U111063
    VIN: 4T1BE32K86U111063
    Transmission: Automatic
    Mileage: 0.00KM
    Fuel Type: Petrol
    


```python
# Tried scraping all the items from all the pages on the website but was unsuccessful
import requests
from bs4 import BeautifulSoup

# using user defined fuction to extract data from the html pages
def extract_data_from_html(html):
    soup = BeautifulSoup(html, 'html.parser')
    
    # For the items and reference numbers extraction
    link_tag = soup.find('div', class_='course_tag').find('a', href=True)
    url = link_tag['href']
    reference_number = link_tag.text.strip()

   # For the bidding prices extraction
    price_tag = soup.find('div', class_='course_price').find('span')
    price = price_tag.text.strip()

   # For the item title extraction
    title_tag = soup.find('h5', class_='card-title')
    car_title = title_tag.text.strip()

   #  For the item condition and VIN
    details_tag = soup.find('p', class_='card-text')
    details = details_tag.find_all('br')
   
   # -1 for condition and 0 for VIN
    VIN = details_tag.text.split('<br/>')[0].strip().split()[-1]
    Condition = details_tag.text.split('<br/>')[-1].strip()
    
    # # Extraction of the transmission, mileage, and fuel type [0] for transmission, [1] for mileage, [2] for fuel type 
    footer_tags = soup.find_all('a', class_='d-inline-block col text-dark')
    transmission = footer_tags[0].find('span').text.strip() if len(footer_tags) > 0 else 'N/A'
    mileage = footer_tags[1].find('span').text.strip() if len(footer_tags) > 1 else 'N/A'
    fuel_type = footer_tags[2].find('span').text.strip() if len(footer_tags) > 2 else 'N/A'

    
    return {
        'URL': url,
        'Reference Number': reference_number,
        'Price': price,
        'Car Title': car_title,
        'Condition': Condition,
        'VIN': VIN,
        'Transmission': transmission,
        'Mileage': mileage,
        'Fuel Type': fuel_type
    }

# user defined fuction to scrap the 38 pages
def scrape_multiple_pages(urls):
    data = []
    for url in urls:
        try:
            # Fetch the page
            response = requests.get(url)
            response.raise_for_status()  # Check for request errors

            # Extract data from the HTML content
            page_data = extract_data_from_html(response.text)
            data.append(page_data)

            print(f"Data extracted from {url}: {page_data}")

        except requests.RequestException as e:
            print(f"Failed to retrieve data from {url}: {e}")

    return data

# List of URLs to scrape
urls = [
    'https://auction.nigeriatradehub.gov.ng/previous_auction.php',
    'https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=2',
    'https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=3',
    'https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=4',
    'https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=5',
    'https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=6',
    'https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=7',
    'https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=8',
    'https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=9',
    'https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=10',
    'https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=11',
    'https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=12',
    'https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=13',
    'https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=14',
    'https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=15',
    'https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=16',
    'https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=17',
    'https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=18',
    'https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=19',
    'https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=20',
    'https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=21',
    'https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=22',
    'https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=23',
    'https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=24',
    'https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=25',
    'https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=26',
    'https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=27',
    'https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=28',
    'https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=29',
    'https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=30',
    'https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=31',
    'https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=32',
    'https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=33',
    'https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=34',
    'https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=35',
    'https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=36',
    'https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=37',
    'https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=38'
]

# Start scraping the data
scraped_data = scrape_multiple_pages(urls)



```

    Data extracted from https://auction.nigeriatradehub.gov.ng/previous_auction.php: {'URL': 'previous_vehicle_details.php?refNo=1&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/24/1', 'Price': '₦892,000.00', 'Car Title': 'TOYOTA CAMRY HYBRID LE 4DR SEDAN 2006', 'Condition': 'Used \n \n\t\t\t\t\t\t\t4T1BE32K86U111063', 'VIN': '4T1BE32K86U111063', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    Data extracted from https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=2: {'URL': 'previous_vehicle_details.php?refNo=37&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/24/37', 'Price': '₦450,000.00', 'Car Title': 'MAZDA MAZDA 5 2005', 'Condition': 'Used \n \n\t\t\t\t\t\t\tJMZCR198260114972', 'VIN': 'JMZCR198260114972', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    Data extracted from https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=3: {'URL': 'previous_vehicle_details.php?refNo=72&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/24/72', 'Price': '₦450,000.00', 'Car Title': 'LEXUS ES 300H LUXURY 4DR SEDAN 2002', 'Condition': 'Used \n \n\t\t\t\t\t\t\tJTHBF30G120074373', 'VIN': 'JTHBF30G120074373', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    Data extracted from https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=4: {'URL': 'previous_vehicle_details.php?refNo=106&itemType=Vehicle', 'Reference Number': 'NCS/OVT/PTML/01/2024/106', 'Price': '₦865,000.00', 'Car Title': 'PEUGEOT  307 2004', 'Condition': 'Used \n \n\t\t\t\t\t\t\tVF33HNFUC83284259', 'VIN': 'VF33HNFUC83284259', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    Data extracted from https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=5: {'URL': 'previous_vehicle_details.php?refNo=140&itemType=Vehicle', 'Reference Number': 'NCS/OVT/PTML/01/2024/140', 'Price': '₦420,000.00', 'Car Title': 'ACURA TL  TL 2003', 'Condition': 'Used \n \n\t\t\t\t\t\t\t19UUA56883A027200', 'VIN': '19UUA56883A027200', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    Data extracted from https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=6: {'URL': 'previous_vehicle_details.php?refNo=174&itemType=Vehicle', 'Reference Number': 'NCS/OVT/PTML/01/2024/174', 'Price': '₦637,800.00', 'Car Title': 'HONDA   PILOT 2005', 'Condition': 'Used \n \n\t\t\t\t\t\t\t5FNYF18485B006197', 'VIN': '5FNYF18485B006197', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    Data extracted from https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=7: {'URL': 'previous_vehicle_details.php?refNo=295&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/2024/295', 'Price': '₦1,400,000.00', 'Car Title': 'HONDA ODYSSEY 2005', 'Condition': 'Used \n \n\t\t\t\t\t\t\t5FNRL38605B409892', 'VIN': '5FNRL38605B409892', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    Data extracted from https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=8: {'URL': 'previous_vehicle_details.php?refNo=249&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/2024/249', 'Price': '₦860,000.00', 'Car Title': 'TOYOTA HIGHLANDER 2005', 'Condition': 'Used \n \n\t\t\t\t\t\t\tJTEEP21A550092973', 'VIN': 'JTEEP21A550092973', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    Data extracted from https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=9: {'URL': 'container_details.php?refNo=4&itemType=Container', 'Reference Number': 'NCS/TCIP/OVT/03/2024/4', 'Price': '₦8,700,000.00', 'Car Title': 'CSNU6999438', 'Condition': '0KG \n \n        \t\t\t\t\t\t\t1x40ft \n \n        \t\t\t\t\t\t\tTINCAN ISLAND PORT AREA COMMAND\n \n        \t\t\t\t\t\t\tNigeria', 'VIN': 'Nigeria', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    Data extracted from https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=10: {'URL': 'previous_vehicle_details.php?refNo=345&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/02/2024/345', 'Price': '₦1,400,000.00', 'Car Title': 'MERCEDES C 280 1999', 'Condition': 'Used \n \n\t\t\t\t\t\t\tWDBHA29G1XA727887', 'VIN': 'WDBHA29G1XA727887', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    Data extracted from https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=11: {'URL': 'previous_vehicle_details.php?refNo=307&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/02/2024/307', 'Price': '₦600,000.00', 'Car Title': 'NISSAN  PRIMERA 2000', 'Condition': 'Used \n \n\t\t\t\t\t\t\tSJNFAAP11U0493474', 'VIN': 'SJNFAAP11U0493474', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    Data extracted from https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=12: {'URL': 'container_details.php?refNo=23&itemType=Container', 'Reference Number': 'NCS/TCIP/OVT/03/2024/23', 'Price': '₦5,111,111.00', 'Car Title': 'MSCU7642396', 'Condition': '0KG \n \n        \t\t\t\t\t\t\t1x40ft \n \n        \t\t\t\t\t\t\tTINCAN ISLAND PORT AREA COMMAND\n \n        \t\t\t\t\t\t\tNigeria', 'VIN': 'Nigeria', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    Data extracted from https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=13: {'URL': 'previous_vehicle_details.php?refNo=128&itemType=Vehicle', 'Reference Number': 'NCS/OVT/PTML/01/2024/128', 'Price': '₦624,000.00', 'Car Title': 'MITSUBISHI   GALANT 1996', 'Condition': 'Used \n \n\t\t\t\t\t\t\tJMBLNE52ATZ000591', 'VIN': 'JMBLNE52ATZ000591', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    Data extracted from https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=14: {'URL': 'previous_vehicle_details.php?refNo=416&itemType=Vehicle', 'Reference Number': 'NCS/01TC/OVT/02/2024/416', 'Price': '₦1,250,000.00', 'Car Title': 'LEXUS  RX 300 1999', 'Condition': 'Used \n \n\t\t\t\t\t\t\tJT6HF10U8X0021044', 'VIN': 'JT6HF10U8X0021044', 'Transmission': 'AUTOMATIC', 'Mileage': '0.00KM', 'Fuel Type': 'NIL'}
    Data extracted from https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=15: {'URL': 'previous_vehicle_details.php?refNo=451&itemType=Vehicle', 'Reference Number': 'NCS/01TC/OVT/02/2024/451', 'Price': '₦365,000.00', 'Car Title': 'TOYOTA AVALON 2003', 'Condition': 'Used \n \n\t\t\t\t\t\t\t4T1BF28B43U303753', 'VIN': '4T1BF28B43U303753', 'Transmission': 'AUTOMATIC', 'Mileage': '0.00KM', 'Fuel Type': 'NIL'}
    Data extracted from https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=16: {'URL': 'previous_vehicle_details.php?refNo=480&itemType=Vehicle', 'Reference Number': 'NCS/01TC/OVT/02/2024/480', 'Price': '₦2,100,000.00', 'Car Title': 'TOYOTA COROLLA 2007', 'Condition': 'Used \n \n\t\t\t\t\t\t\t2T1BR32E17C762567', 'VIN': '2T1BR32E17C762567', 'Transmission': 'AUTOMATIC', 'Mileage': '0.00KM', 'Fuel Type': 'NIL'}
    Data extracted from https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=17: {'URL': 'previous_vehicle_details.php?refNo=506&itemType=Vehicle', 'Reference Number': 'NCS/01TC/OVT/02/2024/506', 'Price': '₦800,000.00', 'Car Title': 'AUDI   ALLROAD 2002', 'Condition': 'Used \n \n\t\t\t\t\t\t\tWA1YD64B82N120800', 'VIN': 'WA1YD64B82N120800', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    Data extracted from https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=18: {'URL': 'container_details.php?refNo=75&itemType=Container', 'Reference Number': 'NCS/TCIP/OVT/03/2024/75', 'Price': '₦1,901,111.00', 'Car Title': 'MSCU1835778', 'Condition': '0KG \n \n        \t\t\t\t\t\t\t1x20ft \n \n        \t\t\t\t\t\t\tAPAPA AREA COMMAND\n \n        \t\t\t\t\t\t\tNigeria', 'VIN': 'Nigeria', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    Data extracted from https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=19: {'URL': 'previous_vehicle_details.php?refNo=536&itemType=Vehicle', 'Reference Number': 'NCS/01AP/OVT/03/2024/536', 'Price': '₦620,000.00', 'Car Title': '2004 RENAULT MEGANE MEGANE 2004', 'Condition': 'Used \n \n\t\t\t\t\t\t\tVF1BMRF0531656771', 'VIN': 'VF1BMRF0531656771', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    Data extracted from https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=20: {'URL': 'previous_vehicle_details.php?refNo=574&itemType=Vehicle', 'Reference Number': 'NCS/01TC/OVT/03/2024/574', 'Price': '₦490,000.00', 'Car Title': 'TOYOTA AVALON 2000', 'Condition': 'Used \n \n\t\t\t\t\t\t\t4TBF28B0YU080019', 'VIN': '4TBF28B0YU080019', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    Data extracted from https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=21: {'URL': 'previous_vehicle_details.php?refNo=611&itemType=Vehicle', 'Reference Number': 'NCS/01TC/OVT/03/2024/611', 'Price': '₦2,000,000.00', 'Car Title': 'HONDA ACCORD 0', 'Condition': 'Used \n \n\t\t\t\t\t\t\tA003789', 'VIN': 'A003789', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    Data extracted from https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=22: {'URL': 'previous_vehicle_details.php?refNo=668&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/03/2024/668', 'Price': '₦1,130,000.00', 'Car Title': 'HYUNDAI  SANTAFE 1994', 'Condition': 'Used \n \n\t\t\t\t\t\t\tKMHSC81ARU121964', 'VIN': 'KMHSC81ARU121964', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    Data extracted from https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=23: {'URL': 'container_details.php?refNo=103&itemType=Container', 'Reference Number': 'NCS/PTML/OVT/03/2024/103', 'Price': '₦1,600,000.00', 'Car Title': 'PIDU4056232', 'Condition': '0KG \n \n        \t\t\t\t\t\t\t1x40ft \n \n        \t\t\t\t\t\t\tPORT TERMINAL MULTISERVICES LIMITED (PTML) AREA COMMAND\n \n        \t\t\t\t\t\t\tNigeria', 'VIN': 'Nigeria', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    Data extracted from https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=24: {'URL': 'previous_vehicle_details.php?refNo=705&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/03/2024/705', 'Price': '₦750,000.00', 'Car Title': 'TOYOTA 4Runner 2002', 'Condition': 'Used \n \n\t\t\t\t\t\t\tJT3GN87R2W0062564', 'VIN': 'JT3GN87R2W0062564', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    Data extracted from https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=25: {'URL': 'previous_vehicle_details.php?refNo=737&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/04/2024/737', 'Price': '₦756,320.00', 'Car Title': 'FORD E250 ECONOLINE VAN 2005', 'Condition': 'Used \n \n\t\t\t\t\t\t\t1FTNE24L35HA80183', 'VIN': '1FTNE24L35HA80183', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    Data extracted from https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=26: {'URL': 'previous_vehicle_details.php?refNo=769&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/04/2024/769', 'Price': '₦860,989.00', 'Car Title': 'SATURN VUE 2009', 'Condition': 'Used \n \n\t\t\t\t\t\t\t3GSDL43N79S562141', 'VIN': '3GSDL43N79S562141', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    Data extracted from https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=27: {'URL': 'previous_vehicle_details.php?refNo=802&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/04/2024/802', 'Price': '₦550,000.00', 'Car Title': 'CHRYSLER PACIFICA 2006', 'Condition': 'Used \n \n\t\t\t\t\t\t\t2A8GF68446R698594', 'VIN': '2A8GF68446R698594', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    Data extracted from https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=28: {'URL': 'previous_vehicle_details.php?refNo=834&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/04/2024/834', 'Price': '₦580,000.00', 'Car Title': 'TOYOTA CAMRY LE 2001', 'Condition': 'Used \n \n\t\t\t\t\t\t\t4T1BG22K614068579', 'VIN': '4T1BG22K614068579', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    Data extracted from https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=29: {'URL': 'previous_vehicle_details.php?refNo=866&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/04/2024/866', 'Price': '₦520,000.00', 'Car Title': 'MERCEDES BENZ C240 0', 'Condition': 'Used \n \n\t\t\t\t\t\t\t569606', 'VIN': '569606', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    Data extracted from https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=30: {'URL': 'previous_vehicle_details.php?refNo=901&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/05/2024/901', 'Price': '₦560,000.00', 'Car Title': 'OPEL VECTRA 1998', 'Condition': 'Used \n \n\t\t\t\t\t\t\tW0L0JBF19W1032590', 'VIN': 'W0L0JBF19W1032590', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    Data extracted from https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=31: {'URL': 'previous_vehicle_details.php?refNo=935&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/05/2024/935', 'Price': '₦803,000.00', 'Car Title': 'LEXUS  GS350 2008', 'Condition': 'Used \n \n\t\t\t\t\t\t\tJTHBE96S980030230', 'VIN': 'JTHBE96S980030230', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    Data extracted from https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=32: {'URL': 'previous_vehicle_details.php?refNo=967&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/06/2024/967', 'Price': '₦666,666.00', 'Car Title': 'HONDA  ACCORD 1992', 'Condition': 'Used \n \n\t\t\t\t\t\t\t1HGCB7555NA232679', 'VIN': '1HGCB7555NA232679', 'Transmission': 'AUTOMATIC', 'Mileage': '0.00KM', 'Fuel Type': 'PETROL'}
    Data extracted from https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=33: {'URL': 'previous_vehicle_details.php?refNo=999&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/06/2024/999', 'Price': '₦1,420,000.00', 'Car Title': 'FORD  RANGER 2001', 'Condition': 'Used \n \n\t\t\t\t\t\t\t1FTYR14E41TA23141', 'VIN': '1FTYR14E41TA23141', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    Data extracted from https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=34: {'URL': 'previous_vehicle_details.php?refNo=1031&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/06/2024/1031', 'Price': '₦1,200,000.00', 'Car Title': 'MERCEDEZ BENZ  E320 0', 'Condition': 'Used \n \n\t\t\t\t\t\t\t681232', 'VIN': '681232', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    Data extracted from https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=35: {'URL': 'previous_vehicle_details.php?refNo=1081&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/07/2024/1081', 'Price': '₦620,000.00', 'Car Title': 'NISSAN XTERRA 0', 'Condition': 'Used \n \n\t\t\t\t\t\t\t508099', 'VIN': '508099', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    Data extracted from https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=36: {'URL': 'previous_vehicle_details.php?refNo=1095&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/07/2024/1095', 'Price': '₦1,000,000.00', 'Car Title': 'FORD  GALAXY 1998', 'Condition': 'Used \n \n\t\t\t\t\t\t\tWF0GXXPSWGTG40874', 'VIN': 'WF0GXXPSWGTG40874', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    Data extracted from https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=37: {'URL': 'previous_vehicle_details.php?refNo=1128&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/07/2024/1128', 'Price': '₦1,146,504.33', 'Car Title': 'VOLKSWAGEN  PASSAT 2006', 'Condition': 'Used \n \n\t\t\t\t\t\t\tWVWAK73C16P137817', 'VIN': 'WVWAK73C16P137817', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    Data extracted from https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=38: {'URL': 'previous_vehicle_details.php?refNo=1161&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/08/2024/1161', 'Price': '₦1,200,000.00', 'Car Title': 'TOYOTA  COROLLA 2005', 'Condition': 'Used \n \n\t\t\t\t\t\t\t536465', 'VIN': '536465', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    


```python
# imported the pandas library
import pandas as pd

auction = pd.DataFrame(scraped_data)
print(auction)
```

                                                      URL  \
    0   previous_vehicle_details.php?refNo=1&itemType=...   
    1   previous_vehicle_details.php?refNo=37&itemType...   
    2   previous_vehicle_details.php?refNo=72&itemType...   
    3   previous_vehicle_details.php?refNo=106&itemTyp...   
    4   previous_vehicle_details.php?refNo=140&itemTyp...   
    5   previous_vehicle_details.php?refNo=174&itemTyp...   
    6   previous_vehicle_details.php?refNo=295&itemTyp...   
    7   previous_vehicle_details.php?refNo=249&itemTyp...   
    8    container_details.php?refNo=4&itemType=Container   
    9   previous_vehicle_details.php?refNo=345&itemTyp...   
    10  previous_vehicle_details.php?refNo=307&itemTyp...   
    11  container_details.php?refNo=23&itemType=Container   
    12  previous_vehicle_details.php?refNo=128&itemTyp...   
    13  previous_vehicle_details.php?refNo=416&itemTyp...   
    14  previous_vehicle_details.php?refNo=451&itemTyp...   
    15  previous_vehicle_details.php?refNo=480&itemTyp...   
    16  previous_vehicle_details.php?refNo=506&itemTyp...   
    17  container_details.php?refNo=75&itemType=Container   
    18  previous_vehicle_details.php?refNo=536&itemTyp...   
    19  previous_vehicle_details.php?refNo=574&itemTyp...   
    20  previous_vehicle_details.php?refNo=611&itemTyp...   
    21  previous_vehicle_details.php?refNo=668&itemTyp...   
    22  container_details.php?refNo=103&itemType=Conta...   
    23  previous_vehicle_details.php?refNo=705&itemTyp...   
    24  previous_vehicle_details.php?refNo=737&itemTyp...   
    25  previous_vehicle_details.php?refNo=769&itemTyp...   
    26  previous_vehicle_details.php?refNo=802&itemTyp...   
    27  previous_vehicle_details.php?refNo=834&itemTyp...   
    28  previous_vehicle_details.php?refNo=866&itemTyp...   
    29  previous_vehicle_details.php?refNo=901&itemTyp...   
    30  previous_vehicle_details.php?refNo=935&itemTyp...   
    31  previous_vehicle_details.php?refNo=967&itemTyp...   
    32  previous_vehicle_details.php?refNo=999&itemTyp...   
    33  previous_vehicle_details.php?refNo=1031&itemTy...   
    34  previous_vehicle_details.php?refNo=1081&itemTy...   
    35  previous_vehicle_details.php?refNo=1095&itemTy...   
    36  previous_vehicle_details.php?refNo=1128&itemTy...   
    37  previous_vehicle_details.php?refNo=1161&itemTy...   
    
                 Reference Number          Price  \
    0        NCS/PTML/OVT/01/24/1    ₦892,000.00   
    1       NCS/PTML/OVT/01/24/37    ₦450,000.00   
    2       NCS/PTML/OVT/01/24/72    ₦450,000.00   
    3    NCS/OVT/PTML/01/2024/106    ₦865,000.00   
    4    NCS/OVT/PTML/01/2024/140    ₦420,000.00   
    5    NCS/OVT/PTML/01/2024/174    ₦637,800.00   
    6    NCS/PTML/OVT/01/2024/295  ₦1,400,000.00   
    7    NCS/PTML/OVT/01/2024/249    ₦860,000.00   
    8      NCS/TCIP/OVT/03/2024/4  ₦8,700,000.00   
    9    NCS/PTML/OVT/02/2024/345  ₦1,400,000.00   
    10   NCS/PTML/OVT/02/2024/307    ₦600,000.00   
    11    NCS/TCIP/OVT/03/2024/23  ₦5,111,111.00   
    12   NCS/OVT/PTML/01/2024/128    ₦624,000.00   
    13   NCS/01TC/OVT/02/2024/416  ₦1,250,000.00   
    14   NCS/01TC/OVT/02/2024/451    ₦365,000.00   
    15   NCS/01TC/OVT/02/2024/480  ₦2,100,000.00   
    16   NCS/01TC/OVT/02/2024/506    ₦800,000.00   
    17    NCS/TCIP/OVT/03/2024/75  ₦1,901,111.00   
    18   NCS/01AP/OVT/03/2024/536    ₦620,000.00   
    19   NCS/01TC/OVT/03/2024/574    ₦490,000.00   
    20   NCS/01TC/OVT/03/2024/611  ₦2,000,000.00   
    21   NCS/TCIP/OVT/03/2024/668  ₦1,130,000.00   
    22   NCS/PTML/OVT/03/2024/103  ₦1,600,000.00   
    23   NCS/TCIP/OVT/03/2024/705    ₦750,000.00   
    24   NCS/PTML/OVT/04/2024/737    ₦756,320.00   
    25   NCS/PTML/OVT/04/2024/769    ₦860,989.00   
    26   NCS/PTML/OVT/04/2024/802    ₦550,000.00   
    27   NCS/PTML/OVT/04/2024/834    ₦580,000.00   
    28   NCS/PTML/OVT/04/2024/866    ₦520,000.00   
    29   NCS/TCIP/OVT/05/2024/901    ₦560,000.00   
    30   NCS/TCIP/OVT/05/2024/935    ₦803,000.00   
    31   NCS/TCIP/OVT/06/2024/967    ₦666,666.00   
    32   NCS/TCIP/OVT/06/2024/999  ₦1,420,000.00   
    33  NCS/TCIP/OVT/06/2024/1031  ₦1,200,000.00   
    34  NCS/TCIP/OVT/07/2024/1081    ₦620,000.00   
    35  NCS/TCIP/OVT/07/2024/1095  ₦1,000,000.00   
    36  NCS/TCIP/OVT/07/2024/1128  ₦1,146,504.33   
    37  NCS/PTML/OVT/08/2024/1161  ₦1,200,000.00   
    
                                    Car Title  \
    0   TOYOTA CAMRY HYBRID LE 4DR SEDAN 2006   
    1                      MAZDA MAZDA 5 2005   
    2     LEXUS ES 300H LUXURY 4DR SEDAN 2002   
    3                       PEUGEOT  307 2004   
    4                       ACURA TL  TL 2003   
    5                      HONDA   PILOT 2005   
    6                      HONDA ODYSSEY 2005   
    7                  TOYOTA HIGHLANDER 2005   
    8                             CSNU6999438   
    9                     MERCEDES C 280 1999   
    10                   NISSAN  PRIMERA 2000   
    11                            MSCU7642396   
    12               MITSUBISHI   GALANT 1996   
    13                     LEXUS  RX 300 1999   
    14                     TOYOTA AVALON 2003   
    15                    TOYOTA COROLLA 2007   
    16                    AUDI   ALLROAD 2002   
    17                            MSCU1835778   
    18        2004 RENAULT MEGANE MEGANE 2004   
    19                     TOYOTA AVALON 2000   
    20                         HONDA ACCORD 0   
    21                  HYUNDAI  SANTAFE 1994   
    22                            PIDU4056232   
    23                    TOYOTA 4Runner 2002   
    24           FORD E250 ECONOLINE VAN 2005   
    25                        SATURN VUE 2009   
    26                 CHRYSLER PACIFICA 2006   
    27                   TOYOTA CAMRY LE 2001   
    28                   MERCEDES BENZ C240 0   
    29                       OPEL VECTRA 1998   
    30                      LEXUS  GS350 2008   
    31                     HONDA  ACCORD 1992   
    32                      FORD  RANGER 2001   
    33                  MERCEDEZ BENZ  E320 0   
    34                        NISSAN XTERRA 0   
    35                      FORD  GALAXY 1998   
    36                VOLKSWAGEN  PASSAT 2006   
    37                   TOYOTA  COROLLA 2005   
    
                                                Condition                VIN  \
    0           Used \n \n\t\t\t\t\t\t\t4T1BE32K86U111063  4T1BE32K86U111063   
    1           Used \n \n\t\t\t\t\t\t\tJMZCR198260114972  JMZCR198260114972   
    2           Used \n \n\t\t\t\t\t\t\tJTHBF30G120074373  JTHBF30G120074373   
    3           Used \n \n\t\t\t\t\t\t\tVF33HNFUC83284259  VF33HNFUC83284259   
    4           Used \n \n\t\t\t\t\t\t\t19UUA56883A027200  19UUA56883A027200   
    5           Used \n \n\t\t\t\t\t\t\t5FNYF18485B006197  5FNYF18485B006197   
    6           Used \n \n\t\t\t\t\t\t\t5FNRL38605B409892  5FNRL38605B409892   
    7           Used \n \n\t\t\t\t\t\t\tJTEEP21A550092973  JTEEP21A550092973   
    8   0KG \n \n        \t\t\t\t\t\t\t1x40ft \n \n   ...            Nigeria   
    9           Used \n \n\t\t\t\t\t\t\tWDBHA29G1XA727887  WDBHA29G1XA727887   
    10          Used \n \n\t\t\t\t\t\t\tSJNFAAP11U0493474  SJNFAAP11U0493474   
    11  0KG \n \n        \t\t\t\t\t\t\t1x40ft \n \n   ...            Nigeria   
    12          Used \n \n\t\t\t\t\t\t\tJMBLNE52ATZ000591  JMBLNE52ATZ000591   
    13          Used \n \n\t\t\t\t\t\t\tJT6HF10U8X0021044  JT6HF10U8X0021044   
    14          Used \n \n\t\t\t\t\t\t\t4T1BF28B43U303753  4T1BF28B43U303753   
    15          Used \n \n\t\t\t\t\t\t\t2T1BR32E17C762567  2T1BR32E17C762567   
    16          Used \n \n\t\t\t\t\t\t\tWA1YD64B82N120800  WA1YD64B82N120800   
    17  0KG \n \n        \t\t\t\t\t\t\t1x20ft \n \n   ...            Nigeria   
    18          Used \n \n\t\t\t\t\t\t\tVF1BMRF0531656771  VF1BMRF0531656771   
    19           Used \n \n\t\t\t\t\t\t\t4TBF28B0YU080019   4TBF28B0YU080019   
    20                    Used \n \n\t\t\t\t\t\t\tA003789            A003789   
    21           Used \n \n\t\t\t\t\t\t\tKMHSC81ARU121964   KMHSC81ARU121964   
    22  0KG \n \n        \t\t\t\t\t\t\t1x40ft \n \n   ...            Nigeria   
    23          Used \n \n\t\t\t\t\t\t\tJT3GN87R2W0062564  JT3GN87R2W0062564   
    24          Used \n \n\t\t\t\t\t\t\t1FTNE24L35HA80183  1FTNE24L35HA80183   
    25          Used \n \n\t\t\t\t\t\t\t3GSDL43N79S562141  3GSDL43N79S562141   
    26          Used \n \n\t\t\t\t\t\t\t2A8GF68446R698594  2A8GF68446R698594   
    27          Used \n \n\t\t\t\t\t\t\t4T1BG22K614068579  4T1BG22K614068579   
    28                     Used \n \n\t\t\t\t\t\t\t569606             569606   
    29          Used \n \n\t\t\t\t\t\t\tW0L0JBF19W1032590  W0L0JBF19W1032590   
    30          Used \n \n\t\t\t\t\t\t\tJTHBE96S980030230  JTHBE96S980030230   
    31          Used \n \n\t\t\t\t\t\t\t1HGCB7555NA232679  1HGCB7555NA232679   
    32          Used \n \n\t\t\t\t\t\t\t1FTYR14E41TA23141  1FTYR14E41TA23141   
    33                     Used \n \n\t\t\t\t\t\t\t681232             681232   
    34                     Used \n \n\t\t\t\t\t\t\t508099             508099   
    35          Used \n \n\t\t\t\t\t\t\tWF0GXXPSWGTG40874  WF0GXXPSWGTG40874   
    36          Used \n \n\t\t\t\t\t\t\tWVWAK73C16P137817  WVWAK73C16P137817   
    37                     Used \n \n\t\t\t\t\t\t\t536465             536465   
    
       Transmission Mileage Fuel Type  
    0     Automatic  0.00KM    Petrol  
    1     Automatic  0.00KM    Petrol  
    2     Automatic  0.00KM    Petrol  
    3     Automatic  0.00KM    Petrol  
    4     Automatic  0.00KM    Petrol  
    5     Automatic  0.00KM    Petrol  
    6     Automatic  0.00KM    Petrol  
    7     Automatic  0.00KM    Petrol  
    8     Automatic  0.00KM    Petrol  
    9     Automatic  0.00KM    Petrol  
    10    Automatic  0.00KM    Petrol  
    11    Automatic  0.00KM    Petrol  
    12    Automatic  0.00KM    Petrol  
    13    AUTOMATIC  0.00KM       NIL  
    14    AUTOMATIC  0.00KM       NIL  
    15    AUTOMATIC  0.00KM       NIL  
    16    Automatic  0.00KM    Petrol  
    17    Automatic  0.00KM    Petrol  
    18    Automatic  0.00KM    Petrol  
    19    Automatic  0.00KM    Petrol  
    20    Automatic  0.00KM    Petrol  
    21    Automatic  0.00KM    Petrol  
    22    Automatic  0.00KM    Petrol  
    23    Automatic  0.00KM    Petrol  
    24    Automatic  0.00KM    Petrol  
    25    Automatic  0.00KM    Petrol  
    26    Automatic  0.00KM    Petrol  
    27    Automatic  0.00KM    Petrol  
    28    Automatic  0.00KM    Petrol  
    29    Automatic  0.00KM    Petrol  
    30    Automatic  0.00KM    Petrol  
    31    AUTOMATIC  0.00KM    PETROL  
    32    Automatic  0.00KM    Petrol  
    33    Automatic  0.00KM    Petrol  
    34    Automatic  0.00KM    Petrol  
    35    Automatic  0.00KM    Petrol  
    36    Automatic  0.00KM    Petrol  
    37    Automatic  0.00KM    Petrol  
    


```python
# Edited my code to scrap all the data from the website 
import requests
from bs4 import BeautifulSoup
import pandas as pd

def extract_data_from_html(html):
    soup = BeautifulSoup(html, 'html.parser')
    data = []

    # Find all the blocks that contain the information in each node from all the 38 pages
    car_blocks = soup.find_all('div', class_='card')

    for block in car_blocks:
        # For the items and reference numbers extraction
        link_tag = block.find('div', class_='course_tag').find('a', href=True)
        url = link_tag['href']
        reference_number = link_tag.text.strip()

        # For the bidding prices extraction
        price_tag = block.find('div', class_='course_price').find('span')
        price = price_tag.text.strip()

        # For the item title extraction
        title_tag = block.find('h5', class_='card-title')
        car_title = title_tag.text.strip()

        #  For the item condition and VIN
        details_tag = block.find('p', class_='card-text')
        details = details_tag.get_text(separator=' ').strip().split()
        
        #-1 for condition and 0 for VIN
        vin = details[0] if len(details) > 0 else 'N/A'
        condition = details[-1] if len(details) > 1 else 'N/A'

         # # Extraction of the transmission, mileage, and fuel type [0] for transmission, [1] for mileage, [2] for fuel type 
        footer_tags = block.find_all('a', class_='d-inline-block col text-dark')
        transmission = footer_tags[0].find('span').text.strip() if len(footer_tags) > 0 else 'N/A'
        mileage = footer_tags[1].find('span').text.strip() if len(footer_tags) > 1 else 'N/A'
        fuel_type = footer_tags[2].find('span').text.strip() if len(footer_tags) > 2 else 'N/A'

        # after getting the data show the results below
        data.append({
            'URL': url,
            'Reference Number': reference_number,
            'Price': price,
            'Car Title': car_title,
            'Condition': condition,
            'VIN': vin,
            'Transmission': transmission,
            'Mileage': mileage,
            'Fuel Type': fuel_type
        })

    return data

def scrape_multiple_pages(urls):
    all_data = []
    
    # run a for loop in the urls 
    for url in urls:
        try:
            response = requests.get(url)
            response.raise_for_status()  # Check for request errors

            page_data = extract_data_from_html(response.text)
            all_data.extend(page_data)

            print(f"Data extracted from {url}")

        except requests.RequestException as e:
            print(f"Failed to retrieve data from {url}: {e}")

    return all_data

# List of URLs to scrape
urls = [
    'https://auction.nigeriatradehub.gov.ng/previous_auction.php',
    'https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=2',
    'https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=3',
    'https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=4',
    'https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=5',
    'https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=6',
    'https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=7',
    'https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=8',
    'https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=9',
    'https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=10',
    'https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=11',
    'https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=12',
    'https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=13',
    'https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=14',
    'https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=15',
    'https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=16',
    'https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=17',
    'https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=18',
    'https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=19',
    'https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=20',
    'https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=21',
    'https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=22',
    'https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=23',
    'https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=24',
    'https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=25',
    'https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=26',
    'https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=27',
    'https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=28',
    'https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=29',
    'https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=30',
    'https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=31',
    'https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=32',
    'https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=33',
    'https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=34',
    'https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=35',
    'https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=36',
    'https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=37',
    'https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=38'
    # Add more URLs as needed
]

# Start the scraping process
scraped_data = scrape_multiple_pages(urls)
```

    Data extracted from https://auction.nigeriatradehub.gov.ng/previous_auction.php
    Data extracted from https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=2
    Data extracted from https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=3
    Data extracted from https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=4
    Data extracted from https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=5
    Data extracted from https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=6
    Data extracted from https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=7
    Data extracted from https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=8
    Data extracted from https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=9
    Data extracted from https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=10
    Data extracted from https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=11
    Data extracted from https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=12
    Data extracted from https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=13
    Data extracted from https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=14
    Data extracted from https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=15
    Data extracted from https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=16
    Data extracted from https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=17
    Data extracted from https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=18
    Data extracted from https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=19
    Data extracted from https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=20
    Data extracted from https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=21
    Data extracted from https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=22
    Data extracted from https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=23
    Data extracted from https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=24
    Data extracted from https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=25
    Data extracted from https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=26
    Data extracted from https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=27
    Data extracted from https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=28
    Data extracted from https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=29
    Data extracted from https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=30
    Data extracted from https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=31
    Data extracted from https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=32
    Data extracted from https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=33
    Data extracted from https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=34
    Data extracted from https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=35
    Data extracted from https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=36
    Data extracted from https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=37
    Data extracted from https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=38
    


```python
# After scraping, printed the data to the console
scrapped_data = scrape_multiple_pages(urls)

# Print the extracted data
for entry in scrapped_data:
    print(entry)
```

    Data extracted from https://auction.nigeriatradehub.gov.ng/previous_auction.php
    Data extracted from https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=2
    Data extracted from https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=3
    Data extracted from https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=4
    Data extracted from https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=5
    Data extracted from https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=6
    Data extracted from https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=7
    Data extracted from https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=8
    Data extracted from https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=9
    Data extracted from https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=10
    Data extracted from https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=11
    Data extracted from https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=12
    Data extracted from https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=13
    Data extracted from https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=14
    Data extracted from https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=15
    Data extracted from https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=16
    Data extracted from https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=17
    Data extracted from https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=18
    Data extracted from https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=19
    Data extracted from https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=20
    Data extracted from https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=21
    Data extracted from https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=22
    Data extracted from https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=23
    Data extracted from https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=24
    Data extracted from https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=25
    Data extracted from https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=26
    Data extracted from https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=27
    Data extracted from https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=28
    Data extracted from https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=29
    Data extracted from https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=30
    Data extracted from https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=31
    Data extracted from https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=32
    Data extracted from https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=33
    Data extracted from https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=34
    Data extracted from https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=35
    Data extracted from https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=36
    Data extracted from https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=37
    Data extracted from https://auction.nigeriatradehub.gov.ng/previous_auction.php?page=38
    {'URL': 'previous_vehicle_details.php?refNo=1&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/24/1', 'Price': '₦892,000.00', 'Car Title': 'TOYOTA CAMRY HYBRID LE 4DR SEDAN 2006', 'Condition': '4T1BE32K86U111063', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=2&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/24/2', 'Price': '₦500,000.00', 'Car Title': 'ACURA TL 2004', 'Condition': '19UUA66214A013030', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=3&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/24/3', 'Price': '₦420,000.00', 'Car Title': 'HONDA ACCORD EX 1.5T 4DR SEDAN 2004', 'Condition': '1HGCM66554A098192', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=4&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/24/4', 'Price': '₦800,000.00', 'Car Title': 'TOYOTA COROLLA L 4DR SEDAN 2007', 'Condition': '2T1BR32E27C777272', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=5&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/24/5', 'Price': '₦715,000.00', 'Car Title': 'PEUGEOT 307 2008', 'Condition': 'VF33CNFUL84568049', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=6&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/24/6', 'Price': '₦410,000.00', 'Car Title': 'VOLKSWAGEN POLO 70 TSI TRENDLINE 2001', 'Condition': 'WVWZZZ6NZ1Y237873', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=7&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/24/7', 'Price': '₦467,000.00', 'Car Title': 'BMW 330I 4DR REAR-WHEEL DRIVE SEDAN 2011', 'Condition': 'WBAKF9C59BE262301', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=8&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/24/8', 'Price': '₦531,001.00', 'Car Title': 'MAZDA PREMACY 2003', 'Condition': 'JMZCP19F231338331', 'VIN': 'Used', 'Transmission': 'Manual', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=11&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/24/11', 'Price': '₦2,100,000.00', 'Car Title': 'HONDA ACCORD EX 4DR SEDAN 2014', 'Condition': '1HGCR3F82EA037331', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=12&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/24/12', 'Price': '₦651,000.00', 'Car Title': 'HONDA ACCORD EX 1.5T 4DR SEDAN 2006', 'Condition': '1HGCM56856A178616', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=13&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/24/13', 'Price': '₦400,900.00', 'Car Title': 'HONDA CIVIC EX 4DR SEDAN 2004', 'Condition': '1HGEM219X4L011483', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=14&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/24/14', 'Price': '₦2,750,000.00', 'Car Title': 'LEXUS GS 300 BASE 4DR REAR-WHEEL DRIVE SEDAN 2006', 'Condition': 'JTHCH96S360012332', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=15&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/24/15', 'Price': '₦610,000.00', 'Car Title': 'BMW 325XI 2006', 'Condition': 'WBAVD13556KV06571', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=17&itemType=Vehicle', 'Reference Number': 'NCS/PH I/OVT/01/24/17', 'Price': '₦405,500.00', 'Car Title': 'VOLVO S80 2010', 'Condition': 'YV1960AS9A1116244', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=18&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/24/18', 'Price': '₦550,000.00', 'Car Title': 'MERCEDES-BENZ C240 2005', 'Condition': 'WDBRF81J95F631019', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': ''}
    {'URL': 'previous_vehicle_details.php?refNo=21&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/24/21', 'Price': '₦500,000.00', 'Car Title': 'PEUGEOT 406 2001', 'Condition': 'VF38BRFNA18007629', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=19&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/24/19', 'Price': '₦600,000.00', 'Car Title': 'HONDA ACCORD EX 1.5T 4DR SEDAN 2007', 'Condition': '1HGCM665X7A090545', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=20&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/24/20', 'Price': '₦455,000.00', 'Car Title': 'TOYOTA CAMRY L 4DR FRONT-WHEEL DRIVE SEDAN 2002', 'Condition': 'JTDBE32K420028817', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=22&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/24/22', 'Price': '₦1,800,000.00', 'Car Title': 'TOYOTA YARIS SEDAN L 4DR SEDAN 2007', 'Condition': 'JTDJT923175085645', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': ''}
    {'URL': 'previous_vehicle_details.php?refNo=24&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/24/24', 'Price': '₦540,000.00', 'Car Title': 'MERCEDES-BENZ C180 2006', 'Condition': 'WDB2030351F066544', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=25&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/24/25', 'Price': '₦425,000.00', 'Car Title': 'MERCEDES-BENZ C180 2002', 'Condition': 'WDB2032461F351760', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': ''}
    {'URL': 'previous_vehicle_details.php?refNo=26&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/24/26', 'Price': '₦401,000.00', 'Car Title': 'NISSAN 37OZ BASE 2DR COUPE 2009', 'Condition': '3N1AB61E59L668598', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=27&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/24/27', 'Price': '₦870,000.00', 'Car Title': 'TOYOTA CAMRY L 4DR FRONT-WHEEL DRIVE SEDAN 2004', 'Condition': '4T1BE32K24U886231', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=28&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/24/28', 'Price': '₦750,000.00', 'Car Title': 'HONDA ACCORD EX-L 1.5T 4DR SEDAN 2010', 'Condition': '1HGCP2F79AA137475', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=29&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/24/29', 'Price': '₦550,000.00', 'Car Title': 'DODGE CARAVAN 2010', 'Condition': '2D4RN5DX9AR124758', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=30&itemType=Vehicle', 'Reference Number': 'NCS///01/24/30', 'Price': '₦421,678.00', 'Car Title': 'DODGE CALIBER 2007', 'Condition': '1B3HE78K77D338275', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=31&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/24/31', 'Price': '₦590,000.00', 'Car Title': 'OPEL ZAFIRA 2000', 'Condition': 'W0L0TGF75Y2210603', 'VIN': 'Used', 'Transmission': 'Manual', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=32&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/24/32', 'Price': '₦410,000.00', 'Car Title': 'VOLVO V40 2005', 'Condition': 'KMHPM81CP5U215763', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=33&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/24/33', 'Price': '₦413,000.00', 'Car Title': 'MAZDA PREMACY 2006', 'Condition': 'JMZCP19F201151989', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=34&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/24/34', 'Price': '₦470,000.00', 'Car Title': 'NISSAN ALTIMA 2.0 SR 4DR FRONT-WHEEL DRIVE SEDAN 2009', 'Condition': '1N4AL21E59N541732', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=35&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/24/35', 'Price': '₦500,000.00', 'Car Title': 'OPEL ZAFIRA 2000', 'Condition': 'W0L0TGF7542006165', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=36&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/24/36', 'Price': '₦413,000.00', 'Car Title': 'MITSUBISHI SPACE WAGON 2001', 'Condition': 'JMBLNN84W1Z001380', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=37&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/24/37', 'Price': '₦450,000.00', 'Car Title': 'MAZDA MAZDA 5 2005', 'Condition': 'JMZCR198260114972', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=38&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/24/38', 'Price': '₦450,000.00', 'Car Title': 'MERCEDES-BENZ C240 2005', 'Condition': 'WDBRF81J95F609358', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=39&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/24/39', 'Price': '₦600,000.00', 'Car Title': 'HONDA FR-VAN 2007', 'Condition': 'JHMBE57206S208841', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=40&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/24/40', 'Price': '₦500,000.00', 'Car Title': 'LEXUS ES 330 2005', 'Condition': 'JTHBA30G755129561', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=41&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/24/41', 'Price': '₦580,000.00', 'Car Title': 'OPEL ZAFIRA 2005', 'Condition': 'W0L0TGF752H012070', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=43&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/24/43', 'Price': '₦470,005.00', 'Car Title': 'LEXUS ES 330 2003', 'Condition': 'JTHBF30G430129433', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=45&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/24/45', 'Price': '₦491,000.00', 'Car Title': 'TOYOTA ECHO 2002', 'Condition': 'JTDBT123920230667', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=47&itemType=Vehicle', 'Reference Number': 'NCS/PTML/CSV/01/24/47', 'Price': '₦450,000.00', 'Car Title': 'VOLVO V40 2005', 'Condition': 'YV1MS382852098817', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=48&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/24/48', 'Price': '₦600,000.00', 'Car Title': 'TOYOTA CAMRY HYBRID SE 4DR SEDAN 2002', 'Condition': '4T1BE32K92U112698', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=50&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/24/50', 'Price': '₦403,000.00', 'Car Title': 'FORD COUGAR 2000', 'Condition': 'WF0HT61L5Y5304779', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=51&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/24/51', 'Price': '₦600,000.00', 'Car Title': 'MERCEDES-BENZ C180 2006', 'Condition': 'WDB2020781F857225', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=52&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/24/52', 'Price': '₦528,000.00', 'Car Title': 'MERCEDES-BENZ C180 2006', 'Condition': 'WDB2020781F775020', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=53&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/24/53', 'Price': '₦503,000.00', 'Car Title': 'TOYOTA CAMRY L 4DR FRONT-WHEEL DRIVE SEDAN 2004', 'Condition': '4T1BE30K64U302738', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=54&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/24/54', 'Price': '₦405,000.00', 'Car Title': 'MERCEDES-BENZ C180 2006', 'Condition': 'WDB2020871F988504', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=55&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/24/55', 'Price': '₦660,000.00', 'Car Title': 'MERCEDES-BENZ C200 2002', 'Condition': 'WDB2030451F082661', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': ''}
    {'URL': 'previous_vehicle_details.php?refNo=56&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/24/56', 'Price': '₦420,000.00', 'Car Title': 'TOYOTA CAMRY LE 4DR FRONT-WHEEL DRIVE SEDAN 2003', 'Condition': 'JTDBE32K830222588', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=57&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/24/57', 'Price': '₦535,000.00', 'Car Title': 'MERCEDES-BENZ C200 2000', 'Condition': 'WDB2030451A017334', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=58&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/24/58', 'Price': '₦440,000.00', 'Car Title': 'NISSAN PRIMERA 1999', 'Condition': 'SJNBCAP11U0460396', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=59&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/24/59', 'Price': '₦606,000.00', 'Car Title': 'TOYOTA CAMRY L 4DR FRONT-WHEEL DRIVE SEDAN 2004', 'Condition': '4T1BE32K94U839326', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=60&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/24/60', 'Price': '₦750,000.00', 'Car Title': 'TOYOTA COROLLA LE 4DR SEDAN 2005', 'Condition': '2T1BR32E05C423408', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=62&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/24/62', 'Price': '₦497,000.00', 'Car Title': 'HONDA ACCORD LX 1.5T 4DR SEDAN 2011', 'Condition': '1HGCP2F36BA108112', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=64&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/24/64', 'Price': '₦450,000.00', 'Car Title': 'MERCEDES-BENZ C200 2000', 'Condition': 'WDB2020801F949624', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=65&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/24/65', 'Price': '₦520,000.00', 'Car Title': 'MERCEDES-BENZ C180 2006', 'Condition': 'WDB2020181A368537', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=66&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/24/66', 'Price': '₦430,000.00', 'Car Title': 'MERCEDES-BENZ C180 2006', 'Condition': 'WDB2020261A607098', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': ''}
    {'URL': 'previous_vehicle_details.php?refNo=67&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/24/67', 'Price': '₦410,000.00', 'Car Title': 'NISSAN PRIMERA 1998', 'Condition': 'SJNFCAP11U0065277', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=77&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/24/77', 'Price': '₦600,000.00', 'Car Title': 'MERCEDES-BENZ C240 2004', 'Condition': 'WDBRF61J14E016294', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=78&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/24/78', 'Price': '₦500,000.00', 'Car Title': 'TOYOTA CAMRY LE 4DR FRONT-WHEEL DRIVE SEDAN 2005', 'Condition': '4T1BE32K75U018050', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=80&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/24/80', 'Price': '₦410,000.00', 'Car Title': 'TOYOTA COROLLA LE 4DR SEDAN 2001', 'Condition': '2T1BR12E81C501755', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=81&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/24/81', 'Price': '₦820,000.00', 'Car Title': 'TOYOTA CAMRY LE 4DR FRONT-WHEEL DRIVE SEDAN 2009', 'Condition': '4T4BE46KX9R115819', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=73&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/24/73', 'Price': '₦1,350,000.00', 'Car Title': 'TOYOTA COROLLA LE 4DR SEDAN 2004', 'Condition': '1NXBR38E74Z310866', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=74&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/24/74', 'Price': '₦411,000.00', 'Car Title': 'MERCEDES-BENZ C200 1997', 'Condition': 'WDB2020201A267123', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=75&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/24/75', 'Price': '₦431,000.00', 'Car Title': 'TOYOTA CAMRY LE 4DR FRONT-WHEEL DRIVE SEDAN 1997', 'Condition': '4T1BG22KXVU798629', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=72&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/24/72', 'Price': '₦450,000.00', 'Car Title': 'LEXUS ES 300H LUXURY 4DR SEDAN 2002', 'Condition': 'JTHBF30G120074373', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=71&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/24/71', 'Price': '₦460,000.00', 'Car Title': 'HONDA CIVIC EX 4DR SEDAN 2008', 'Condition': '2HGFG12968H534314', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=70&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/24/70', 'Price': '₦456,000.00', 'Car Title': 'NISSAN MAXIMA 3.5 S 4DR SEDAN 2006', 'Condition': '1N4BA41E16C801573', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=82&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/24/82', 'Price': '₦410,000.00', 'Car Title': 'VOLKSWAGEN PASSAT 2.0T R-LINE 4DR SEDAN 1995', 'Condition': 'WVWZZZ3AZTE102724', 'VIN': 'Used', 'Transmission': 'Manual', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=83&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/24/83', 'Price': '₦800,000.00', 'Car Title': 'TOYOTA CAMRY LE 4DR FRONT-WHEEL DRIVE SEDAN 2010', 'Condition': '4T1BF3EK0AU045240', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=84&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/24/84', 'Price': '₦725,000.00', 'Car Title': 'OPEL ZAFIRA 2000', 'Condition': 'W0L0TGF75X2267290', 'VIN': 'Used', 'Transmission': 'Manual', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=69&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/24/69', 'Price': '₦420,000.00', 'Car Title': 'SCION TC 2007', 'Condition': 'JTKDE177X70204013', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=76&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/24/76', 'Price': '₦530,000.00', 'Car Title': 'HONDA ACCORD LX 1.5T 4DR SEDAN 2010', 'Condition': '1HGCP2F36AA161293', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': ''}
    {'URL': 'previous_vehicle_details.php?refNo=85&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/24/85', 'Price': '₦650,000.00', 'Car Title': 'DODGE CALIBER 2008', 'Condition': '1B3HB28BX8D732592', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=86&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/24/86', 'Price': '₦472,000.00', 'Car Title': 'MERCEDES-BENZ C180 2006', 'Condition': 'WDB2020781F812142', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=87&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/24/87', 'Price': '₦470,000.00', 'Car Title': 'MAZDA MAZDA 5 2006', 'Condition': 'JM1CR293260104252', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=88&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/24/88', 'Price': '₦450,000.00', 'Car Title': 'OPEL ZAFIRA 2001', 'Condition': 'WOLOTGF7522176659', 'VIN': 'Used', 'Transmission': 'Manual', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=89&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/24/89', 'Price': '₦425,000.00', 'Car Title': 'TOYOTA CAMRY HYBRID LE 4DR SEDAN 1997', 'Condition': '4T1BG22KXVU019424', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=90&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/24/90', 'Price': '₦1,000,000.00', 'Car Title': 'HONDA ODYSSEY EX PASSENGER VAN 2009', 'Condition': '5FNRL38719B042371', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=92&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/24/92', 'Price': '₦2,600,000.00', 'Car Title': 'FORD TRANSIT 250 BASE 2008', 'Condition': 'WF0XXXTTFX8R29769', 'VIN': 'Used', 'Transmission': 'Manual', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=93&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/24/93', 'Price': '₦1,550,000.00', 'Car Title': 'TOYOTA RAV4 LIMITED 4DR FRONT-WHEEL DRIVE 2009', 'Condition': 'JTMBK32V895076952', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=96&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/24/96', 'Price': '₦561,000.00', 'Car Title': 'HYUNDAI ELANTRA SE 4DR SEDAN 2010', 'Condition': 'KMHDC8AE8AU057215', 'VIN': 'Accidented', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=97&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/24/97', 'Price': '₦400,100.00', 'Car Title': 'MERCEDES-BENZ C230 2005', 'Condition': 'WDBRF40J65F677577', 'VIN': 'Used', 'Transmission': 'Manual', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=98&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/24/98', 'Price': '₦851,900.00', 'Car Title': 'HONDA ACCORD EX-L 2.0T 4DR SEDAN 2016', 'Condition': '1HGCR2F37GA117497', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=9&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/24/9', 'Price': '₦505,000.00', 'Car Title': 'TOYOTA SOLARA 2008', 'Condition': '4T1CA30P38U154565', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=42&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/24/42', 'Price': '₦526,000.00', 'Car Title': 'MERCEDES-BENZ C320 2001', 'Condition': 'WDB2030641A342141', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=44&itemType=Vehicle', 'Reference Number': 'NCS/PTML//01/24/44', 'Price': '₦422,000.00', 'Car Title': 'VOLVO S80 1999', 'Condition': 'YV1TS65F9Y1096638', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=46&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/24/46', 'Price': '₦451,000.00', 'Car Title': 'LEXUS LS 400 1990', 'Condition': 'JT8UF11E4L0015426', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=49&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/24/49', 'Price': '₦460,000.00', 'Car Title': 'MERCEDES-BENZ E320 1998', 'Condition': 'WDBJF65F0WA587093', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=79&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/24/79', 'Price': '₦402,000.00', 'Car Title': 'OPEL ASTRA 1994', 'Condition': 'W0L000052T2625846', 'VIN': 'Used', 'Transmission': 'Manual', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=91&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/24/91', 'Price': '₦402,000.00', 'Car Title': 'MITSUBISHI CARISMA 2002', 'Condition': 'JMBSNEA2A1Z000979', 'VIN': 'Used', 'Transmission': 'Manual', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=95&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/24/95', 'Price': '₦420,000.00', 'Car Title': 'VOLVO V70 1998', 'Condition': 'YV1LW7206W2465760', 'VIN': 'Used', 'Transmission': 'Manual', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=100&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/24/100', 'Price': '₦1,050,000.00', 'Car Title': 'HONDA ACCORD EX 1.5T 4DR SEDAN 2009', 'Condition': '1HGCP26339A184929', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=101&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/24/101', 'Price': '₦2,150,000.00', 'Car Title': 'TOYOTA COROLLA L 4DR SEDAN 2013', 'Condition': '2T1BU4EE8DC123422', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=103&itemType=Vehicle', 'Reference Number': 'NCS/OVT/PTML/01/2024/103', 'Price': '₦660,000.00', 'Car Title': 'TOYOTA CAMRY 2010', 'Condition': '4T4BF3EK1AR045110', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=102&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/24/102', 'Price': '₦414,000.00', 'Car Title': 'HONDA ACCORD EX 1.5T 4DR SEDAN 2000', 'Condition': '1HGCG5643YA032920', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=104&itemType=Vehicle', 'Reference Number': 'NCS/OVT/PTML/01/2024/104', 'Price': '₦461,000.00', 'Car Title': 'TOYOTA CAMRY 2007', 'Condition': '4T1BE46KX7U569608', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=106&itemType=Vehicle', 'Reference Number': 'NCS/OVT/PTML/01/2024/106', 'Price': '₦865,000.00', 'Car Title': 'PEUGEOT  307 2004', 'Condition': 'VF33HNFUC83284259', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=109&itemType=Vehicle', 'Reference Number': 'NCS/OVT/PTML/01/2024/109', 'Price': '₦650,000.00', 'Car Title': 'MERCEDES-BENZ  C180 1989', 'Condition': 'WDB2020781F784682', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=110&itemType=Vehicle', 'Reference Number': 'NCS/OVT/PTML/01/2024/110', 'Price': '₦1,200,000.00', 'Car Title': 'TOYOTA  COROLLA 2007', 'Condition': '2T1BR32E47C822194', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=111&itemType=Vehicle', 'Reference Number': 'NCS/OVT/PTML/01/2024/111', 'Price': '₦515,000.00', 'Car Title': 'NISSAN  JUKE 2016', 'Condition': 'JN8AF5MV2GT654095', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=112&itemType=Vehicle', 'Reference Number': 'NCS/OVT/PTML/01/2024/112', 'Price': '₦581,000.00', 'Car Title': 'TOYOTA  SIENNA 1998', 'Condition': '4T3ZF13C7WU021370', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=108&itemType=Vehicle', 'Reference Number': 'NCS/OVT/PTML/01/2024/108', 'Price': '₦401,000.00', 'Car Title': 'JAGUAR  JAGUAR XJ6 1989', 'Condition': 'SAJHY154XKC577036', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=114&itemType=Vehicle', 'Reference Number': 'NCS/OVT/PTML/01/2024/114', 'Price': '₦405,000.00', 'Car Title': 'TOYOTA  RAV 4 2003', 'Condition': 'JTEGH20V430091577', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=116&itemType=Vehicle', 'Reference Number': 'NCS/OVT/PTML/01/2024/116', 'Price': '₦520,000.00', 'Car Title': 'KIA  SEDONA 2004', 'Condition': 'KNDUP131746545140', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=115&itemType=Vehicle', 'Reference Number': 'NCS/OVT/PTML/01/2024/115', 'Price': '₦450,000.00', 'Car Title': 'FORD   TRANSIT 2004', 'Condition': 'WF0HXXGBVHRG13465', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=117&itemType=Vehicle', 'Reference Number': 'NCS/OVT/PTML/01/2024/117', 'Price': '₦461,000.00', 'Car Title': 'TOYOTA  SIENNA 2002', 'Condition': '4T3ZF13C62U451787', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=120&itemType=Vehicle', 'Reference Number': 'NCS/OVT/PTML/01/2024/120', 'Price': '₦401,000.00', 'Car Title': 'ISUZU RODEO RODEO 2001', 'Condition': '4S2DM58W314305955', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=121&itemType=Vehicle', 'Reference Number': 'NCS/OVT/PTML/01/2024/121', 'Price': '₦901,111.00', 'Car Title': 'TOYOTA  SIENNA 2004', 'Condition': '5TDZA23C14S212480', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=94&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/24/94', 'Price': '₦400,003.00', 'Car Title': 'VOLVO V70 2004', 'Condition': 'YV1SW61T342443587', 'VIN': 'Used', 'Transmission': 'Manual', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=99&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/24/99', 'Price': '₦1,350,500.00', 'Car Title': 'MERCEDES-BENZ C300 2008', 'Condition': 'WDDGF54X68R038976', 'VIN': 'Used', 'Transmission': 'Manual', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=105&itemType=Vehicle', 'Reference Number': 'NCS/OVT/PTML/01/2024/105', 'Price': '₦480,000.00', 'Car Title': 'TOYOTA YARIS 1999', 'Condition': 'JTDJV123703021901', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=107&itemType=Vehicle', 'Reference Number': 'NCS/OVT/PTML/01/2024/107', 'Price': '₦470,000.00', 'Car Title': 'TOYOTA COROLLA 2003', 'Condition': '1NXBR32E13Z135750', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=113&itemType=Vehicle', 'Reference Number': 'NCS/OVT/PTML/01/2024/113', 'Price': '₦530,000.00', 'Car Title': 'FORD   WINDSTAR 2002', 'Condition': '2FMZA52482BA69419', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=119&itemType=Vehicle', 'Reference Number': 'NCS/OVT/PTML/01/2024/119', 'Price': '₦450,000.00', 'Car Title': 'LEXUS RX300 RX300 2000', 'Condition': 'JT6HF10U2Y0111792', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=122&itemType=Vehicle', 'Reference Number': 'NCS/OVT/PTML/01/2024/122', 'Price': '₦1,520,000.00', 'Car Title': 'HONDA   RIDGELINE 2009', 'Condition': '5FPYK165X9B103003', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=123&itemType=Vehicle', 'Reference Number': 'NCS/OVT/PTML/01/2024/123', 'Price': '₦1,250,000.00', 'Car Title': 'TOYOTA  COROLLA 2006', 'Condition': '1NXBR32E06Z617324', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=124&itemType=Vehicle', 'Reference Number': 'NCS/OVT/PTML/01/2024/124', 'Price': '₦2,000,000.00', 'Car Title': 'HONDA   ACCORD 2012', 'Condition': '1HGCP2F82CA221956', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=127&itemType=Vehicle', 'Reference Number': 'NCS/OVT/PTML/01/2024/127', 'Price': '₦450,000.00', 'Car Title': 'INFINITI   G37 2011', 'Condition': 'JN1CV6AR9BM411913', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=129&itemType=Vehicle', 'Reference Number': 'NCS/OVT/PTML/01/2024/129', 'Price': '₦990,000.00', 'Car Title': 'LEXUS  ES 350 2009', 'Condition': 'JTHBJ46G192315214', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=130&itemType=Vehicle', 'Reference Number': 'NCS/OVT/PTML/01/2024/130', 'Price': '₦930,000.00', 'Car Title': 'TOYOTA  CAMRY 2009', 'Condition': 'JTNBE46K793164301', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=131&itemType=Vehicle', 'Reference Number': 'NCS/OVT/PTML/01/2024/131', 'Price': '₦450,000.00', 'Car Title': 'TOYOTA  CAMRY 2001', 'Condition': 'JT2BF28K110325517', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=132&itemType=Vehicle', 'Reference Number': 'NCS/OVT/PTML/01/2024/132', 'Price': '₦600,000.00', 'Car Title': 'HONDA ACCORD 2008', 'Condition': 'JHMCP26868C071407', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=133&itemType=Vehicle', 'Reference Number': 'NCS/OVT/PTML/01/2024/133', 'Price': '₦630,000.00', 'Car Title': 'TOYOTA  CAMRY 2010', 'Condition': '4T4BF3EK6AR029694', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=134&itemType=Vehicle', 'Reference Number': 'NCS/OVT/PTML/01/2024/134', 'Price': '₦1,170,000.00', 'Car Title': 'TOYOTA  CAMRY 2005', 'Condition': 'JTDBE32K853027589', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=135&itemType=Vehicle', 'Reference Number': 'NCS/OVT/PTML/01/2024/135', 'Price': '₦401,000.00', 'Car Title': 'TOYOTA CAMRY 1998', 'Condition': '4T1BF28K4WU062362', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=136&itemType=Vehicle', 'Reference Number': 'NCS/OVT/PTML/01/2024/136', 'Price': '₦640,000.00', 'Car Title': 'TOYOTA CAMRY 2002', 'Condition': '4T1BF30K12U007699', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=138&itemType=Vehicle', 'Reference Number': 'NCS/OVT/PTML/01/2024/138', 'Price': '₦460,000.00', 'Car Title': 'MERCEDES BENZ  C240 2004', 'Condition': 'WDBRH81J14F540139', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=139&itemType=Vehicle', 'Reference Number': 'NCS/OVT/PTML/01/2024/139', 'Price': '₦560,000.00', 'Car Title': 'TOYOTA  COROLLA 2003', 'Condition': '1NXBR32E73Z023762', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=140&itemType=Vehicle', 'Reference Number': 'NCS/OVT/PTML/01/2024/140', 'Price': '₦420,000.00', 'Car Title': 'ACURA TL  TL 2003', 'Condition': '19UUA56883A027200', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=141&itemType=Vehicle', 'Reference Number': 'NCS/OVT/PTML/01/2024/141', 'Price': '₦1,130,000.00', 'Car Title': 'HYUNDAI ELANTRA ELANTRA 2008', 'Condition': 'KMHDU46D78U490993', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=142&itemType=Vehicle', 'Reference Number': 'NCS/OVT/PTML/01/2024/142', 'Price': '₦1,000,000.00', 'Car Title': 'HONDA   ACCORD 2006', 'Condition': '1HGCM561X6A003636', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=143&itemType=Vehicle', 'Reference Number': 'NCS/OVT/PTML/01/2024/143', 'Price': '₦450,111.00', 'Car Title': 'KIA CEED CEED 2008', 'Condition': 'U5YFF24428L105978', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=144&itemType=Vehicle', 'Reference Number': 'NCS/OVT/PTML/01/2024/144', 'Price': '₦450,000.00', 'Car Title': 'HONDA ACCORD 2005', 'Condition': 'JHMCN36445C002896', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=145&itemType=Vehicle', 'Reference Number': 'NCS/OVT/PTML/01/2024/145', 'Price': '₦450,000.00', 'Car Title': 'TOYOTA  COROLLA 1999', 'Condition': '2T1BR12E7XC179327', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=146&itemType=Vehicle', 'Reference Number': 'NCS/OVT/PTML/01/2024/146', 'Price': '₦2,850,000.00', 'Car Title': 'VOLKSWAGEN   PASSAT 2015', 'Condition': '1VWCS7A38FC057804', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=147&itemType=Vehicle', 'Reference Number': 'NCS/OVT/PTML/01/2024/147', 'Price': '₦2,700,000.00', 'Car Title': 'TOYOTA  CAMRY 2017', 'Condition': '4T1BF1FKXHU418748', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=148&itemType=Vehicle', 'Reference Number': 'NCS/OVT/PTML/01/2024/148', 'Price': '₦410,000.00', 'Car Title': 'TOYOTA  CAMRY 1992', 'Condition': '4T1SK12E1NU000764', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=149&itemType=Vehicle', 'Reference Number': 'NCS/OVT/PTML/01/2024/149', 'Price': '₦1,350,000.00', 'Car Title': 'TOYOTA  COROLLA 2007', 'Condition': '1NXBR30E17Z879065', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=150&itemType=Vehicle', 'Reference Number': 'NCS/OVT/PTML/01/2024/150', 'Price': '₦425,500.00', 'Car Title': 'NISSAN   PRIMERA 1999', 'Condition': 'SJNBCAP11U0447328', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=152&itemType=Vehicle', 'Reference Number': 'NCS/OVT/PTML/01/2024/152', 'Price': '₦1,990,000.00', 'Car Title': 'TOYOTA COROLLA 2004', 'Condition': '2T1BR32E74C206839', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=153&itemType=Vehicle', 'Reference Number': 'NCS/OVT/PTML/01/2024/153', 'Price': '₦650,000.00', 'Car Title': 'TOYOTA AVALON 2003', 'Condition': '4T1BF28B23U294521', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=154&itemType=Vehicle', 'Reference Number': 'NCS/OVT/PTML/01/2024/154', 'Price': '₦1,320,000.00', 'Car Title': 'TOYOTA CAMRY 2013', 'Condition': '4T1BF1FK5DU720412', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=155&itemType=Vehicle', 'Reference Number': 'NCS/OVT/PTML/01/2024/155', 'Price': '₦3,650,000.00', 'Car Title': 'TOYOTA COROLLA 2011', 'Condition': '2T1BU4EE8BC671756', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=157&itemType=Vehicle', 'Reference Number': 'NCS/OVT/PTML/01/2024/157', 'Price': '₦505,000.00', 'Car Title': 'FORD  E350 ECONOLINE VAN 2006', 'Condition': '1FBNE31L56DA20252', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=158&itemType=Vehicle', 'Reference Number': 'NCS/OVT/PTML/01/2024/158', 'Price': '₦422,000.00', 'Car Title': 'FIAT DUCATO 2005', 'Condition': 'ZFA24400007670849', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=159&itemType=Vehicle', 'Reference Number': 'NCS/OVT/PTML/01/2024/159', 'Price': '₦442,000.00', 'Car Title': 'MERCEDES BENZ   SPRINTER 2005', 'Condition': 'WDB9036621R835252', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=160&itemType=Vehicle', 'Reference Number': 'NCS/OVT/PTML/01/2024/160', 'Price': '₦449,900.00', 'Car Title': 'MERCEDES-BENZ   SPRINTER 2005', 'Condition': 'WDB9036621R913683', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=161&itemType=Vehicle', 'Reference Number': 'NCS/OVT/PTML/01/2024/161', 'Price': '₦870,000.00', 'Car Title': 'FORD  E250 ECONOLINE VAN 2009', 'Condition': '1FTNE24W89DA34713', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=162&itemType=Vehicle', 'Reference Number': 'NCS/OVT/PTML/01/2024/162', 'Price': '₦460,000.00', 'Car Title': 'VOLKSWAGEN   LT 31 1998', 'Condition': 'WV2ZZZ28ZJH020778', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=163&itemType=Vehicle', 'Reference Number': 'NCS/OVT/PTML/01/2024/163', 'Price': '₦656,000.00', 'Car Title': 'LDV CONVOY   LWB 2004', 'Condition': 'SEYZMVSYGDN083572', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=164&itemType=Vehicle', 'Reference Number': 'NCS/OVT/PTML/01/2024/164', 'Price': '₦450,000.00', 'Car Title': 'FORD  ECONOLINE 2000', 'Condition': '1FTRE14W9YHA15249', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=165&itemType=Vehicle', 'Reference Number': 'NCS/OVT/PTML/01/2024/165', 'Price': '₦840,000.00', 'Car Title': 'TOYOTA  SIENNA 2008', 'Condition': '5TDZK23C98S187878', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=166&itemType=Vehicle', 'Reference Number': 'NCS/OVT/PTML/01/2024/166', 'Price': '₦455,000.00', 'Car Title': 'DODGE   CARAVAN 2006', 'Condition': '1D4GP45R26B717346', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=167&itemType=Vehicle', 'Reference Number': 'NCS/OVT/PTML/01/2024/167', 'Price': '₦470,000.00', 'Car Title': 'ACURA   RDX 2009', 'Condition': '5J8TB18269A005652', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=168&itemType=Vehicle', 'Reference Number': 'NCS/OVT/PTML/01/2024/168', 'Price': '₦420,103.00', 'Car Title': 'LANDROVER  RANGE ROVER SPORT 2009', 'Condition': 'SALSK254X9A207294', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=169&itemType=Vehicle', 'Reference Number': 'NCS/OVT/PTML/01/2024/169', 'Price': '₦407,000.00', 'Car Title': 'NISSAN  PATHFINDER 2002', 'Condition': 'JN8DR09Y32W720106', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=170&itemType=Vehicle', 'Reference Number': 'NCS/OVT/PTML/01/2024/170', 'Price': '₦1,000,000.00', 'Car Title': 'FORD  EDGE 2007', 'Condition': '2FMDK38C07BB55664', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=171&itemType=Vehicle', 'Reference Number': 'NCS/OVT/PTML/01/2024/171', 'Price': '₦500,000.00', 'Car Title': 'FORD  RANGER 2004', 'Condition': '1FTZR15E84PA94147', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=172&itemType=Vehicle', 'Reference Number': 'NCS/OVT/PTML/01/2024/172', 'Price': '₦415,000.00', 'Car Title': 'HYUNDAI   SANTA FE 2005', 'Condition': 'KM8SC73D05U004892', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=173&itemType=Vehicle', 'Reference Number': 'NCS/OVT/PTML/01/2024/173', 'Price': '₦500,100.00', 'Car Title': 'INFINITI  FX35 2004', 'Condition': 'JNRAS08W54X222750', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=174&itemType=Vehicle', 'Reference Number': 'NCS/OVT/PTML/01/2024/174', 'Price': '₦637,800.00', 'Car Title': 'HONDA   PILOT 2005', 'Condition': '5FNYF18485B006197', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=175&itemType=Vehicle', 'Reference Number': 'NCS/OVT/PTML/01/2024/175', 'Price': '₦401,001.00', 'Car Title': 'CHRYSLER 300 2005', 'Condition': '2C3JA53G95H503654', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=176&itemType=Vehicle', 'Reference Number': 'NCS/OVT/PTML/01/2024/176', 'Price': '₦440,000.00', 'Car Title': 'PEUGEOT 806 2006', 'Condition': 'VF3221RA212431832', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=177&itemType=Vehicle', 'Reference Number': 'NCS/OVT/PTML/01/2024/177', 'Price': '₦685,000.00', 'Car Title': 'TOYOTA  SIENNA 2002', 'Condition': '4T3ZF13C72U487326', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=178&itemType=Vehicle', 'Reference Number': 'NCS/OVT/PTML/01/2024/178', 'Price': '₦900,000.00', 'Car Title': 'TOYOTA SIENNA 2008', 'Condition': '5TDZK23C88S219896', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=179&itemType=Vehicle', 'Reference Number': 'NCS/OVT/PTML/01/2024/179', 'Price': '₦401,000.00', 'Car Title': 'SEAT INCA 2001', 'Condition': 'VSSZZZ9KZ1R021067', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=180&itemType=Vehicle', 'Reference Number': 'NCS/OVT/PTML/01/2024/180', 'Price': '₦620,000.00', 'Car Title': 'TOYOTA HIGHLANDER 2005', 'Condition': 'JTEHD21A750036975', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=181&itemType=Vehicle', 'Reference Number': 'NCS/OVT/PTML/01/2024/181', 'Price': '₦750,000.00', 'Car Title': 'HONDA FIT 2008', 'Condition': 'JHMGD386383047178', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=182&itemType=Vehicle', 'Reference Number': 'NCS/OVT/PTML/01/2024/182', 'Price': '₦412,000.00', 'Car Title': 'TOYOTA CAMRY 2005', 'Condition': '4T1BE32K65U979612', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=183&itemType=Vehicle', 'Reference Number': 'NCS/OVT/PTML/01/2024/183', 'Price': '₦690,000.00', 'Car Title': 'MERCEDES BENZ C240 2002', 'Condition': 'WDBRF61JX2F295199', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=184&itemType=Vehicle', 'Reference Number': 'NCS/OVT/PTML/01/2024/184', 'Price': '₦534,000.00', 'Car Title': 'LEXUS ES 300 2003', 'Condition': 'JTHBF30G030122219', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=185&itemType=Vehicle', 'Reference Number': 'NCS/OVT/PTML/01/2024/185', 'Price': '₦401,000.00', 'Car Title': 'DAEWOO EVANDA 2003', 'Condition': 'KLALA69Z13B085287', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=187&itemType=Vehicle', 'Reference Number': 'NCS/OVT/PTML/01/2024/187', 'Price': '₦420,001.00', 'Car Title': 'VOLKSWAGEN PASSAT 2000', 'Condition': 'WVWWH23B8YE384412', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=188&itemType=Vehicle', 'Reference Number': 'NCS/OVT/PTML/01/2024/188', 'Price': '₦460,000.00', 'Car Title': 'KIA CERATO 2005', 'Condition': 'KNEFE222265211935', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=189&itemType=Vehicle', 'Reference Number': 'NCS/OVT/PTML/01/2024/189', 'Price': '₦465,000.00', 'Car Title': 'JAGUAR XJ SALOON 2006', 'Condition': 'SAJWA79B36SG50026', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=190&itemType=Vehicle', 'Reference Number': 'NCS/OVT/PTML/01/2024/190', 'Price': '₦440,000.00', 'Car Title': 'NISSAN ALTIMA 2002', 'Condition': '1N4AL11D52C194292', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=191&itemType=Vehicle', 'Reference Number': 'NCS/OVT/PTML/01/2024/191', 'Price': '₦421,000.00', 'Car Title': 'VOLVO  S80 2007', 'Condition': 'YV1AS982771034038', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=192&itemType=Vehicle', 'Reference Number': 'NCS/OVT/PTML/01/2024/192', 'Price': '₦700,000.00', 'Car Title': 'TOYOTA CAMRY 2003', 'Condition': '4T1BE30K33U684001', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=194&itemType=Vehicle', 'Reference Number': 'NCS/OVT/PTML/01/2024/194', 'Price': '₦401,000.00', 'Car Title': 'DAEWOO LANOS 2000', 'Condition': 'KLATF48CEXB388483', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=195&itemType=Vehicle', 'Reference Number': 'NCS/OVT/PTML/01/2024/195', 'Price': '₦550,000.00', 'Car Title': 'FORD  F250 CREW CAB 4X2 S 2000', 'Condition': '1FTNX21S4YED57919', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=197&itemType=Vehicle', 'Reference Number': 'NCS/OVT/PTML/01/2024/197', 'Price': '₦455,500.00', 'Car Title': 'HONDA PILOT 2006', 'Condition': '2HKYF18796H004469', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=198&itemType=Vehicle', 'Reference Number': 'NCS/OVT/PTML/01/2024/198', 'Price': '₦410,000.00', 'Car Title': 'NISSAN QUEST 2004', 'Condition': '5N1BV28U24N346875', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=200&itemType=Vehicle', 'Reference Number': 'NCS/OVT/PTML/01/2024/200', 'Price': '₦420,000.00', 'Car Title': 'NISSAN ARMADA 2008', 'Condition': '5N1AA08D18N627101', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=199&itemType=Vehicle', 'Reference Number': 'NCS/OVT/PTML/01/2024/199', 'Price': '₦522,000.00', 'Car Title': 'NISSAN TERRA 2007', 'Condition': '5N1AN08W77C511126', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=196&itemType=Vehicle', 'Reference Number': 'NCS/OVT/PTML/01/2024/196', 'Price': '₦473,765.00', 'Car Title': 'MERCEDES-BENZ  ML320 2001', 'Condition': '4JGAB54E01A233871', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=193&itemType=Vehicle', 'Reference Number': 'NCS/OVT/PTML/01/2024/193', 'Price': '₦412,000.00', 'Car Title': 'AUDI A4 2005', 'Condition': 'WAULT68E15A098445', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=202&itemType=Vehicle', 'Reference Number': 'NCS/OVT/PTML/01/2024/202', 'Price': '₦450,000.00', 'Car Title': 'SUZUKI XL7 2008', 'Condition': '2S3DA417586116705', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=201&itemType=Vehicle', 'Reference Number': 'NCS/OVT/PTML/01/2024/201', 'Price': '₦950,000.00', 'Car Title': 'LANDROVER  RANGE ROVER 2011', 'Condition': 'SALME1D41BA354993', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=186&itemType=Vehicle', 'Reference Number': 'NCS/OVT/PTML/01/2024/186', 'Price': '₦640,000.00', 'Car Title': 'AUDI A4 2009', 'Condition': 'WAULF78K79N014470', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=298&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/2024/298', 'Price': '₦800,000.00', 'Car Title': 'MERCEDES BENZ SPRINTER 2005', 'Condition': 'WDB9036621R830273', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=297&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/2024/297', 'Price': '₦1,300,000.00', 'Car Title': 'KIA  SEDONA 2012', 'Condition': 'KNDMG4C77C6493061', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=296&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/2024/296', 'Price': '₦1,180,000.00', 'Car Title': 'ACURA MDX 2006', 'Condition': '2HNYD18976H542954', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=295&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/2024/295', 'Price': '₦1,400,000.00', 'Car Title': 'HONDA ODYSSEY 2005', 'Condition': '5FNRL38605B409892', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=293&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/2024/293', 'Price': '₦4,790,000.00', 'Car Title': 'LEXUS RX330 2005', 'Condition': 'JTJGA31U250055259', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=292&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/2024/292', 'Price': '₦1,070,000.00', 'Car Title': 'PEUGEOT 807 2004', 'Condition': 'VF3EB4HWB13042972', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=291&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/2024/291', 'Price': '₦1,001,000.00', 'Car Title': 'TOYOTA SIENNA 2001', 'Condition': '4T3ZF19C51U407740', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=288&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/2024/288', 'Price': '₦490,000.00', 'Car Title': 'BMW 520 2002', 'Condition': 'WBADM410806M11520', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=285&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/2024/285', 'Price': '₦1,810,000.00', 'Car Title': 'TOYOTA HIGHLANDER 2001', 'Condition': 'JTEHF21A510011917', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=283&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/2024/283', 'Price': '₦1,030,000.00', 'Car Title': 'HONDA ODYSSEY 2007', 'Condition': '5FNRL38447B082379', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=282&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/2024/282', 'Price': '₦620,000.00', 'Car Title': 'DODGE GRAND CARAVAN 2007', 'Condition': '2D4GP44LX7R115102', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=281&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/2024/281', 'Price': '₦490,000.00', 'Car Title': 'LDV  400 MINIBUS 2003', 'Condition': 'SEYZMVSYGDN092097', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=280&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/2024/280', 'Price': '₦445,000.00', 'Car Title': 'DODGE GRAND CARAVAN 2010', 'Condition': '2D4RN4DEXAR354513', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=279&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/2024/279', 'Price': '₦850,000.00', 'Car Title': 'SATURN VUE 2004', 'Condition': '5GZCZ23DX4S848926', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=277&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/2024/277', 'Price': '₦851,000.00', 'Car Title': 'MAZDA B3000 1999', 'Condition': '4F4ZR16V7XTM32736', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=276&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/2024/276', 'Price': '₦1,020,000.00', 'Car Title': 'TOYOTA 4 RUNNER 2000', 'Condition': 'JT3GM84R7Y0065535', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=275&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/2024/275', 'Price': '₦750,000.00', 'Car Title': 'DODGE CARAVAN 2000', 'Condition': '2B4FP25B9YR604432', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=235&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/2024/235', 'Price': '₦3,100,000.00', 'Car Title': 'HUMMER H2 2003', 'Condition': '5GRGN23U53H106992', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=273&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/2024/273', 'Price': '₦1,100,000.00', 'Car Title': 'BMW  X5 2003', 'Condition': '5UXFA53503LW23616', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=272&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/2024/272', 'Price': '₦6,120,000.00', 'Car Title': 'TOYOTA TUNDRA 2007', 'Condition': '5TBBV58137S453212', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=271&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/2024/271', 'Price': '₦1,600,000.00', 'Car Title': 'LEXUS RX300 2000', 'Condition': 'JT6HF10U9Y0155269', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=267&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/2024/267', 'Price': '₦560,000.00', 'Car Title': 'FORD MERCURY VILLAGE 2001', 'Condition': '4M2ZV14T01DJ11672', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=266&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/2024/266', 'Price': '₦631,001.00', 'Car Title': 'FIAT DOBLO 1997', 'Condition': 'ZFA22300005034910', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=264&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/2024/264', 'Price': '₦970,000.00', 'Car Title': 'DODGE RAM 1200 1996', 'Condition': '2B7JB31Z1TK173073', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=262&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/2024/262', 'Price': '₦2,900,000.00', 'Car Title': 'MERCEDES BENZ GLE450 2010', 'Condition': '4JGBF7BE7AA537755', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=258&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/2024/258', 'Price': '₦551,000.00', 'Car Title': 'ACURA MDX 2007', 'Condition': '2HNYD28387H532985', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=253&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/2024/253', 'Price': '₦2,700,000.00', 'Car Title': 'SUZUKI XL7 2008', 'Condition': '2S3DA417186114689', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=255&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/2024/255', 'Price': '₦933,333.00', 'Car Title': 'CHEVROLET ASTRO VAN 1997', 'Condition': '1GBDM19W2VB160383', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=257&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/2024/257', 'Price': '₦3,200,000.00', 'Car Title': 'TOYOTA 4 RUNNER 2005', 'Condition': 'JTEZU14R058041002', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=256&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/2024/256', 'Price': '₦900,000.00', 'Car Title': 'TOYOTA  4 RUNNER 1999', 'Condition': 'JT3HN86R9X0242163', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=118&itemType=Vehicle', 'Reference Number': 'NCS/OVT/PTML/01/2024/118', 'Price': '₦1,700,000.00', 'Car Title': 'JEEP GRAND  CHEROKEE 2007', 'Condition': '1J8GR48K07C585519', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=251&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/2024/251', 'Price': '₦1,550,000.00', 'Car Title': 'TOYOTA SIENNA 2000', 'Condition': '4T3ZF13C8YU306341', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=248&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/2024/248', 'Price': '₦420,000.00', 'Car Title': 'LINCOLN TOWN CAR 2005', 'Condition': '1LNHM81W55Y630030', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=243&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/2024/243', 'Price': '₦1,800,000.00', 'Car Title': 'TOYOTA SIENNA 2004', 'Condition': '5TDZA23C74S189643', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=247&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/2024/247', 'Price': '₦1,050,000.00', 'Car Title': 'TOYOTA SIENNA 1999', 'Condition': '4T3ZF13C5XU162827', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=249&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/2024/249', 'Price': '₦860,000.00', 'Car Title': 'TOYOTA HIGHLANDER 2005', 'Condition': 'JTEEP21A550092973', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=250&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/2024/250', 'Price': '₦830,000.00', 'Car Title': 'LEXUS RX300 2003', 'Condition': 'JTJHF10U830309565', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=238&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/2024/238', 'Price': '₦825,000.00', 'Car Title': 'TOYOTA SIENNA 2005', 'Condition': '5TDBA22C25S032803', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=234&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/2024/234', 'Price': '₦500,000.00', 'Car Title': 'MERCEDES BENZ VITO 1999', 'Condition': 'VSA63829413210835', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=237&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/2024/237', 'Price': '₦1,300,000.00', 'Car Title': 'TOYOTA SIENNA 2000', 'Condition': '4T3GF19C5YU257937', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=125&itemType=Vehicle', 'Reference Number': 'NCS/OVT/PTML/01/2024/125', 'Price': '₦450,000.00', 'Car Title': 'TOYOTA  CAMRY 1990', 'Condition': '4T1SV21E0LU191105', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=156&itemType=Vehicle', 'Reference Number': 'NCS/OVT/PTML/01/2024/156', 'Price': '₦420,000.00', 'Car Title': 'OPEL   CORSA 1995', 'Condition': 'W0L0SBF08Y4088555', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=203&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/2024/203', 'Price': '₦480,000.00', 'Car Title': 'VOLVO V70 1998', 'Condition': 'YV1LW5522W2402857', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=204&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/2024/204', 'Price': '₦1,000,000.00', 'Car Title': 'DODGE  CALIBER 2007', 'Condition': '1B3HB48B17D179342', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=210&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/2024/210', 'Price': '₦880,000.00', 'Car Title': 'FORD ECONOVAN 1999', 'Condition': '1FBSS31L2XHB39740', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=213&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/2024/213', 'Price': '₦510,000.00', 'Car Title': 'NISSAN PATHFINDER 1988', 'Condition': 'JN8HD16Y4JW000418', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=215&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/2024/215', 'Price': '₦3,200,000.00', 'Car Title': 'TOYOTA SIENNA 2009', 'Condition': '5TDZK23C39S236834', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=222&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/2024/222', 'Price': '₦1,600,000.00', 'Car Title': 'MERCEDES BENZ C230 2002', 'Condition': 'WDBRN47J42A358406', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=225&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/2024/225', 'Price': '₦680,000.00', 'Car Title': 'CHEVROLET EXPRESS PASSENGER VAN G35 2005', 'Condition': '1GCGG25U751183917', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=226&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/2024/226', 'Price': '₦2,700,000.00', 'Car Title': 'TOYOTA SIENNA 2005', 'Condition': '5TDZA23C25S346058', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=227&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/2024/227', 'Price': '₦750,000.00', 'Car Title': 'FORD CLUBWAGEN 1995', 'Condition': '1FMEE11H2SHA63120', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=228&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/2024/228', 'Price': '₦740,000.00', 'Car Title': 'TOYOTA SIENNA 2001', 'Condition': '4T3ZF19C91U345839', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=230&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/2024/230', 'Price': '₦1,201,000.00', 'Car Title': 'VOLKSWAGEN TOURAN 2004', 'Condition': 'WVGZZZ1TZ4W153300', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=214&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/2024/214', 'Price': '₦1,150,000.00', 'Car Title': 'VOLKSWAGEN TRANSPORTER 1992', 'Condition': 'WV2ZZZ25ZHH116837', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=209&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/2024/209', 'Price': '₦510,000.00', 'Car Title': 'DODGE  DAKOTA 2002', 'Condition': '1B7GG16X22S701103', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=246&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/2024/246', 'Price': '₦900,000.00', 'Car Title': 'DODGE RAM 1500 PICK UP 2003', 'Condition': '1D7HU18D03S262717', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=259&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/2024/259', 'Price': '₦759,000.00', 'Car Title': 'LEXUS RX300 2001', 'Condition': 'JTJHF10U510186644', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=260&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/2024/260', 'Price': '₦1,100,000.00', 'Car Title': 'FORD EXPLORER 2004', 'Condition': '1FMZU73E14UC11908', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=252&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/2024/252', 'Price': '₦1,500,000.00', 'Car Title': 'PONTIAC AZTEK 2004', 'Condition': '3G7DA03E74S520022', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=241&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/2024/241', 'Price': '₦1,500,000.00', 'Car Title': 'TOYOTA SIENNA 2000', 'Condition': '4T3ZF13CXYU200005', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=268&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/2024/268', 'Price': '₦1,500,000.00', 'Car Title': 'TOYOTA PREVIA 1991', 'Condition': 'JT3AC11R8M0012633', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=289&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/2024/289', 'Price': '₦730,000.00', 'Car Title': 'MERCEDES BENZ A160 1998', 'Condition': 'WDB1680331J058679', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=10&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/24/10', 'Price': '₦9,000,000.00', 'Car Title': 'TOYOTA CAMRY LE  2015', 'Condition': '4T1BF1FK4FU946508', 'VIN': 'Used', 'Transmission': 'Manual', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=23&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/24/23', 'Price': '₦853,000.00', 'Car Title': 'TOYOTA COROLLA EX 2006', 'Condition': '2T1BR32E76C591340', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'container_details.php?refNo=1&itemType=Container', 'Reference Number': 'NCS/TCIP/OVT/03/2024/1', 'Price': '₦25,000,000.00', 'Car Title': 'DFSU6276690', 'Condition': 'Nigeria', 'VIN': '0KG', 'Transmission': 'N/A', 'Mileage': 'N/A', 'Fuel Type': 'N/A'}
    {'URL': 'container_details.php?refNo=2&itemType=Container', 'Reference Number': 'NCS/TCIP/OVT/03/2024/2', 'Price': '₦19,000,500.00', 'Car Title': 'CSNU6062890', 'Condition': 'Nigeria', 'VIN': '0KG', 'Transmission': 'N/A', 'Mileage': 'N/A', 'Fuel Type': 'N/A'}
    {'URL': 'container_details.php?refNo=3&itemType=Container', 'Reference Number': 'NCS/TCIP/OVT/03/2024/3', 'Price': '₦9,000,000.00', 'Car Title': 'CBHU8708359', 'Condition': 'Nigeria', 'VIN': '0KG', 'Transmission': 'N/A', 'Mileage': 'N/A', 'Fuel Type': 'N/A'}
    {'URL': 'container_details.php?refNo=4&itemType=Container', 'Reference Number': 'NCS/TCIP/OVT/03/2024/4', 'Price': '₦8,700,000.00', 'Car Title': 'CSNU6999438', 'Condition': 'Nigeria', 'VIN': '0KG', 'Transmission': 'N/A', 'Mileage': 'N/A', 'Fuel Type': 'N/A'}
    {'URL': 'container_details.php?refNo=5&itemType=Container', 'Reference Number': 'NCS/TCIP/OVT/03/2024/5', 'Price': '₦29,000,000.00', 'Car Title': 'CBHU7069227', 'Condition': 'Nigeria', 'VIN': '0KG', 'Transmission': 'N/A', 'Mileage': 'N/A', 'Fuel Type': 'N/A'}
    {'URL': 'container_details.php?refNo=6&itemType=Container', 'Reference Number': 'NCS/TCIP/OVT/03/2024/6', 'Price': '₦9,600,000.00', 'Car Title': 'TCNU1677537', 'Condition': 'Nigeria', 'VIN': '0KG', 'Transmission': 'N/A', 'Mileage': 'N/A', 'Fuel Type': 'N/A'}
    {'URL': 'container_details.php?refNo=7&itemType=Container', 'Reference Number': 'NCS/TCIP/OVT/03/2024/7', 'Price': '₦5,500,000.00', 'Car Title': 'BMOU4410540', 'Condition': 'Nigeria', 'VIN': '0KG', 'Transmission': 'N/A', 'Mileage': 'N/A', 'Fuel Type': 'N/A'}
    {'URL': 'container_details.php?refNo=8&itemType=Container', 'Reference Number': 'NCS/TCIP/OVT/03/2024/8', 'Price': '₦2,199,090.00', 'Car Title': 'CCLU7651541', 'Condition': 'Nigeria', 'VIN': '0KG', 'Transmission': 'N/A', 'Mileage': 'N/A', 'Fuel Type': 'N/A'}
    {'URL': 'container_details.php?refNo=9&itemType=Container', 'Reference Number': 'NCS/TCIP/OVT/03/2024/9', 'Price': '₦13,000,000.00', 'Car Title': 'MEDU8568601', 'Condition': 'Nigeria', 'VIN': '0KG', 'Transmission': 'N/A', 'Mileage': 'N/A', 'Fuel Type': 'N/A'}
    {'URL': 'container_details.php?refNo=11&itemType=Container', 'Reference Number': 'NCS/TCIP/OVT/03/2024/11', 'Price': '₦28,900,000.00', 'Car Title': 'AMFU8911347', 'Condition': 'Nigeria', 'VIN': '0KG', 'Transmission': 'N/A', 'Mileage': 'N/A', 'Fuel Type': 'N/A'}
    {'URL': 'previous_vehicle_details.php?refNo=300&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/2024/300', 'Price': '₦500,100.00', 'Car Title': 'DODGE  DURANGO 2004', 'Condition': '1D4HD48N74F167007', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=301&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/2024/301', 'Price': '₦456,000.00', 'Car Title': 'CITROEN  BERLINGO 2006', 'Condition': 'VF7MBRHYB65620204', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=303&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/2024/303', 'Price': '₦403,500.00', 'Car Title': 'CITROEN  BERLINGO 2001', 'Condition': 'VF7MFRHYB65602668', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=302&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/2024/302', 'Price': '₦2,700,000.00', 'Car Title': 'FORD  ECONOLINE 2006', 'Condition': '1FTNE24W36HB17762', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=304&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/2024/304', 'Price': '₦1,500,000.00', 'Car Title': 'FORD  F150 PICK UP 2004', 'Condition': '1FTRX12W34NC39173', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=305&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/2024/305', 'Price': '₦900,000.00', 'Car Title': 'HONDA  CR-V 2002', 'Condition': 'JHLRD78832C819636', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=306&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/2024/306', 'Price': '₦2,600,000.00', 'Car Title': 'TOYOTA  SIENNA 2000', 'Condition': '4T3ZF13CXYU208590', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=373&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/02/2024/373', 'Price': '₦11,500,000.00', 'Car Title': 'TOYOTA  SIENNA 2016', 'Condition': '5TDKK3DC6GS693012', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=377&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/02/2024/377', 'Price': '₦589,000.00', 'Car Title': 'SEAT  INCA 2001', 'Condition': 'R009161', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=376&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/02/2024/376', 'Price': '₦455,000.00', 'Car Title': 'CHRYSLER  VOYAGER 2003', 'Condition': '1C4GJ25373B287369', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=375&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/02/2024/375', 'Price': '₦550,089.00', 'Car Title': 'HONDA  ACCORD 2003', 'Condition': '1HGCM56623A112695', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=366&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/02/2024/366', 'Price': '₦560,000.00', 'Car Title': 'CHRYSLER  PACIFICA 2007', 'Condition': '2A8GF68X37R224244', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=365&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/02/2024/365', 'Price': '₦660,000.00', 'Car Title': 'MERCEDES  BENZ VITO 2001', 'Condition': 'VSA63819413385046', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=363&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/02/2024/363', 'Price': '₦432,000.00', 'Car Title': 'SCION  XB 2013', 'Condition': 'JTLZE4FE6DJ038971', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=362&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/02/2024/362', 'Price': '₦580,000.00', 'Car Title': 'MAZDA  MPV 2006', 'Condition': 'JMZLW19F2Y0102415', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=361&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/02/2024/361', 'Price': '₦495,555.00', 'Car Title': 'FORD  EXPLORER 2006', 'Condition': '1FMEU73EX6UA43168', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=360&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/02/2024/360', 'Price': '₦700,001.00', 'Car Title': 'LANDROVER  RANGE ROVER 2004', 'Condition': 'SALME11444A161924', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=356&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/02/2024/356', 'Price': '₦450,000.00', 'Car Title': 'MERCEDES  BENZ A140 2000', 'Condition': 'WDB1680311J462018', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=355&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/02/2024/355', 'Price': '₦701,000.00', 'Car Title': 'RENAULT  MEGANE SCENIC 2007', 'Condition': 'VF1JA040520582858', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=354&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/02/2024/354', 'Price': '₦670,000.00', 'Car Title': 'HONDA  CIVIC 2004', 'Condition': '2HGES16594H530155', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=353&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/02/2024/353', 'Price': '₦630,000.00', 'Car Title': 'VOLKSWAGEN  PASSAT 2001', 'Condition': 'WVWZZZ3AZTE157980', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=350&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/02/2024/350', 'Price': '₦490,000.00', 'Car Title': 'VOLKSWAGEN  GOLF 2000', 'Condition': 'WVWZZZ1JZ1B079525', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=349&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/02/2024/349', 'Price': '₦460,000.00', 'Car Title': 'TOYOTA  SOLARA 2001', 'Condition': '2T1CF22P01C431365', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=348&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/02/2024/348', 'Price': '₦800,000.00', 'Car Title': 'VOLKSWAGEN  GOLF 1998', 'Condition': 'WVWZZZ1JZXW224212', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=346&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/02/2024/346', 'Price': '₦2,109,900.00', 'Car Title': 'HYUNDAI  ELANTRA 2008', 'Condition': 'KMHDU46DX8U332227', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=345&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/02/2024/345', 'Price': '₦1,400,000.00', 'Car Title': 'MERCEDES C 280 1999', 'Condition': 'WDBHA29G1XA727887', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=344&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/02/2024/344', 'Price': '₦450,000.00', 'Car Title': 'HONDA  ACCORD 2002', 'Condition': '1HGCG56782A146591', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=342&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/02/2024/342', 'Price': '₦600,000.00', 'Car Title': 'OPEL  ZAFIRA 2002', 'Condition': 'W0L0TGF7522213726', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=341&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/02/2024/341', 'Price': '₦2,000,000.00', 'Car Title': 'TOYOTA  TUNDRA 2004', 'Condition': '5TBET34124S446597', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=340&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/02/2024/340', 'Price': '₦592,295.00', 'Car Title': 'SUZUKI  XL7 2002', 'Condition': 'JS3TY92V024102768', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=339&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/02/2024/339', 'Price': '₦2,900,000.00', 'Car Title': 'TOYOTA  SIENNA 2007', 'Condition': '5TDZK23C27S022334', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=338&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/02/2024/338', 'Price': '₦4,000,022.00', 'Car Title': 'TOYOTA  TACOMA 2010', 'Condition': '3TMJU4GN4AM104586', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=337&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/02/2024/337', 'Price': '₦630,000.00', 'Car Title': 'JEEP  LIBERTY 2009', 'Condition': '1J8GN28K79W530468', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=336&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/02/2024/336', 'Price': '₦750,000.00', 'Car Title': 'FORD  EXPLORER 2005', 'Condition': '1FMZU73K25UC05462', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=335&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/02/2024/335', 'Price': '₦1,300,000.00', 'Car Title': 'FORD  ESCAPE 2012', 'Condition': '1FMCU9DG1CKA76151', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=334&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/02/2024/334', 'Price': '₦2,100,000.00', 'Car Title': 'TOYOTA  HIGHLANDER 2003', 'Condition': 'JTEHF21A230116109', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=333&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/02/2024/333', 'Price': '₦700,000.00', 'Car Title': 'MAZDA  MPV 2006', 'Condition': 'JM3LW28AX60562220', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=332&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/02/2024/332', 'Price': '₦1,050,000.00', 'Car Title': 'HONDA  PILOT 2005', 'Condition': '2HKYF18195H566396', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=331&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/02/2024/331', 'Price': '₦1,050,000.00', 'Car Title': 'LEXUS  RX300 2001', 'Condition': 'JTJHF10U910198909', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=330&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/02/2024/330', 'Price': '₦580,000.00', 'Car Title': 'MERCEDES  BENZ S500C 2001', 'Condition': 'WDBNG75JX1A137842', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=329&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/02/2024/329', 'Price': '₦2,000,000.00', 'Car Title': 'TOYOTA  SIENNA 2005', 'Condition': '5TDZA23C25S344097', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=309&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/02/2024/309', 'Price': '₦1,680,000.00', 'Car Title': 'HONDA  ACCORD 2010', 'Condition': '1HGCP2F35AA045230', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=328&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/02/2024/328', 'Price': '₦1,350,000.00', 'Car Title': 'DODGE  RAM PICKUP 2012', 'Condition': '1C6RD7FT6CS189940', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=326&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/02/2024/326', 'Price': '₦442,200.00', 'Car Title': 'ALFA  ROMEO 156 1999', 'Condition': 'ZAR93200001116131', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=325&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/02/2024/325', 'Price': '₦500,000.00', 'Car Title': 'FORD  FOCUS 2002', 'Condition': 'WF0NXXGCDN2A23102', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=323&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/02/2024/323', 'Price': '₦480,000.00', 'Car Title': 'TOYOTA  AVALON 2001', 'Condition': '4T1BF28B01U172611', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=322&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/02/2024/322', 'Price': '₦950,000.00', 'Car Title': 'LEXUS  ES 300 2001', 'Condition': 'JT8BF28G010306779', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=321&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/02/2024/321', 'Price': '₦1,500,000.00', 'Car Title': 'MAZDA  3 2005', 'Condition': 'JM1BK343851224904', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=320&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/02/2024/320', 'Price': '₦751,000.00', 'Car Title': 'NISSAN  MICRA 1999', 'Condition': 'SJNEBAK12U1075794', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=319&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/02/2024/319', 'Price': '₦800,000.00', 'Car Title': 'INFINITI  G35 2003', 'Condition': 'JNKCV51E63M313121', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=318&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/02/2024/318', 'Price': '₦651,000.00', 'Car Title': 'FORD  RANGER 2002', 'Condition': '1FTZR45E02PB01025', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=317&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/02/2024/317', 'Price': '₦550,000.00', 'Car Title': 'NISSAN  SENTRA 2012', 'Condition': '3N1AB6AP6CL769092', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=315&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/02/2024/315', 'Price': '₦500,000.00', 'Car Title': 'LANDROVER  RANGE ROVER 2007', 'Condition': 'SALMF154X7A242373', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=314&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/02/2024/314', 'Price': '₦701,111.00', 'Car Title': 'TOYOTA  CAMRY 2003', 'Condition': '4T1BE32K23U665369', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=312&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/02/2024/312', 'Price': '₦1,300,000.00', 'Car Title': 'TOYOTA  COROLLA 2004', 'Condition': '2T1BR38E34C240770', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=311&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/02/2024/311', 'Price': '₦850,000.00', 'Car Title': 'CHEVROLET  MALIBU 2011', 'Condition': '1G1ZD5E7XBF389558', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=310&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/02/2024/310', 'Price': '₦650,000.00', 'Car Title': 'NISSAN  ALMERA TINO 2005', 'Condition': 'VSKTDAV10U0201011', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=307&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/02/2024/307', 'Price': '₦600,000.00', 'Car Title': 'NISSAN  PRIMERA 2000', 'Condition': 'SJNFAAP11U0493474', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'container_details.php?refNo=13&itemType=Container', 'Reference Number': 'NCS/TCIP/OVT/03/2024/13', 'Price': '₦10,200,000.00', 'Car Title': 'GCNU4686930', 'Condition': 'Nigeria', 'VIN': '19,958KG', 'Transmission': 'N/A', 'Mileage': 'N/A', 'Fuel Type': 'N/A'}
    {'URL': 'container_details.php?refNo=14&itemType=Container', 'Reference Number': 'NCS/TCIP/OVT/03/2024/14', 'Price': '₦2,000,000.00', 'Car Title': 'GCNU1347168', 'Condition': 'Nigeria', 'VIN': '1,020KG', 'Transmission': 'N/A', 'Mileage': 'N/A', 'Fuel Type': 'N/A'}
    {'URL': 'container_details.php?refNo=15&itemType=Container', 'Reference Number': 'NCS/TCIP/OVT/03/2024/15', 'Price': '₦5,000,000.00', 'Car Title': 'ACLU9742735', 'Condition': 'Nigeria', 'VIN': '0KG', 'Transmission': 'N/A', 'Mileage': 'N/A', 'Fuel Type': 'N/A'}
    {'URL': 'container_details.php?refNo=16&itemType=Container', 'Reference Number': 'NCS/TCIP/OVT/03/2024/16', 'Price': '₦13,000,000.00', 'Car Title': 'ACLU9694160', 'Condition': 'Nigeria', 'VIN': '0KG', 'Transmission': 'N/A', 'Mileage': 'N/A', 'Fuel Type': 'N/A'}
    {'URL': 'container_details.php?refNo=17&itemType=Container', 'Reference Number': 'NCS/TCIP/OVT/03/2024/17', 'Price': '₦2,900,100.00', 'Car Title': 'GCNU4726611', 'Condition': 'Nigeria', 'VIN': '0KG', 'Transmission': 'N/A', 'Mileage': 'N/A', 'Fuel Type': 'N/A'}
    {'URL': 'container_details.php?refNo=18&itemType=Container', 'Reference Number': 'NCS/TCIP/OVT/03/2024/18', 'Price': '₦22,000,000.00', 'Car Title': 'GCNU4772601', 'Condition': 'Nigeria', 'VIN': '0KG', 'Transmission': 'N/A', 'Mileage': 'N/A', 'Fuel Type': 'N/A'}
    {'URL': 'container_details.php?refNo=19&itemType=Container', 'Reference Number': 'NCS/TCIP/OVT/03/2024/19', 'Price': '₦2,020,000.00', 'Car Title': 'GCNU4739429', 'Condition': 'Nigeria', 'VIN': '0KG', 'Transmission': 'N/A', 'Mileage': 'N/A', 'Fuel Type': 'N/A'}
    {'URL': 'container_details.php?refNo=21&itemType=Container', 'Reference Number': 'NCS/TCIP/OVT/03/2024/21', 'Price': '₦10,000,000.00', 'Car Title': 'ACLU9724813', 'Condition': 'Nigeria', 'VIN': '0KG', 'Transmission': 'N/A', 'Mileage': 'N/A', 'Fuel Type': 'N/A'}
    {'URL': 'container_details.php?refNo=22&itemType=Container', 'Reference Number': 'NCS/TCIP/OVT/03/2024/22', 'Price': '₦8,500,000.00', 'Car Title': 'ACLU9698972', 'Condition': 'Nigeria', 'VIN': '0KG', 'Transmission': 'N/A', 'Mileage': 'N/A', 'Fuel Type': 'N/A'}
    {'URL': 'previous_vehicle_details.php?refNo=410&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/02/2024/410', 'Price': '₦1,000,000.00', 'Car Title': 'TOYOTA SIENNA 1998', 'Condition': '4T3ZF13C8WU043684', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=409&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/02/2024/409', 'Price': '₦1,600,000.00', 'Car Title': 'TOYOTA SIENNA 2002', 'Condition': '4T3ZF19CX2U450570', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=408&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/02/2024/408', 'Price': '₦800,000.00', 'Car Title': 'ACURA  MDX 2002', 'Condition': '2HNYD18202H532800', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=407&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/02/2024/407', 'Price': '₦740,000.00', 'Car Title': 'KIA  CARNIVAL 2000', 'Condition': 'KNEUP751356688690', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=406&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/02/2024/406', 'Price': '₦1,250,000.00', 'Car Title': 'HONDA ODYSSEY 2005', 'Condition': '5FNRL38655B403957', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=405&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/02/2024/405', 'Price': '₦1,600,000.00', 'Car Title': 'TOYOTA SIENNA 1998', 'Condition': '4T3ZF13CXWU083815', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=402&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/02/2024/402', 'Price': '₦4,500,000.00', 'Car Title': 'GMC TERRAIN SLT 2010', 'Condition': '2CTALDEW2A6213819', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=400&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/02/2024/400', 'Price': '₦900,000.00', 'Car Title': 'MERCEDES BENZ  VIANO 2004', 'Condition': 'WDB4147001N210981', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=399&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/02/2024/399', 'Price': '₦1,500,000.00', 'Car Title': 'LEXUS RX300 2000', 'Condition': 'JT6HF10U9Y0146507', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=398&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/02/2024/398', 'Price': '₦1,400,000.00', 'Car Title': 'LEXUS RX300 2001', 'Condition': 'JTJHF10UX10208170', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=397&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/02/2024/397', 'Price': '₦2,300,000.00', 'Car Title': 'BMW X3 2004', 'Condition': 'WBXPA73414WB22541', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=395&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/02/2024/395', 'Price': '₦1,400,000.00', 'Car Title': 'TOYOTA CAMRY 2002', 'Condition': '4T1BE30K62U554521', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=379&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/02/2024/379', 'Price': '₦1,000,000.00', 'Car Title': 'BMW 316 2002', 'Condition': 'WBAAT51010FW38128', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=382&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/02/2024/382', 'Price': '₦650,000.00', 'Car Title': 'PEUGEOT 306 1998', 'Condition': 'VF37ELFYE33006853', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=383&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/02/2024/383', 'Price': '₦1,400,000.00', 'Car Title': 'LEXUS ES 300 2003', 'Condition': 'JTHBF30G830118998', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=384&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/02/2024/384', 'Price': '₦700,123.00', 'Car Title': 'VOLKSWAGEN GOLF 2000', 'Condition': 'WVWZZZ1JZYW605954', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=385&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/02/2024/385', 'Price': '₦450,000.00', 'Car Title': 'NISSAN PRIMERA 2000', 'Condition': 'SJNFCAP12U0063090', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=386&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/02/2024/386', 'Price': '₦1,300,000.00', 'Car Title': 'VOLKSWAGEN GOLF 1998', 'Condition': 'WVWZZZ1HZXK003466', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=388&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/02/2024/388', 'Price': '₦1,000,000.00', 'Car Title': 'TOYOTA CAMRY 2006', 'Condition': '4T1BE30K86U650270', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=389&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/02/2024/389', 'Price': '₦450,100.00', 'Car Title': 'CITROEN SAXO 2000', 'Condition': 'VF7S1HDZF57127839', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=391&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/02/2024/391', 'Price': '₦1,300,000.00', 'Car Title': 'MERCEDES BENZ  C220 2006', 'Condition': 'WDB2032641F192958', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=394&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/02/2024/394', 'Price': '₦900,000.00', 'Car Title': 'TOYOTA CAMRY 1999', 'Condition': '4T1BG22K2XU614027', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'container_details.php?refNo=23&itemType=Container', 'Reference Number': 'NCS/TCIP/OVT/03/2024/23', 'Price': '₦5,111,111.00', 'Car Title': 'MSCU7642396', 'Condition': 'Nigeria', 'VIN': '0KG', 'Transmission': 'N/A', 'Mileage': 'N/A', 'Fuel Type': 'N/A'}
    {'URL': 'container_details.php?refNo=24&itemType=Container', 'Reference Number': 'NCS/TCIP/OVT/03/2024/24', 'Price': '₦2,000,000.00', 'Car Title': 'TEMU7050462', 'Condition': 'Nigeria', 'VIN': '0KG', 'Transmission': 'N/A', 'Mileage': 'N/A', 'Fuel Type': 'N/A'}
    {'URL': 'container_details.php?refNo=25&itemType=Container', 'Reference Number': 'NCS/TCIP/OVT/03/2024/25', 'Price': '₦3,500,000.00', 'Car Title': 'MAGU5520123', 'Condition': 'Nigeria', 'VIN': '0KG', 'Transmission': 'N/A', 'Mileage': 'N/A', 'Fuel Type': 'N/A'}
    {'URL': 'container_details.php?refNo=26&itemType=Container', 'Reference Number': 'NCS/TCIP/OVT/03/2024/26', 'Price': '₦6,900,000.00', 'Car Title': 'CCLU7863221', 'Condition': 'Nigeria', 'VIN': '0KG', 'Transmission': 'N/A', 'Mileage': 'N/A', 'Fuel Type': 'N/A'}
    {'URL': 'previous_vehicle_details.php?refNo=367&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/02/2024/367', 'Price': '₦900,000.00', 'Car Title': 'NISSAN  PATHFINDER 2005', 'Condition': '5N1AR18W35C783602', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=380&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/02/2024/380', 'Price': '₦1,802,000.00', 'Car Title': 'PEUGEOT 206 2003', 'Condition': 'VF32KNFUF43040590', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=403&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/02/2024/403', 'Price': '₦1,100,000.00', 'Car Title': 'MERCEDES BENZ  ML320 2001', 'Condition': '4JGAB54E91A237174', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=381&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/02/2024/381', 'Price': '₦900,000.00', 'Car Title': 'MERCEDES BENZ  C220 2001', 'Condition': 'WDB2030061F139000', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=404&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/02/2024/404', 'Price': '₦820,000.00', 'Car Title': 'TOYOTA SIENNA 2003', 'Condition': '4T3ZF19C33U517222', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=401&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/02/2024/401', 'Price': '₦800,000.00', 'Car Title': 'VOLVO XC90 2004', 'Condition': 'YV1CM91H741045876', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=396&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/02/2024/396', 'Price': '₦900,000.00', 'Car Title': 'HONDA CIVIC 2001', 'Condition': '1HGEM22531L102232', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=392&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/02/2024/392', 'Price': '₦1,636,900.00', 'Car Title': 'MERCEDES BENZ  C180 2006', 'Condition': 'WDB2020181A595866', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=372&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/02/2024/372', 'Price': '₦1,111,115.00', 'Car Title': 'TOYOTA  SIENNA 2004', 'Condition': '5TDBA22C64S024718', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=364&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/02/2024/364', 'Price': '₦1,060,000.00', 'Car Title': 'FORD  EXPEDITION 2008', 'Condition': '1FMEU17L63LA01071', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=363&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/02/2024/363', 'Price': '₦435,000.00', 'Car Title': 'SCION  XB 2013', 'Condition': 'JTLZE4FE6DJ038971', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=368&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/02/2024/368', 'Price': '₦850,000.00', 'Car Title': 'HONDA  ODYSSEY 2004', 'Condition': '5FNRL18564B103547', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=352&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/02/2024/352', 'Price': '₦650,000.00', 'Car Title': 'HONDA  ACCORD 2006', 'Condition': 'JHMCL76403C206504', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=351&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/02/2024/351', 'Price': '₦488,888.00', 'Car Title': 'BMW  523 2001', 'Condition': 'WBADH31060BY05593', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=347&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/02/2024/347', 'Price': '₦1,352,500.00', 'Car Title': 'PONTIAC  VIBE 2004', 'Condition': '5Y2SL62864Z431224', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=343&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/02/2024/343', 'Price': '₦800,000.00', 'Car Title': 'NISSAN  SENTRA 2008', 'Condition': '3N1AB61E08L633823', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=313&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/02/2024/313', 'Price': '₦1,100,000.00', 'Car Title': 'TOYOTA  CAMRY 2004', 'Condition': '4T1BE32K04U367579', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=299&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/2024/299', 'Price': '₦900,000.00', 'Car Title': 'FORD  TAURUS 2007', 'Condition': '1FAFP56U57A148992', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=269&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/2024/269', 'Price': '₦751,000.00', 'Car Title': 'MERCEDES BENZ ML 1991', 'Condition': '4JG1631541A018964', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=208&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/2024/208', 'Price': '₦650,000.00', 'Car Title': 'HONDA CIVIC 2004', 'Condition': '2HGES16664H630934', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=211&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/2024/211', 'Price': '₦602,350.00', 'Car Title': 'NISSAN  MURANO 2005', 'Condition': 'JN8AZ08T35W318485', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=216&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/2024/216', 'Price': '₦1,550,000.00', 'Car Title': 'PONTIAC VIBE 2005', 'Condition': '5Y2SL63895Z409766', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=219&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/2024/219', 'Price': '₦651,900.00', 'Car Title': 'TOYOTA COROLLA 2002', 'Condition': 'NMTEZ28E80R020936', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=220&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/2024/220', 'Price': '₦1,400,001.00', 'Car Title': 'HONDA CIVIC 2004', 'Condition': '1HGES15544L009770', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=221&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/2024/221', 'Price': '₦1,350,000.00', 'Car Title': 'HONDA ACCORD 2007', 'Condition': '1HGCM56427A174182', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=223&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/2024/223', 'Price': '₦1,400,000.00', 'Car Title': 'TOYOTA CAMRY 2003', 'Condition': '4T1BE32KX3U145100', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=231&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/2024/231', 'Price': '₦1,309,000.00', 'Car Title': 'MAZDA MPV 2005', 'Condition': 'JM3LW28A750534521', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=16&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/24/16', 'Price': '₦750,000.00', 'Car Title': 'AUDI A6 2.0T PREMIUM 2003', 'Condition': 'WAUZZZ4BZWN042668', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=128&itemType=Vehicle', 'Reference Number': 'NCS/OVT/PTML/01/2024/128', 'Price': '₦624,000.00', 'Car Title': 'MITSUBISHI   GALANT 1996', 'Condition': 'JMBLNE52ATZ000591', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=205&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/2024/205', 'Price': '₦520,180.00', 'Car Title': 'HONDA  CIVIC 2006', 'Condition': 'JHMFA36216S028242', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=232&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/2024/232', 'Price': '₦1,004,010.00', 'Car Title': 'TOYOTA SIENNA 2005', 'Condition': '5TDZA23C35S239715', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=233&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/2024/233', 'Price': '₦540,000.00', 'Car Title': 'VOLKSWAGEN SHARAN 2000', 'Condition': 'WVWZZZ7MZ1V002280', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=236&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/2024/236', 'Price': '₦1,103,600.00', 'Car Title': 'HONDA PILOT 2003', 'Condition': '2HKYF18493H601767', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=240&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/2024/240', 'Price': '₦750,000.00', 'Car Title': 'CHEVROLET SILVERADO 2004', 'Condition': '1GCEK14X44Z233541', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=244&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/2024/244', 'Price': '₦6,604,000.00', 'Car Title': 'MERCEDES BENZ GL450 2007', 'Condition': '4JGBF71E67A166520', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=245&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/2024/245', 'Price': '₦1,300,000.00', 'Car Title': 'VOLVO XC90 2004', 'Condition': 'YV1CZ91H441063155', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=254&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/2024/254', 'Price': '₦1,131,350.00', 'Car Title': 'HONDA CR-V 1999', 'Condition': 'JHLRD1848XC033297', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=258&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/2024/258', 'Price': '₦604,500.00', 'Car Title': 'ACURA MDX 2007', 'Condition': '2HNYD28387H532985', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=263&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/2024/263', 'Price': '₦1,102,600.00', 'Car Title': 'VOLKSWAGEN EURO VAN 2002', 'Condition': 'WV2KB47032H016232', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=270&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/2024/270', 'Price': '₦1,413,311.00', 'Car Title': 'TOYOTA SIENNA 2000', 'Condition': '4T3ZF13C3YU257677', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=274&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/2024/274', 'Price': '₦1,000,000.00', 'Car Title': 'FORD EXPLORER 2003', 'Condition': '1FMZU77E53UA00915', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=278&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/2024/278', 'Price': '₦961,900.00', 'Car Title': 'HONDA ODYSSEY 2010', 'Condition': '5FNRL3H4XAB001036', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=284&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/2024/284', 'Price': '₦803,600.00', 'Car Title': 'TOYOTA SIENNA 2004', 'Condition': '5TDZA22C64S134540', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=286&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/2024/286', 'Price': '₦1,111,111.00', 'Car Title': 'OPEL ZAFIRA 2002', 'Condition': 'W0L0TGF7522143670', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=287&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/2024/287', 'Price': '₦900,000.00', 'Car Title': 'VOLKSWAGEN GOLF 1995', 'Condition': 'WVWZZZ1HZTP419200', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=290&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/2024/290', 'Price': '₦1,300,000.00', 'Car Title': 'ACURA  RL 2011', 'Condition': 'JH4KB2F66BC000661', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=294&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/2024/294', 'Price': '₦1,300,003.00', 'Car Title': 'NISSAN ARMADA 2005', 'Condition': '5N1AA08B35N724245', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=137&itemType=Vehicle', 'Reference Number': 'NCS/OVT/PTML/01/2024/137', 'Price': '₦717,222.00', 'Car Title': 'HYUNDAI  TIBURON 2005', 'Condition': 'KMHHN65FX5U177798', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=316&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/02/2024/316', 'Price': '₦760,000.00', 'Car Title': 'NISSAN  PICK UP 1991', 'Condition': '1N6SD11SXMC327333', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=324&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/02/2024/324', 'Price': '₦3,000,000.00', 'Car Title': 'TOYOTA  COROLLA 2005', 'Condition': '2T1BR32E35C441658', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=370&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/02/2024/370', 'Price': '₦1,455,555.00', 'Car Title': 'VOLKSWAGEN  JETTA 2011', 'Condition': '3VWLX7ABM324618', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=218&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/2024/218', 'Price': '₦750,000.00', 'Car Title': 'MERCEDES BENZ E320 2005', 'Condition': 'WDBUF65J55A704358', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=229&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/2024/229', 'Price': '₦2,150,000.00', 'Car Title': 'LANDROVER RANGE ROVER SPORT 2008', 'Condition': 'SALSF25428A122534', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=369&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/02/2024/369', 'Price': '₦3,500,000.00', 'Car Title': 'TOYOTA  COROLLA 2010', 'Condition': '1NXBU4EE6AZ323418', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=374&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/02/2024/374', 'Price': '₦1,301,800.00', 'Car Title': 'TOYOTA  HIGHLANDER 2013', 'Condition': '5TDYK3EH7DS122077', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=411&itemType=Vehicle', 'Reference Number': 'NCS/01TC/OVT/02/2024/411', 'Price': '₦600,700.00', 'Car Title': 'CHEVROLET  TRANSPORT 2001', 'Condition': 'IGNDX03E11D1717', 'VIN': 'Used', 'Transmission': 'AUTOMATIC', 'Mileage': '0.00KM', 'Fuel Type': 'NIL'}
    {'URL': 'previous_vehicle_details.php?refNo=412&itemType=Vehicle', 'Reference Number': 'NCS/01TC/OVT/02/2024/412', 'Price': '₦2,000,000.00', 'Car Title': 'HONDA  CIVIC 2004', 'Condition': 'JMES96634S004245', 'VIN': 'Used', 'Transmission': 'AUTOMATIC', 'Mileage': '0.00KM', 'Fuel Type': 'NIL'}
    {'URL': 'previous_vehicle_details.php?refNo=413&itemType=Vehicle', 'Reference Number': 'NCS/01TC/OVT/02/2024/413', 'Price': '₦520,000.00', 'Car Title': 'MERCEDES-BENZ BENZ 2002', 'Condition': 'WDBRF61JX2E004433', 'VIN': 'Used', 'Transmission': 'AUTOMATIC', 'Mileage': '0.00KM', 'Fuel Type': 'NIL'}
    {'URL': 'previous_vehicle_details.php?refNo=414&itemType=Vehicle', 'Reference Number': 'NCS/01TC/OVT/02/2024/414', 'Price': '₦1,259,000.00', 'Car Title': 'HONDA  CRV 2002', 'Condition': 'JHLRD78852C015290', 'VIN': 'Used', 'Transmission': 'AUTOMATIC', 'Mileage': '0.00KM', 'Fuel Type': 'NIL'}
    {'URL': 'previous_vehicle_details.php?refNo=415&itemType=Vehicle', 'Reference Number': 'NCS/01TC/OVT/02/2024/415', 'Price': '₦2,400,000.00', 'Car Title': 'MITSUBISHI  GALANT 2011', 'Condition': '4A32B2FFXBE018339', 'VIN': 'Used', 'Transmission': 'AUTOMATIC', 'Mileage': '0.00KM', 'Fuel Type': 'NIL'}
    {'URL': 'previous_vehicle_details.php?refNo=416&itemType=Vehicle', 'Reference Number': 'NCS/01TC/OVT/02/2024/416', 'Price': '₦1,250,000.00', 'Car Title': 'LEXUS  RX 300 1999', 'Condition': 'JT6HF10U8X0021044', 'VIN': 'Used', 'Transmission': 'AUTOMATIC', 'Mileage': '0.00KM', 'Fuel Type': 'NIL'}
    {'URL': 'previous_vehicle_details.php?refNo=417&itemType=Vehicle', 'Reference Number': 'NCS/01TC/OVT/02/2024/417', 'Price': '₦3,600,000.00', 'Car Title': 'TOYOTA RAV 4 2007', 'Condition': 'JTMBD31V476027251', 'VIN': 'Used', 'Transmission': 'AUTOMATIC', 'Mileage': '0.00KM', 'Fuel Type': 'NIL'}
    {'URL': 'previous_vehicle_details.php?refNo=418&itemType=Vehicle', 'Reference Number': 'NCS/01TC/OVT/02/2024/418', 'Price': '₦4,240,000.00', 'Car Title': 'HONDA  ACCORD 2014', 'Condition': '1HGCR2E56EA027502', 'VIN': 'Used', 'Transmission': 'AUTOMATIC', 'Mileage': '0.00KM', 'Fuel Type': 'NIL'}
    {'URL': 'previous_vehicle_details.php?refNo=419&itemType=Vehicle', 'Reference Number': 'NCS/01TC/OVT/02/2024/419', 'Price': '₦910,000.00', 'Car Title': 'VOLKSWAGEN PASSAT 2003', 'Condition': 'WVWPD63BX3P044313', 'VIN': 'Used', 'Transmission': 'AUTOMATIC', 'Mileage': '0.00KM', 'Fuel Type': 'NIL'}
    {'URL': 'previous_vehicle_details.php?refNo=420&itemType=Vehicle', 'Reference Number': 'NCS/01TC/OVT/02/2024/420', 'Price': '₦1,150,000.00', 'Car Title': 'LEXUS  ES350 2004', 'Condition': 'JTHBA30G345051553', 'VIN': 'Used', 'Transmission': 'AUTOMATIC', 'Mileage': '0.00KM', 'Fuel Type': 'NIL'}
    {'URL': 'previous_vehicle_details.php?refNo=421&itemType=Vehicle', 'Reference Number': 'NCS/01TC/OVT/02/2024/421', 'Price': '₦850,000.00', 'Car Title': 'TOYOTA  CAMRY 2002', 'Condition': '4T1BE32K22U051601', 'VIN': 'Used', 'Transmission': 'AUTOMATIC', 'Mileage': '0.00KM', 'Fuel Type': 'NIL'}
    {'URL': 'previous_vehicle_details.php?refNo=422&itemType=Vehicle', 'Reference Number': 'NCS/01TC/OVT/02/2024/422', 'Price': '₦1,000,000.00', 'Car Title': 'TOYOTA RAV 4 2005', 'Condition': 'JTEGD20V750053985', 'VIN': 'Used', 'Transmission': 'AUTOMATIC', 'Mileage': '0.00KM', 'Fuel Type': 'NIL'}
    {'URL': 'previous_vehicle_details.php?refNo=423&itemType=Vehicle', 'Reference Number': 'NCS/01TC/OVT/02/2024/423', 'Price': '₦2,824,000.00', 'Car Title': 'TOYOTA 4RUNNER 2006', 'Condition': 'JTEZU14R260064975', 'VIN': 'Used', 'Transmission': 'AUTOMATIC', 'Mileage': '0.00KM', 'Fuel Type': 'NIL'}
    {'URL': 'previous_vehicle_details.php?refNo=424&itemType=Vehicle', 'Reference Number': 'NCS/01TC/OVT/02/2024/424', 'Price': '₦870,000.00', 'Car Title': 'TOYOTA CAMRY 2001', 'Condition': '4T1BG22K51U069545', 'VIN': 'Used', 'Transmission': 'AUTOMATIC', 'Mileage': '0.00KM', 'Fuel Type': 'NIL'}
    {'URL': 'previous_vehicle_details.php?refNo=425&itemType=Vehicle', 'Reference Number': 'NCS/01TC/OVT/02/2024/425', 'Price': '₦709,999.00', 'Car Title': 'HONDA  4DSD 2002', 'Condition': '1HGCG66852A126216', 'VIN': 'Used', 'Transmission': 'AUTOMATIC', 'Mileage': '0.00KM', 'Fuel Type': 'NIL'}
    {'URL': 'previous_vehicle_details.php?refNo=426&itemType=Vehicle', 'Reference Number': 'NCS/01TC/OVT/02/2024/426', 'Price': '₦1,450,000.00', 'Car Title': 'TOYOTA SIENNA 1997', 'Condition': 'JT3HK23M7V1076120', 'VIN': 'Used', 'Transmission': 'AUTOMATIC', 'Mileage': '0.00KM', 'Fuel Type': 'NIL'}
    {'URL': 'previous_vehicle_details.php?refNo=427&itemType=Vehicle', 'Reference Number': 'NCS/01TC/OVT/02/2024/427', 'Price': '₦550,000.00', 'Car Title': 'MITSUBISHI  GALLANT 2003', 'Condition': '3AA46G13E092401', 'VIN': 'Used', 'Transmission': 'AUTOMATIC', 'Mileage': '0.00KM', 'Fuel Type': 'NIL'}
    {'URL': 'previous_vehicle_details.php?refNo=428&itemType=Vehicle', 'Reference Number': 'NCS/01TC/OVT/02/2024/428', 'Price': '₦800,000.00', 'Car Title': 'TOYOTA CAMRY 2002', 'Condition': '4T1BE32K32UO97664', 'VIN': 'Used', 'Transmission': 'AUTOMATIC', 'Mileage': '0.00KM', 'Fuel Type': 'NIL'}
    {'URL': 'previous_vehicle_details.php?refNo=429&itemType=Vehicle', 'Reference Number': 'NCS/01TC/OVT/02/2024/429', 'Price': '₦300,000.00', 'Car Title': 'LEXUS  ES350 2003', 'Condition': 'JTHBF30GX30098236', 'VIN': 'Used', 'Transmission': 'AUTOMATIC', 'Mileage': '0.00KM', 'Fuel Type': 'NIL'}
    {'URL': 'previous_vehicle_details.php?refNo=430&itemType=Vehicle', 'Reference Number': 'NCS/01TC/OVT/02/2024/430', 'Price': '₦1,686,000.00', 'Car Title': 'TOYOTA CAMRY 2005', 'Condition': '4T1BF30K25U107508', 'VIN': 'Used', 'Transmission': 'AUTOMATIC', 'Mileage': '0.00KM', 'Fuel Type': 'NIL'}
    {'URL': 'previous_vehicle_details.php?refNo=432&itemType=Vehicle', 'Reference Number': 'NCS/01TC/OVT/02/2024/432', 'Price': '₦3,800,000.00', 'Car Title': 'TOYOTA COROLLA  2009', 'Condition': '2T1BU40E69C125569', 'VIN': 'Used', 'Transmission': 'AUTOMATIC', 'Mileage': '0.00KM', 'Fuel Type': 'NIL'}
    {'URL': 'previous_vehicle_details.php?refNo=433&itemType=Vehicle', 'Reference Number': 'NCS/01TC/OVT/02/2024/433', 'Price': '₦440,000.00', 'Car Title': 'CHRYSLER  VOYAGER 1999', 'Condition': '1C4GYB4R4XU126070', 'VIN': 'Used', 'Transmission': 'AUTOMATIC', 'Mileage': '0.00KM', 'Fuel Type': 'NIL'}
    {'URL': 'previous_vehicle_details.php?refNo=434&itemType=Vehicle', 'Reference Number': 'NCS/01TC/OVT/02/2024/434', 'Price': '₦630,000.00', 'Car Title': 'MERCEDES-BENZ CLK 2002', 'Condition': 'WDBLK65G32T128779', 'VIN': 'Used', 'Transmission': 'AUTOMATIC', 'Mileage': '0.00KM', 'Fuel Type': 'NIL'}
    {'URL': 'previous_vehicle_details.php?refNo=435&itemType=Vehicle', 'Reference Number': 'NCS/01TC/OVT/02/2024/435', 'Price': '₦410,999.00', 'Car Title': 'HONDA  ACCORD 2005', 'Condition': '1HGCM56A75A136590', 'VIN': 'Used', 'Transmission': 'AUTOMATIC', 'Mileage': '0.00KM', 'Fuel Type': 'NIL'}
    {'URL': 'previous_vehicle_details.php?refNo=436&itemType=Vehicle', 'Reference Number': 'NCS/01TC/OVT/02/2024/436', 'Price': '₦620,000.00', 'Car Title': 'TOYOTA SIENNA 1999', 'Condition': '4T3ZF13C5XU136650', 'VIN': 'Used', 'Transmission': 'AUTOMATIC', 'Mileage': '0.00KM', 'Fuel Type': 'NIL'}
    {'URL': 'previous_vehicle_details.php?refNo=437&itemType=Vehicle', 'Reference Number': 'NCS/01TC/OVT/02/2024/437', 'Price': '₦1,000,000.00', 'Car Title': 'VOLVO XC90 2008', 'Condition': 'YV1CZ592851140748', 'VIN': 'Used', 'Transmission': 'AUTOMATIC', 'Mileage': '0.00KM', 'Fuel Type': 'NIL'}
    {'URL': 'previous_vehicle_details.php?refNo=438&itemType=Vehicle', 'Reference Number': 'NCS/01TC/OVT/02/2024/438', 'Price': '₦820,000.00', 'Car Title': 'MERCEDES-BENZ BENZ 2002', 'Condition': 'WDBRF64J12F150614', 'VIN': 'Used', 'Transmission': 'AUTOMATIC', 'Mileage': '0.00KM', 'Fuel Type': 'NIL'}
    {'URL': 'previous_vehicle_details.php?refNo=439&itemType=Vehicle', 'Reference Number': 'NCS/01TC/OVT/02/2024/439', 'Price': '₦315,000.00', 'Car Title': 'MERCEDES-BENZ E200 2002', 'Condition': 'WDB2100372A154002', 'VIN': 'Used', 'Transmission': 'AUTOMATIC', 'Mileage': '0.00KM', 'Fuel Type': 'NIL'}
    {'URL': 'previous_vehicle_details.php?refNo=440&itemType=Vehicle', 'Reference Number': 'NCS/01TC/OVT/02/2024/440', 'Price': '₦465,660.00', 'Car Title': 'MERCEDES-BENZ BENZ 2001', 'Condition': 'WDBNG70JX1A154485', 'VIN': 'Used', 'Transmission': 'AUTOMATIC', 'Mileage': '0.00KM', 'Fuel Type': 'NIL'}
    {'URL': 'previous_vehicle_details.php?refNo=441&itemType=Vehicle', 'Reference Number': 'NCS/01TC/OVT/02/2024/441', 'Price': '₦1,200,000.00', 'Car Title': 'HONDA  ACCORD 2007', 'Condition': '1HGCM56797A169152', 'VIN': 'Used', 'Transmission': 'AUTOMATIC', 'Mileage': '0.00KM', 'Fuel Type': 'NIL'}
    {'URL': 'previous_vehicle_details.php?refNo=442&itemType=Vehicle', 'Reference Number': 'NCS/01TC/OVT/02/2024/442', 'Price': '₦1,400,000.00', 'Car Title': 'NISSAN ALTIMA 2009', 'Condition': '1N4AL21E79C169368', 'VIN': 'Used', 'Transmission': 'AUTOMATIC', 'Mileage': '0.00KM', 'Fuel Type': 'NIL'}
    {'URL': 'previous_vehicle_details.php?refNo=443&itemType=Vehicle', 'Reference Number': 'NCS/01TC/OVT/02/2024/443', 'Price': '₦2,500,000.00', 'Car Title': 'CADILLAC CADILLAC 2015', 'Condition': '2G61U5S36F9196590', 'VIN': 'Used', 'Transmission': 'AUTOMATIC', 'Mileage': '0.00KM', 'Fuel Type': 'NIL'}
    {'URL': 'previous_vehicle_details.php?refNo=444&itemType=Vehicle', 'Reference Number': 'NCS/01TC/OVT/02/2024/444', 'Price': '₦720,000.00', 'Car Title': 'TOYOTA AVALON 2002', 'Condition': '4T1BF28B32U202850', 'VIN': 'Used', 'Transmission': 'AUTOMATIC', 'Mileage': '0.00KM', 'Fuel Type': 'NIL'}
    {'URL': 'previous_vehicle_details.php?refNo=445&itemType=Vehicle', 'Reference Number': 'NCS/01TC/OVT/02/2024/445', 'Price': '₦320,000.00', 'Car Title': 'CHEROKEE JEEP 1994', 'Condition': 'IJ4FJ28XSRL208496', 'VIN': 'Used', 'Transmission': 'AUTOMATIC', 'Mileage': '0.00KM', 'Fuel Type': 'NIL'}
    {'URL': 'previous_vehicle_details.php?refNo=446&itemType=Vehicle', 'Reference Number': 'NCS/01TC/OVT/02/2024/446', 'Price': '₦301,000.00', 'Car Title': 'NISSAN NISSAN 1990', 'Condition': 'SJNBCAP10U0210495', 'VIN': 'Used', 'Transmission': 'AUTOMATIC', 'Mileage': '0.00KM', 'Fuel Type': 'NIL'}
    {'URL': 'previous_vehicle_details.php?refNo=447&itemType=Vehicle', 'Reference Number': 'NCS/01TC/OVT/02/2024/447', 'Price': '₦550,000.00', 'Car Title': 'VOLKSWAGEN GOLF 2000', 'Condition': 'WVWGC21J0YW235029', 'VIN': 'Used', 'Transmission': 'AUTOMATIC', 'Mileage': '0.00KM', 'Fuel Type': 'NIL'}
    {'URL': 'previous_vehicle_details.php?refNo=448&itemType=Vehicle', 'Reference Number': 'NCS/01TC/OVT/02/2024/448', 'Price': '₦2,900,000.00', 'Car Title': 'TOYOTA  SIENNA 2005', 'Condition': '5TDZA23C15S247702', 'VIN': 'Used', 'Transmission': 'AUTOMATIC', 'Mileage': '0.00KM', 'Fuel Type': 'NIL'}
    {'URL': 'previous_vehicle_details.php?refNo=451&itemType=Vehicle', 'Reference Number': 'NCS/01TC/OVT/02/2024/451', 'Price': '₦365,000.00', 'Car Title': 'TOYOTA AVALON 2003', 'Condition': '4T1BF28B43U303753', 'VIN': 'Used', 'Transmission': 'AUTOMATIC', 'Mileage': '0.00KM', 'Fuel Type': 'NIL'}
    {'URL': 'previous_vehicle_details.php?refNo=452&itemType=Vehicle', 'Reference Number': 'NCS/01TC/OVT/02/2024/452', 'Price': '₦1,650,000.00', 'Car Title': 'TOYOTA AVALON 2008', 'Condition': '4T1BK36B18U287720', 'VIN': 'Used', 'Transmission': 'AUTOMATIC', 'Mileage': '0.00KM', 'Fuel Type': 'NIL'}
    {'URL': 'previous_vehicle_details.php?refNo=454&itemType=Vehicle', 'Reference Number': 'NCS/01TC/OVT/02/2024/454', 'Price': '₦3,864,000.00', 'Car Title': 'FORD FUSION 2013', 'Condition': '3FA6P0G73DR298838', 'VIN': 'Used', 'Transmission': 'AUTOMATIC', 'Mileage': '0.00KM', 'Fuel Type': 'NIL'}
    {'URL': 'previous_vehicle_details.php?refNo=458&itemType=Vehicle', 'Reference Number': 'NCS/01TC/OVT/02/2024/458', 'Price': '₦380,800.00', 'Car Title': 'MAZDA MPV 2003', 'Condition': 'JM3LW28J830335801', 'VIN': 'Used', 'Transmission': 'AUTOMATIC', 'Mileage': '0.00KM', 'Fuel Type': 'NIL'}
    {'URL': 'previous_vehicle_details.php?refNo=462&itemType=Vehicle', 'Reference Number': 'NCS/01TC/OVT/02/2024/462', 'Price': '₦950,050.00', 'Car Title': 'NISSAN FRONTIER 2000', 'Condition': 'IN6ED27Y0YC379011', 'VIN': 'Used', 'Transmission': 'AUTOMATIC', 'Mileage': '0.00KM', 'Fuel Type': 'NIL'}
    {'URL': 'previous_vehicle_details.php?refNo=463&itemType=Vehicle', 'Reference Number': 'NCS/01TC/OVT/02/2024/463', 'Price': '₦452,000.00', 'Car Title': 'TOYOTA CAMRY 2011', 'Condition': '4TIBK3DBOBU395613', 'VIN': 'Used', 'Transmission': 'AUTOMATIC', 'Mileage': '0.00KM', 'Fuel Type': 'NIL'}
    {'URL': 'previous_vehicle_details.php?refNo=464&itemType=Vehicle', 'Reference Number': 'NCS/01TC/OVT/02/2024/464', 'Price': '₦380,000.00', 'Car Title': 'MERCEDES-BENZ BENZ 2001', 'Condition': 'WDB2102351A412752', 'VIN': 'Used', 'Transmission': 'AUTOMATIC', 'Mileage': '0.00KM', 'Fuel Type': 'NIL'}
    {'URL': 'previous_vehicle_details.php?refNo=465&itemType=Vehicle', 'Reference Number': 'NCS/01TC/OVT/02/2024/465', 'Price': '₦2,100,000.00', 'Car Title': 'HONDA ODYSSEY 2006', 'Condition': '5FNRL38466B422713', 'VIN': 'Used', 'Transmission': 'AUTOMATIC', 'Mileage': '0.00KM', 'Fuel Type': 'NIL'}
    {'URL': 'previous_vehicle_details.php?refNo=466&itemType=Vehicle', 'Reference Number': 'NCS/01TC/OVT/02/2024/466', 'Price': '₦2,871,521.00', 'Car Title': 'HONDA ODYSSEY 2007', 'Condition': '5NFRL38637B427001', 'VIN': 'Used', 'Transmission': 'AUTOMATIC', 'Mileage': '0.00KM', 'Fuel Type': 'NIL'}
    {'URL': 'previous_vehicle_details.php?refNo=467&itemType=Vehicle', 'Reference Number': 'NCS/01TC/OVT/02/2024/467', 'Price': '₦1,000,050.00', 'Car Title': 'TOYOTA CAMRY 2000', 'Condition': 'JT2BG22K9YO437532', 'VIN': 'Used', 'Transmission': 'AUTOMATIC', 'Mileage': '0.00KM', 'Fuel Type': 'NIL'}
    {'URL': 'previous_vehicle_details.php?refNo=468&itemType=Vehicle', 'Reference Number': 'NCS/01TC/OVT/02/2024/468', 'Price': '₦1,100,000.00', 'Car Title': 'PONTIAC VIBE 2005', 'Condition': '5Y2SL638X5Z447135', 'VIN': 'Used', 'Transmission': 'AUTOMATIC', 'Mileage': '0.00KM', 'Fuel Type': 'NIL'}
    {'URL': 'previous_vehicle_details.php?refNo=469&itemType=Vehicle', 'Reference Number': 'NCS/01TC/OVT/02/2024/469', 'Price': '₦3,000,001.00', 'Car Title': 'NISSAN FRONTIER 2004', 'Condition': '1N6ED29X44C453190', 'VIN': 'Used', 'Transmission': 'AUTOMATIC', 'Mileage': '0.00KM', 'Fuel Type': 'NIL'}
    {'URL': 'previous_vehicle_details.php?refNo=490&itemType=Vehicle', 'Reference Number': 'NCS/01TC/OVT/02/2024/490', 'Price': '₦3,000,000.00', 'Car Title': 'LEXUS IS250 2008', 'Condition': 'JTHCK262082023465', 'VIN': 'Used', 'Transmission': 'AUTOMATIC', 'Mileage': '0.00KM', 'Fuel Type': 'NIL'}
    {'URL': 'previous_vehicle_details.php?refNo=489&itemType=Vehicle', 'Reference Number': 'NCS/01TC/OVT/02/2024/489', 'Price': '₦900,000.00', 'Car Title': 'SATURN VUE 2006', 'Condition': '5GZCZ63476S873714', 'VIN': 'Used', 'Transmission': 'AUTOMATIC', 'Mileage': '0.00KM', 'Fuel Type': 'NIL'}
    {'URL': 'previous_vehicle_details.php?refNo=488&itemType=Vehicle', 'Reference Number': 'NCS/01TC/OVT/02/2024/488', 'Price': '₦1,800,000.00', 'Car Title': 'MERCEDES-BENZ BENZ 2007', 'Condition': 'WDB2020897F859931', 'VIN': 'Used', 'Transmission': 'AUTOMATIC', 'Mileage': '0.00KM', 'Fuel Type': 'NIL'}
    {'URL': 'previous_vehicle_details.php?refNo=449&itemType=Vehicle', 'Reference Number': 'NCS/01TC/OVT/02/2024/449', 'Price': '₦450,000.00', 'Car Title': 'HONDA  ACCORD 1998', 'Condition': '1HGCG5646WA242067', 'VIN': 'Used', 'Transmission': 'AUTOMATIC', 'Mileage': '0.00KM', 'Fuel Type': 'NIL'}
    {'URL': 'previous_vehicle_details.php?refNo=450&itemType=Vehicle', 'Reference Number': 'NCS/01TC/OVT/02/2024/450', 'Price': '₦650,000.00', 'Car Title': 'HONDA  CRV 2000', 'Condition': '4T3ZF19C5YU209668', 'VIN': 'Used', 'Transmission': 'AUTOMATIC', 'Mileage': '0.00KM', 'Fuel Type': 'NIL'}
    {'URL': 'previous_vehicle_details.php?refNo=453&itemType=Vehicle', 'Reference Number': 'NCS/01TC/OVT/02/2024/453', 'Price': '₦1,800,000.00', 'Car Title': 'TOYOTA SIENNA 2000', 'Condition': '4T3ZF1C8YU298693', 'VIN': 'Used', 'Transmission': 'AUTOMATIC', 'Mileage': '0.00KM', 'Fuel Type': 'NIL'}
    {'URL': 'previous_vehicle_details.php?refNo=455&itemType=Vehicle', 'Reference Number': 'NCS/01TC/OVT/02/2024/455', 'Price': '₦1,111,111.00', 'Car Title': 'TOYOTA CAMRY 1999', 'Condition': 'JT2BG22K0X0315723', 'VIN': 'Used', 'Transmission': 'AUTOMATIC', 'Mileage': '0.00KM', 'Fuel Type': 'NIL'}
    {'URL': 'previous_vehicle_details.php?refNo=456&itemType=Vehicle', 'Reference Number': 'NCS/01TC/OVT/02/2024/456', 'Price': '₦520,000.00', 'Car Title': 'MERCEDES-BENZ E320 2003', 'Condition': 'WDBUF65J33A326201', 'VIN': 'Used', 'Transmission': 'AUTOMATIC', 'Mileage': '0.00KM', 'Fuel Type': 'NIL'}
    {'URL': 'previous_vehicle_details.php?refNo=457&itemType=Vehicle', 'Reference Number': 'NCS/01TC/OVT/02/2024/457', 'Price': '₦1,400,000.00', 'Car Title': 'HYUNDAI ELANTRA 2008', 'Condition': 'KMHDU46D58U330336', 'VIN': 'Used', 'Transmission': 'AUTOMATIC', 'Mileage': '0.00KM', 'Fuel Type': 'NIL'}
    {'URL': 'previous_vehicle_details.php?refNo=459&itemType=Vehicle', 'Reference Number': 'NCS/01TC/OVT/02/2024/459', 'Price': '₦5,499,999.00', 'Car Title': 'TOYOTA CAMRY 2009', 'Condition': '4T1BE46K99U347080', 'VIN': 'Used', 'Transmission': 'AUTOMATIC', 'Mileage': '0.00KM', 'Fuel Type': 'NIL'}
    {'URL': 'previous_vehicle_details.php?refNo=460&itemType=Vehicle', 'Reference Number': 'NCS/01TC/OVT/02/2024/460', 'Price': '₦450,000.00', 'Car Title': 'CHRYLER NA 2005', 'Condition': '2C4GF68445R366693', 'VIN': 'Used', 'Transmission': 'AUTOMATIC', 'Mileage': '0.00KM', 'Fuel Type': 'NIL'}
    {'URL': 'previous_vehicle_details.php?refNo=470&itemType=Vehicle', 'Reference Number': 'NCS/01TC/OVT/02/2024/470', 'Price': '₦750,000.00', 'Car Title': 'TOYOTA SIENNA 2002', 'Condition': '4T3ZF19C62U484893', 'VIN': 'Used', 'Transmission': 'AUTOMATIC', 'Mileage': '0.00KM', 'Fuel Type': 'NIL'}
    {'URL': 'previous_vehicle_details.php?refNo=471&itemType=Vehicle', 'Reference Number': 'NCS/01TC/OVT/02/2024/471', 'Price': '₦1,200,000.00', 'Car Title': 'ACURA MDX 2003', 'Condition': '2HNYD18733H501800', 'VIN': 'Used', 'Transmission': 'AUTOMATIC', 'Mileage': '0.00KM', 'Fuel Type': 'NIL'}
    {'URL': 'previous_vehicle_details.php?refNo=472&itemType=Vehicle', 'Reference Number': 'NCS/01TC/OVT/02/2024/472', 'Price': '₦1,000,000.00', 'Car Title': 'MERCEDES-BENZ BENZ 2001', 'Condition': 'WDB1680331J526707', 'VIN': 'Used', 'Transmission': 'AUTOMATIC', 'Mileage': '0.00KM', 'Fuel Type': 'NIL'}
    {'URL': 'previous_vehicle_details.php?refNo=473&itemType=Vehicle', 'Reference Number': 'NCS/01TC/OVT/02/2024/473', 'Price': '₦2,650,000.00', 'Car Title': 'TOYOTA CAMRY 2002', 'Condition': '4T1BE32K12U546825', 'VIN': 'Used', 'Transmission': 'AUTOMATIC', 'Mileage': '0.00KM', 'Fuel Type': 'NIL'}
    {'URL': 'previous_vehicle_details.php?refNo=474&itemType=Vehicle', 'Reference Number': 'NCS/01TC/OVT/02/2024/474', 'Price': '₦1,000,000.00', 'Car Title': 'HONDA CIVIC 2003', 'Condition': '2HGES26713H589318', 'VIN': 'Used', 'Transmission': 'AUTOMATIC', 'Mileage': '0.00KM', 'Fuel Type': 'NIL'}
    {'URL': 'previous_vehicle_details.php?refNo=478&itemType=Vehicle', 'Reference Number': 'NCS/01TC/OVT/02/2024/478', 'Price': '₦1,350,000.00', 'Car Title': 'MERCEDES-BENZ C230 2005', 'Condition': 'WDBRF40J45F672507', 'VIN': 'Used', 'Transmission': 'AUTOMATIC', 'Mileage': '0.00KM', 'Fuel Type': 'NIL'}
    {'URL': 'previous_vehicle_details.php?refNo=477&itemType=Vehicle', 'Reference Number': 'NCS/01TC/OVT/02/2024/477', 'Price': '₦870,000.00', 'Car Title': 'TOYOTA CAMRY 2002', 'Condition': '4T1BE32KX6U667519', 'VIN': 'Used', 'Transmission': 'AUTOMATIC', 'Mileage': '0.00KM', 'Fuel Type': 'NIL'}
    {'URL': 'previous_vehicle_details.php?refNo=485&itemType=Vehicle', 'Reference Number': 'NCS/01TC/OVT/02/2024/485', 'Price': '₦2,400,000.00', 'Car Title': 'HYUNDAI ELANTRA 2009', 'Condition': 'KMHDU46D49U825130', 'VIN': 'Used', 'Transmission': 'AUTOMATIC', 'Mileage': '0.00KM', 'Fuel Type': 'NIL'}
    {'URL': 'previous_vehicle_details.php?refNo=479&itemType=Vehicle', 'Reference Number': 'NCS/01TC/OVT/02/2024/479', 'Price': '₦701,111.00', 'Car Title': 'HYUNDAI SANTAFE 2004', 'Condition': 'KM8SC13D44U724563', 'VIN': 'Used', 'Transmission': 'AUTOMATIC', 'Mileage': '0.00KM', 'Fuel Type': 'NIL'}
    {'URL': 'previous_vehicle_details.php?refNo=480&itemType=Vehicle', 'Reference Number': 'NCS/01TC/OVT/02/2024/480', 'Price': '₦2,100,000.00', 'Car Title': 'TOYOTA COROLLA 2007', 'Condition': '2T1BR32E17C762567', 'VIN': 'Used', 'Transmission': 'AUTOMATIC', 'Mileage': '0.00KM', 'Fuel Type': 'NIL'}
    {'URL': 'previous_vehicle_details.php?refNo=481&itemType=Vehicle', 'Reference Number': 'NCS/01TC/OVT/02/2024/481', 'Price': '₦3,200,000.00', 'Car Title': 'BENZ C280 2006', 'Condition': 'WDBRF92H36F766449', 'VIN': 'Used', 'Transmission': 'AUTOMATIC', 'Mileage': '0.00KM', 'Fuel Type': 'NIL'}
    {'URL': 'previous_vehicle_details.php?refNo=482&itemType=Vehicle', 'Reference Number': 'NCS/01TC/OVT/02/2024/482', 'Price': '₦555,554.00', 'Car Title': 'TOYOTA CAMRY 2000', 'Condition': 'TIBG22K7Y1768756', 'VIN': 'Used', 'Transmission': 'AUTOMATIC', 'Mileage': '0.00KM', 'Fuel Type': 'NIL'}
    {'URL': 'previous_vehicle_details.php?refNo=483&itemType=Vehicle', 'Reference Number': 'NCS/01TC/OVT/02/2024/483', 'Price': '₦1,800,000.00', 'Car Title': 'TOYOTA COROLLA 2007', 'Condition': '2T1BR32E27C792418', 'VIN': 'Used', 'Transmission': 'AUTOMATIC', 'Mileage': '0.00KM', 'Fuel Type': 'NIL'}
    {'URL': 'previous_vehicle_details.php?refNo=484&itemType=Vehicle', 'Reference Number': 'NCS/01TC/OVT/02/2024/484', 'Price': '₦570,000.00', 'Car Title': 'TOYOTA CAMRY 2001', 'Condition': '4T1BG22K41U796644', 'VIN': 'Used', 'Transmission': 'AUTOMATIC', 'Mileage': '0.00KM', 'Fuel Type': 'NIL'}
    {'URL': 'previous_vehicle_details.php?refNo=486&itemType=Vehicle', 'Reference Number': 'NCS/01TC/OVT/02/2024/486', 'Price': '₦910,000.00', 'Car Title': 'TOYOTA SOLARA 2004', 'Condition': '4T1CE30P74U836251', 'VIN': 'Used', 'Transmission': 'AUTOMATIC', 'Mileage': '0.00KM', 'Fuel Type': 'NIL'}
    {'URL': 'previous_vehicle_details.php?refNo=475&itemType=Vehicle', 'Reference Number': 'NCS/01TC/OVT/02/2024/475', 'Price': '₦1,250,000.00', 'Car Title': 'TOYOTA MATRIX 2006', 'Condition': '2T1KR30E16C613223', 'VIN': 'Used', 'Transmission': 'AUTOMATIC', 'Mileage': '0.00KM', 'Fuel Type': 'NIL'}
    {'URL': 'previous_vehicle_details.php?refNo=487&itemType=Vehicle', 'Reference Number': 'NCS/01TC/OVT/02/2024/487', 'Price': '₦500,000.00', 'Car Title': 'TOYOTA CAMRY 2001', 'Condition': '4T1BG22K31U843209', 'VIN': 'Used', 'Transmission': 'AUTOMATIC', 'Mileage': '0.00KM', 'Fuel Type': 'NIL'}
    {'URL': 'previous_vehicle_details.php?refNo=207&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/2024/207', 'Price': '₦3,900,000.00', 'Car Title': 'NISSAN  ALTIMA 2015', 'Condition': '1N4AL3AP1FC139530', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=212&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/2024/212', 'Price': '₦900,500.00', 'Car Title': 'FORD TAURUS 2004', 'Condition': '1FAFP55U04G119684', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=217&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/2024/217', 'Price': '₦1,715,000.00', 'Car Title': 'TOYOTA CAMRY 2013', 'Condition': '4T4BF1FKXDR289071', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=224&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/01/2024/224', 'Price': '₦1,600,000.00', 'Car Title': 'FIAT DUCATO 1995', 'Condition': 'ZFA24400007379024', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=358&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/02/2024/358', 'Price': '₦1,000,090.00', 'Car Title': 'VOLVO  V40 2000', 'Condition': 'YV1VW26751F639922', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=359&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/02/2024/359', 'Price': '₦450,000.00', 'Car Title': 'NISSAN  ALMERA 2004', 'Condition': 'JN1CAAN16U0007462', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=378&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/02/2024/378', 'Price': '₦1,700,000.00', 'Car Title': 'TOYOTA COROLLA 2005', 'Condition': '2T1BR32EX5C336874', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=387&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/02/2024/387', 'Price': '₦1,600,000.00', 'Car Title': 'PEUGEOT 406 1999', 'Condition': 'VF38BRFVE80645422', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=393&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/02/2024/393', 'Price': '₦2,004,895.00', 'Car Title': 'VOLKSWAGEN GOLF 2007', 'Condition': 'WVWZZZ1JZXB035377', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=491&itemType=Vehicle', 'Reference Number': 'NCS/01TC/OVT/02/2024/491', 'Price': '₦1,203,838.00', 'Car Title': 'TOYOTA CAMRY 1999', 'Condition': 'JT2BF28K2X0167469', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=492&itemType=Vehicle', 'Reference Number': 'NCS/01TC/OVT/02/2024/492', 'Price': '₦1,700,000.00', 'Car Title': 'MINI  COOPER 2009', 'Condition': 'WMWMF33569TW70248', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=493&itemType=Vehicle', 'Reference Number': 'NCS/01TC/OVT/02/2024/493', 'Price': '₦927,837.00', 'Car Title': 'HONDA CR-V 1998', 'Condition': 'JHLRD1840WC046981', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=494&itemType=Vehicle', 'Reference Number': 'NCS/01TC/OVT/02/2024/494', 'Price': '₦2,250,000.00', 'Car Title': 'TOYOTA COROLLA 2004', 'Condition': '1NXBR32E94Z251733', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=495&itemType=Vehicle', 'Reference Number': 'NCS/01TC/OVT/02/2024/495', 'Price': '₦1,700,000.00', 'Car Title': 'LEXUS  S GS 300 2003', 'Condition': 'JT8BD69S030173721', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=496&itemType=Vehicle', 'Reference Number': 'NCS/01TC/OVT/02/2024/496', 'Price': '₦1,000,000.00', 'Car Title': 'VOLVO  XC70 2007', 'Condition': 'YV4SZ592471257356', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=497&itemType=Vehicle', 'Reference Number': 'NCS/01TC/OVT/02/2024/497', 'Price': '₦3,000,000.00', 'Car Title': 'TOYOTA COROLLA 2009', 'Condition': '1NXBU40E29Z030487', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=498&itemType=Vehicle', 'Reference Number': 'NCS/01TC/OVT/02/2024/498', 'Price': '₦500,000.00', 'Car Title': 'CHEVROLET  EQUINOX LT 2001', 'Condition': '2CND163F956012525', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=499&itemType=Vehicle', 'Reference Number': 'NCS/01TC/OVT/02/2024/499', 'Price': '₦2,200,000.00', 'Car Title': 'HYUNDAI  SONATA 2007', 'Condition': '5NPEU46F87H225339', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=500&itemType=Vehicle', 'Reference Number': 'NCS/01TC/OVT/02/2024/500', 'Price': '₦876,000.00', 'Car Title': 'DAEWOO DAEWOO 2002', 'Condition': 'KLAUF75612K823757', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=501&itemType=Vehicle', 'Reference Number': 'NCS/01TC/OVT/02/2024/501', 'Price': '₦950,000.00', 'Car Title': 'VOLCKSWAGEN PASSAT 2003', 'Condition': 'WVWMD63B13E411369', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=502&itemType=Vehicle', 'Reference Number': 'NCS/01TC/OVT/02/2024/502', 'Price': '₦800,000.00', 'Car Title': 'VOLKSWAGEN JETTA 2004', 'Condition': '3VWRK69MX4M138445', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=503&itemType=Vehicle', 'Reference Number': 'NCS/01TC/OVT/02/2024/503', 'Price': '₦1,000,000.00', 'Car Title': 'HONDA ODDESY 2000', 'Condition': '2HKRL1866YH540738', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=504&itemType=Vehicle', 'Reference Number': 'NCS/01TC/OVT/02/2024/504', 'Price': '₦411,100.00', 'Car Title': 'MERCEDES  BENZ 2002', 'Condition': 'WDBLK65G42T101316', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=505&itemType=Vehicle', 'Reference Number': 'NCS/01TC/OVT/02/2024/505', 'Price': '₦2,000,005.00', 'Car Title': 'MAZDA  CX7 2007', 'Condition': 'JM3ER293270133459', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=506&itemType=Vehicle', 'Reference Number': 'NCS/01TC/OVT/02/2024/506', 'Price': '₦800,000.00', 'Car Title': 'AUDI   ALLROAD 2002', 'Condition': 'WA1YD64B82N120800', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=507&itemType=Vehicle', 'Reference Number': 'NCS/01TC/OVT/02/2024/507', 'Price': '₦1,400,000.00', 'Car Title': 'HONDA ACCORD 2007', 'Condition': '1HGCM56897A018739', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=508&itemType=Vehicle', 'Reference Number': 'NCS/01TC/OVT/02/2024/508', 'Price': '₦4,600,000.00', 'Car Title': 'TOYOTA COROLLA 2010', 'Condition': '1NXBU4EE6AZ383909', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=509&itemType=Vehicle', 'Reference Number': 'NCS/01TC/OVT/02/2024/509', 'Price': '₦2,500,000.00', 'Car Title': 'TOYOTA CAMRY 2005', 'Condition': 'JTDBE32K753033626', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=510&itemType=Vehicle', 'Reference Number': 'NCS/01TC/OVT/02/2024/510', 'Price': '₦1,000,000.00', 'Car Title': 'HONDA ACCORD 2005', 'Condition': '1HGCM56475L004238', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=511&itemType=Vehicle', 'Reference Number': 'NCS/01TC/OVT/02/2024/511', 'Price': '₦1,400,000.00', 'Car Title': 'MERCEDES  BENZ 2005', 'Condition': '4JGAB57E05A530267', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=512&itemType=Vehicle', 'Reference Number': 'NCS/01TC/OVT/02/2024/512', 'Price': '₦900,099.00', 'Car Title': 'TOYOTA SOLORA 2004', 'Condition': '4T1CA38P54U008098', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=513&itemType=Vehicle', 'Reference Number': 'NCS/01TC/OVT/02/2024/513', 'Price': '₦2,000,000.00', 'Car Title': 'HONDA CIVIC 2008', 'Condition': '2HGFA16968H504175', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=514&itemType=Vehicle', 'Reference Number': 'NCS/01TC/OVT/02/2024/514', 'Price': '₦610,000.00', 'Car Title': 'SCION XA 2006', 'Condition': 'JTKKT624460151542', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=515&itemType=Vehicle', 'Reference Number': 'NCS/01TC/OVT/02/2024/515', 'Price': '₦7,500,000.00', 'Car Title': 'MERCEDES  BENZ C300 2011', 'Condition': 'WDDGF5EB0BR148500', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=516&itemType=Vehicle', 'Reference Number': 'NCS/01TC/OVT/02/2024/516', 'Price': '₦1,300,000.00', 'Car Title': 'TOYOTA CAMRY 2001', 'Condition': '401BF22AS1U119900', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=517&itemType=Vehicle', 'Reference Number': 'NCS/01TC/OVT/02/2024/517', 'Price': '₦1,650,000.00', 'Car Title': 'VOLCKSWAGEN GOLF 1998', 'Condition': 'WVWZZZ1JZWB042824', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=518&itemType=Vehicle', 'Reference Number': 'NCS/01TC/OVT/02/2024/518', 'Price': '₦1,350,000.00', 'Car Title': 'OPEL   ASTRA 1998', 'Condition': 'W0L0TGF3512086052', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=519&itemType=Vehicle', 'Reference Number': 'NCS/01TC/OVT/02/2024/519', 'Price': '₦3,511,111.00', 'Car Title': 'LEXUS 350 2004', 'Condition': 'JTHA30GX45020347', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=520&itemType=Vehicle', 'Reference Number': 'NCS/01TC/OVT/02/2024/520', 'Price': '₦3,200,000.00', 'Car Title': 'NISSAN  ALTIMA 2013', 'Condition': 'IN4BL113DDC178498', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=521&itemType=Vehicle', 'Reference Number': 'NCS/01TC/OVT/02/2024/521', 'Price': '₦1,900,000.00', 'Car Title': 'HONDA PILOT 2006', 'Condition': '2HKYF18546H555780', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=522&itemType=Vehicle', 'Reference Number': 'NCS/01TC/OVT/02/2024/522', 'Price': '₦650,000.00', 'Car Title': 'FORD  MONDEO 2010', 'Condition': 'UF0AXX6BBAWA24713', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=523&itemType=Vehicle', 'Reference Number': 'NCS/01TC/OVT/02/2024/523', 'Price': '₦2,700,000.00', 'Car Title': 'TOYOTA T100 T100 1996', 'Condition': 'JT4TN12D6T0022593', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=524&itemType=Vehicle', 'Reference Number': 'NCS/01TC/OVT/02/2024/524', 'Price': '₦3,200,000.00', 'Car Title': 'TOYOTA COROLLA 2005', 'Condition': '1NXBR32E65Z434119', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'container_details.php?refNo=60&itemType=Container', 'Reference Number': 'NCS/TCIP/OVT/03/2024/60', 'Price': '₦2,600,999.00', 'Car Title': 'MOLU7034820', 'Condition': 'Nigeria', 'VIN': '0KG', 'Transmission': 'N/A', 'Mileage': 'N/A', 'Fuel Type': 'N/A'}
    {'URL': 'container_details.php?refNo=62&itemType=Container', 'Reference Number': 'NCS/TCIP/OVT/03/2024/62', 'Price': '₦8,000,000.00', 'Car Title': 'CLHU8060923', 'Condition': 'Nigeria', 'VIN': '0KG', 'Transmission': 'N/A', 'Mileage': 'N/A', 'Fuel Type': 'N/A'}
    {'URL': 'container_details.php?refNo=63&itemType=Container', 'Reference Number': 'NCS/TCIP/OVT/03/2024/63', 'Price': '₦1,600,000.00', 'Car Title': 'MOLU3014174', 'Condition': 'Nigeria', 'VIN': '0KG', 'Transmission': 'N/A', 'Mileage': 'N/A', 'Fuel Type': 'N/A'}
    {'URL': 'container_details.php?refNo=64&itemType=Container', 'Reference Number': 'NCS/TCIP/OVT/03/2024/64', 'Price': '₦2,100,000.00', 'Car Title': 'ONEU0288573', 'Condition': 'Nigeria', 'VIN': '0KG', 'Transmission': 'N/A', 'Mileage': 'N/A', 'Fuel Type': 'N/A'}
    {'URL': 'container_details.php?refNo=66&itemType=Container', 'Reference Number': 'NCS/TCIP/OVT/03/2024/66', 'Price': '₦2,789,898.00', 'Car Title': 'CAXU6428957', 'Condition': 'Nigeria', 'VIN': '0KG', 'Transmission': 'N/A', 'Mileage': 'N/A', 'Fuel Type': 'N/A'}
    {'URL': 'container_details.php?refNo=67&itemType=Container', 'Reference Number': 'NCS/TCIP/OVT/03/2024/67', 'Price': '₦1,700,000.00', 'Car Title': 'ARKU2310217', 'Condition': 'Nigeria', 'VIN': '0KG', 'Transmission': 'N/A', 'Mileage': 'N/A', 'Fuel Type': 'N/A'}
    {'URL': 'container_details.php?refNo=68&itemType=Container', 'Reference Number': 'NCS/TCIP/OVT/03/2024/68', 'Price': '₦3,000,000.00', 'Car Title': 'FCIU3703352', 'Condition': 'Nigeria', 'VIN': '0KG', 'Transmission': 'N/A', 'Mileage': 'N/A', 'Fuel Type': 'N/A'}
    {'URL': 'container_details.php?refNo=69&itemType=Container', 'Reference Number': 'NCS/TCIP/OVT/03/2024/69', 'Price': '₦2,800,000.00', 'Car Title': 'GLDU5168929', 'Condition': 'Nigeria', 'VIN': '0KG', 'Transmission': 'N/A', 'Mileage': 'N/A', 'Fuel Type': 'N/A'}
    {'URL': 'container_details.php?refNo=70&itemType=Container', 'Reference Number': 'NCS/TCIP/OVT/03/2024/70', 'Price': '₦2,400,000.00', 'Car Title': 'DVRU1465319', 'Condition': 'Nigeria', 'VIN': '0KG', 'Transmission': 'N/A', 'Mileage': 'N/A', 'Fuel Type': 'N/A'}
    {'URL': 'container_details.php?refNo=71&itemType=Container', 'Reference Number': 'NCS/TCIP/OVT/03/2024/71', 'Price': '₦2,000,000.00', 'Car Title': 'CLHU2820103', 'Condition': 'Nigeria', 'VIN': '0KG', 'Transmission': 'N/A', 'Mileage': 'N/A', 'Fuel Type': 'N/A'}
    {'URL': 'container_details.php?refNo=72&itemType=Container', 'Reference Number': 'NCS/TCIP/OVT/03/2024/72', 'Price': '₦7,300,000.00', 'Car Title': 'MOAU0530694', 'Condition': 'Nigeria', 'VIN': '0KG', 'Transmission': 'N/A', 'Mileage': 'N/A', 'Fuel Type': 'N/A'}
    {'URL': 'container_details.php?refNo=73&itemType=Container', 'Reference Number': 'NCS/TCIP/OVT/03/2024/73', 'Price': '₦2,800,000.00', 'Car Title': 'MOAU0221289', 'Condition': 'Nigeria', 'VIN': '0KG', 'Transmission': 'N/A', 'Mileage': 'N/A', 'Fuel Type': 'N/A'}
    {'URL': 'container_details.php?refNo=74&itemType=Container', 'Reference Number': 'NCS/TCIP/OVT/03/2024/74', 'Price': '₦8,000,000.00', 'Car Title': 'MSCU2459021', 'Condition': 'Nigeria', 'VIN': '0KG', 'Transmission': 'N/A', 'Mileage': 'N/A', 'Fuel Type': 'N/A'}
    {'URL': 'container_details.php?refNo=75&itemType=Container', 'Reference Number': 'NCS/TCIP/OVT/03/2024/75', 'Price': '₦1,901,111.00', 'Car Title': 'MSCU1835778', 'Condition': 'Nigeria', 'VIN': '0KG', 'Transmission': 'N/A', 'Mileage': 'N/A', 'Fuel Type': 'N/A'}
    {'URL': 'container_details.php?refNo=77&itemType=Container', 'Reference Number': 'NCS/TCIP/OVT/03/2024/77', 'Price': '₦2,999,000.00', 'Car Title': 'MEDU2609299', 'Condition': 'Nigeria', 'VIN': '0KG', 'Transmission': 'N/A', 'Mileage': 'N/A', 'Fuel Type': 'N/A'}
    {'URL': 'container_details.php?refNo=78&itemType=Container', 'Reference Number': 'NCS/TCIP/OVT/03/2024/78', 'Price': '₦1,600,000.00', 'Car Title': 'MSCU8038647', 'Condition': 'Nigeria', 'VIN': '0KG', 'Transmission': 'N/A', 'Mileage': 'N/A', 'Fuel Type': 'N/A'}
    {'URL': 'container_details.php?refNo=79&itemType=Container', 'Reference Number': 'NCS/TCIP/OVT/03/2024/79', 'Price': '₦3,000,000.00', 'Car Title': 'MEDU8377143', 'Condition': 'Nigeria', 'VIN': '0KG', 'Transmission': 'N/A', 'Mileage': 'N/A', 'Fuel Type': 'N/A'}
    {'URL': 'container_details.php?refNo=81&itemType=Container', 'Reference Number': 'NCS/TCIP/OVT/03/2024/81', 'Price': '₦1,800,005.00', 'Car Title': 'MSCU3755671', 'Condition': 'Nigeria', 'VIN': '0KG', 'Transmission': 'N/A', 'Mileage': 'N/A', 'Fuel Type': 'N/A'}
    {'URL': 'previous_vehicle_details.php?refNo=525&itemType=Vehicle', 'Reference Number': 'NCS/01AP/OVT/03/2024/525', 'Price': '₦750,000.00', 'Car Title': 'MECEDES BEZ 2003', 'Condition': 'WDBRF81J03F359084', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=526&itemType=Vehicle', 'Reference Number': 'NCS/01AP/OVT/03/2024/526', 'Price': '₦730,000.00', 'Car Title': 'LEXUS ES 300 2003', 'Condition': 'JTHBF30G436015350', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=527&itemType=Vehicle', 'Reference Number': 'NCS/01AP/OVT/03/2024/527', 'Price': '₦1,000,000.00', 'Car Title': 'VOLKSWAGON GOLF 2003', 'Condition': '9BWDE61JX34039159', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'container_details.php?refNo=33&itemType=Container', 'Reference Number': 'NCS/TCIP/OVT/03/2024/33', 'Price': '₦1,501,200.00', 'Car Title': 'CCLU2989731', 'Condition': 'Nigeria', 'VIN': '0KG', 'Transmission': 'N/A', 'Mileage': 'N/A', 'Fuel Type': 'N/A'}
    {'URL': 'container_details.php?refNo=34&itemType=Container', 'Reference Number': 'NCS/TCIP/OVT/03/2024/34', 'Price': '₦2,500,000.00', 'Car Title': 'CCLU3937286', 'Condition': 'Nigeria', 'VIN': '0KG', 'Transmission': 'N/A', 'Mileage': 'N/A', 'Fuel Type': 'N/A'}
    {'URL': 'container_details.php?refNo=36&itemType=Container', 'Reference Number': 'NCS/TCIP/OVT/03/2024/36', 'Price': '₦2,999,999.00', 'Car Title': 'CCLU6122986', 'Condition': 'Nigeria', 'VIN': '0KG', 'Transmission': 'N/A', 'Mileage': 'N/A', 'Fuel Type': 'N/A'}
    {'URL': 'container_details.php?refNo=39&itemType=Container', 'Reference Number': 'NCS/TCIP/OVT/03/2024/39', 'Price': '₦3,200,000.00', 'Car Title': 'GLDU0836500', 'Condition': 'Nigeria', 'VIN': '0KG', 'Transmission': 'N/A', 'Mileage': 'N/A', 'Fuel Type': 'N/A'}
    {'URL': 'container_details.php?refNo=40&itemType=Container', 'Reference Number': 'NCS/TCIP/OVT/03/2024/40', 'Price': '₦1,500,150.00', 'Car Title': 'GTOU3500611', 'Condition': 'Nigeria', 'VIN': '0KG', 'Transmission': 'N/A', 'Mileage': 'N/A', 'Fuel Type': 'N/A'}
    {'URL': 'container_details.php?refNo=44&itemType=Container', 'Reference Number': 'NCS/TCIP/OVT/03/2024/44', 'Price': '₦1,785,099.00', 'Car Title': 'MSCU4554922', 'Condition': 'Nigeria', 'VIN': '0KG', 'Transmission': 'N/A', 'Mileage': 'N/A', 'Fuel Type': 'N/A'}
    {'URL': 'container_details.php?refNo=46&itemType=Container', 'Reference Number': 'NCS/TCIP/OVT/03/2024/46', 'Price': '₦1,800,000.00', 'Car Title': 'MSMU8100018', 'Condition': 'Nigeria', 'VIN': '0KG', 'Transmission': 'N/A', 'Mileage': 'N/A', 'Fuel Type': 'N/A'}
    {'URL': 'container_details.php?refNo=49&itemType=Container', 'Reference Number': 'NCS/TCIP/OVT/03/2024/49', 'Price': '₦5,200,000.00', 'Car Title': 'OOLU9157554', 'Condition': 'Nigeria', 'VIN': '0KG', 'Transmission': 'N/A', 'Mileage': 'N/A', 'Fuel Type': 'N/A'}
    {'URL': 'container_details.php?refNo=51&itemType=Container', 'Reference Number': 'NCS/TCIP/OVT/03/2024/51', 'Price': '₦4,300,040.00', 'Car Title': 'TCNU4797618', 'Condition': 'Nigeria', 'VIN': '0KG', 'Transmission': 'N/A', 'Mileage': 'N/A', 'Fuel Type': 'N/A'}
    {'URL': 'container_details.php?refNo=52&itemType=Container', 'Reference Number': 'NCS/TCIP/OVT/03/2024/52', 'Price': '₦1,500,001.00', 'Car Title': 'TEMU3549535', 'Condition': 'Nigeria', 'VIN': '0KG', 'Transmission': 'N/A', 'Mileage': 'N/A', 'Fuel Type': 'N/A'}
    {'URL': 'container_details.php?refNo=56&itemType=Container', 'Reference Number': 'NCS/TCIP/OVT/03/2024/56', 'Price': '₦1,999,999.00', 'Car Title': 'TGBU7558556', 'Condition': 'Nigeria', 'VIN': '0KG', 'Transmission': 'N/A', 'Mileage': 'N/A', 'Fuel Type': 'N/A'}
    {'URL': 'container_details.php?refNo=58&itemType=Container', 'Reference Number': 'NCS/TCIP/OVT/03/2024/58', 'Price': '₦2,500,000.00', 'Car Title': 'UETU2516220', 'Condition': 'Nigeria', 'VIN': '0KG', 'Transmission': 'N/A', 'Mileage': 'N/A', 'Fuel Type': 'N/A'}
    {'URL': 'previous_vehicle_details.php?refNo=529&itemType=Vehicle', 'Reference Number': 'NCS/01AP/OVT/03/2024/529', 'Price': '₦606,000.00', 'Car Title': 'H CIVIC CIVIC 0', 'Condition': '1HGEM21974L0069339', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=537&itemType=Vehicle', 'Reference Number': 'NCS/01AP/OVT/03/2024/537', 'Price': '₦659,000.00', 'Car Title': 'TOYOTA RAV 4 2004', 'Condition': 'JTEGD20V640009278', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=530&itemType=Vehicle', 'Reference Number': 'NCS/01AP/OVT/03/2024/530', 'Price': '₦406,030.00', 'Car Title': 'INFINITY QX4 2002', 'Condition': 'JNRDR09Y52W255064', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=531&itemType=Vehicle', 'Reference Number': 'NCS/01AP/OVT/03/2024/531', 'Price': '₦700,000.00', 'Car Title': 'PONTIAC TORRENT TORRENT 0', 'Condition': '2CKD173F276006510', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=532&itemType=Vehicle', 'Reference Number': 'NCS/01AP/OVT/03/2024/532', 'Price': '₦1,300,000.00', 'Car Title': '2007 VOLVO XC90 XC90 2007', 'Condition': 'YV4CZ982871347512', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=542&itemType=Vehicle', 'Reference Number': 'NCS/01AP/OVT/03/2024/542', 'Price': '₦980,000.00', 'Car Title': 'TOYOTA CAMRY 2003', 'Condition': '4T1BE30K73U229894', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=540&itemType=Vehicle', 'Reference Number': 'NCS/01AP/OVT/03/2024/540', 'Price': '₦884,000.00', 'Car Title': 'KIA RIO RIO 2010', 'Condition': 'KNADH4A6659970', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=545&itemType=Vehicle', 'Reference Number': 'NCS/01AP/OVT/03/2024/545', 'Price': '₦2,500,005.00', 'Car Title': 'TOYOTA COROLLA 2013', 'Condition': '5YFBU4EE3DP134991', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=546&itemType=Vehicle', 'Reference Number': 'NCS/01AP/OVT/03/2024/546', 'Price': '₦670,999.00', 'Car Title': 'MAZDA MPV MPV 2002', 'Condition': 'JMZLW28A820319581', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=533&itemType=Vehicle', 'Reference Number': 'NCS/01AP/OVT/03/2024/533', 'Price': '₦650,000.00', 'Car Title': 'OPEL VECTRA VECTRA 1997', 'Condition': 'VOLOJBF19V5229686', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=534&itemType=Vehicle', 'Reference Number': 'NCS/01AP/OVT/03/2024/534', 'Price': '₦700,000.00', 'Car Title': 'VOLK SWAGEN PASSAT PASSAT 1998', 'Condition': 'WVWZZZ3BZWEO65072', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=535&itemType=Vehicle', 'Reference Number': 'NCS/01AP/OVT/03/2024/535', 'Price': '₦600,000.00', 'Car Title': '2014 LINCON FORD 2014', 'Condition': '1LNHL9DK9EG601735', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=536&itemType=Vehicle', 'Reference Number': 'NCS/01AP/OVT/03/2024/536', 'Price': '₦620,000.00', 'Car Title': '2004 RENAULT MEGANE MEGANE 2004', 'Condition': 'VF1BMRF0531656771', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=538&itemType=Vehicle', 'Reference Number': 'NCS/01AP/OVT/03/2024/538', 'Price': '₦612,222.00', 'Car Title': 'VOLCKSWAGEN JETTA 2006', 'Condition': '3VWSG71k36M798946', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=541&itemType=Vehicle', 'Reference Number': 'NCS/01AP/OVT/03/2024/541', 'Price': '₦600,000.00', 'Car Title': 'TOYOTA CAMRY 2000', 'Condition': '4T1BG22K8YU644250', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=544&itemType=Vehicle', 'Reference Number': 'NCS/01AP/OVT/03/2024/544', 'Price': '₦1,500,000.00', 'Car Title': 'HYUNDAI AI 2007', 'Condition': '5NMSG73D57H102786', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=547&itemType=Vehicle', 'Reference Number': 'NCS/01AP/OVT/03/2024/547', 'Price': '₦1,000,000.00', 'Car Title': 'M BENZ BEZ 2000', 'Condition': 'WDBHA24GXYA832789', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=548&itemType=Vehicle', 'Reference Number': 'NCS/01AP/OVT/03/2024/548', 'Price': '₦780,000.00', 'Car Title': 'FORD EDGE EDGE 2007', 'Condition': '2FMDK49C37BA20862', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=549&itemType=Vehicle', 'Reference Number': 'NCS/01AP/OVT/03/2024/549', 'Price': '₦800,000.00', 'Car Title': 'TOYOTA CAMRY 1997', 'Condition': 'JY2BG22K4V0008102', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=577&itemType=Vehicle', 'Reference Number': 'NCS/01AP/OVT/03/2024/577', 'Price': '₦2,000,000.00', 'Car Title': 'KIA SORENTO SORENTO 2007', 'Condition': 'KNDJC736975730555', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=543&itemType=Vehicle', 'Reference Number': 'NCS/01AP/OVT/03/2024/543', 'Price': '₦1,500,096.00', 'Car Title': 'TOYOTA ACCORD 0', 'Condition': 'JHMCG65872C015122', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=551&itemType=Vehicle', 'Reference Number': 'NCS/01AP/OVT/03/2024/551', 'Price': '₦1,300,008.00', 'Car Title': 'HYUNDAI AI 2007', 'Condition': 'KMHDU46D87U066110', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=554&itemType=Vehicle', 'Reference Number': 'NCS/01AP/OVT/03/2024/554', 'Price': '₦2,100,000.00', 'Car Title': 'TOYOTA CAMRY 2005', 'Condition': '4T1BE32K05U605299', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=558&itemType=Vehicle', 'Reference Number': 'NCS/01AP/OVT/03/2024/558', 'Price': '₦1,500,000.00', 'Car Title': 'PONTIAC VIBE VIBE 2005', 'Condition': '5Y2SL638052458922', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=561&itemType=Vehicle', 'Reference Number': 'NCS/01AP/OVT/03/2024/561', 'Price': '₦2,800,000.00', 'Car Title': 'TOYOTA COROLLA COROLLA 0', 'Condition': '1NXBU4EE8AZ358509', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=550&itemType=Vehicle', 'Reference Number': 'NCS/01AP/OVT/03/2024/550', 'Price': '₦2,432,222.00', 'Car Title': 'H ACCORD ACCORD 0', 'Condition': '1HGCP2F72AA163481', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=552&itemType=Vehicle', 'Reference Number': 'NCS/01AP/OVT/03/2024/552', 'Price': '₦950,000.00', 'Car Title': 'NISSAN ALTIMA ALTIMA 0', 'Condition': '1N4AL21E89N537254', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=556&itemType=Vehicle', 'Reference Number': 'NCS/01AP/OVT/03/2024/556', 'Price': '₦598,000.00', 'Car Title': 'TOYOTA CAMRY 0', 'Condition': '4T1BG22K8XU411448', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=557&itemType=Vehicle', 'Reference Number': 'NCS/01AP/OVT/03/2024/557', 'Price': '₦810,000.00', 'Car Title': 'T SOLARA SOLARA 0', 'Condition': '4T1CA38P15U046879', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=562&itemType=Vehicle', 'Reference Number': 'NCS/01AP/OVT/03/2024/562', 'Price': '₦896,600.00', 'Car Title': 'VOLVO 680 680 0', 'Condition': 'YVIAS982481048920', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=564&itemType=Vehicle', 'Reference Number': 'NCS/01AP/OVT/03/2024/564', 'Price': '₦1,000,200.00', 'Car Title': 'H ACCORD ACCORD 2008', 'Condition': '1HGCP26348A129887', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=565&itemType=Vehicle', 'Reference Number': 'NCS/01AP/OVT/03/2024/565', 'Price': '₦1,560,000.00', 'Car Title': 'TOYOTA CAMRY 2006', 'Condition': 'JTDBE32K640270267', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=566&itemType=Vehicle', 'Reference Number': 'NCS/01AP/OVT/03/2024/566', 'Price': '₦550,000.00', 'Car Title': 'TOYOTA RAV4 RAV 4 1998', 'Condition': 'JT3GP10V5W0021127', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=568&itemType=Vehicle', 'Reference Number': 'NCS/01AP/OVT/03/2024/568', 'Price': '₦3,670,000.00', 'Car Title': 'HONDA ACCORD 2014 ACCORD 2014', 'Condition': '2HGFB2F81EH556092', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=569&itemType=Vehicle', 'Reference Number': 'NCS/01AP/OVT/03/2024/569', 'Price': '₦550,000.00', 'Car Title': 'HYUNDAI HYUNDAI 2004', 'Condition': 'KM8SC73D14U583857', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=573&itemType=Vehicle', 'Reference Number': 'NCS/01AP/OVT/03/2024/573', 'Price': '₦1,100,000.00', 'Car Title': 'HONDA CIVIC CIVIC 2002', 'Condition': '2HGES16562H504707', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=553&itemType=Vehicle', 'Reference Number': 'NCS/01TC/OVT/03/2024/553', 'Price': '₦1,600,000.00', 'Car Title': 'TOYOTA CAMRY 2003', 'Condition': '4T1BE32K03U740246', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=555&itemType=Vehicle', 'Reference Number': 'NCS/01TC/OVT/03/2024/555', 'Price': '₦1,800,000.00', 'Car Title': 'HONDA CIVIC 2004', 'Condition': '2HGES1655H561243', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=559&itemType=Vehicle', 'Reference Number': 'NCS/01TC/OVT/03/2024/559', 'Price': '₦1,611,111.00', 'Car Title': 'HONDA ACCORD 2009', 'Condition': '1HGCM56894A49128', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=563&itemType=Vehicle', 'Reference Number': 'NCS/01TC/OVT/03/2024/563', 'Price': '₦3,222,222.00', 'Car Title': 'VOLKSWAGEN BUS 1997', 'Condition': 'WV1ZZZ10ZVX046319', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=567&itemType=Vehicle', 'Reference Number': 'NCS/01TC/OVT/03/2024/567', 'Price': '₦3,500,000.00', 'Car Title': 'PONTIAC VIBE 2007', 'Condition': '5Y2SL6382574458520', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=570&itemType=Vehicle', 'Reference Number': 'NCS/01TC/OVT/03/2024/570', 'Price': '₦3,200,000.00', 'Car Title': 'HONDA ACCORD 2012', 'Condition': '1HGCP2F83CA222579', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=571&itemType=Vehicle', 'Reference Number': 'NCS/01TC/OVT/03/2024/571', 'Price': '₦1,300,000.00', 'Car Title': 'TOYOTA CAMRY 1998', 'Condition': '4TI6622K0WU289496', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=572&itemType=Vehicle', 'Reference Number': 'NCS/01TC/OVT/03/2024/572', 'Price': '₦1,000,000.00', 'Car Title': 'NISSAN ALTIMA 2003', 'Condition': '1N4AL11D63C163344', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=574&itemType=Vehicle', 'Reference Number': 'NCS/01TC/OVT/03/2024/574', 'Price': '₦490,000.00', 'Car Title': 'TOYOTA AVALON 2000', 'Condition': '4TBF28B0YU080019', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=575&itemType=Vehicle', 'Reference Number': 'NCS/01TC/OVT/03/2024/575', 'Price': '₦3,000,030.00', 'Car Title': 'TOYOTA CAMRY 2007', 'Condition': '4T1BE46K57U566115', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=578&itemType=Vehicle', 'Reference Number': 'NCS/01TC/OVT/03/2024/578', 'Price': '₦1,600,000.00', 'Car Title': 'TOYOTA SOLARA 2007', 'Condition': '2T1FF28P22C556518', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=579&itemType=Vehicle', 'Reference Number': 'NCS/01TC/OVT/03/2024/579', 'Price': '₦1,500,000.00', 'Car Title': 'TOYOTA HIGHLANDER 2002', 'Condition': 'JTEHF21AX20075050', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=580&itemType=Vehicle', 'Reference Number': 'NCS/01TC/OVT/03/2024/580', 'Price': '₦801,000.00', 'Car Title': 'TOYOTA SOLARA 2003', 'Condition': '2T1CE22P03C023616', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=581&itemType=Vehicle', 'Reference Number': 'NCS/01TC/OVT/03/2024/581', 'Price': '₦1,350,000.00', 'Car Title': 'TOYOTA CAMRY 1999', 'Condition': '4T1BF22K8XU076081', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=582&itemType=Vehicle', 'Reference Number': 'NCS/01TC/OVT/03/2024/582', 'Price': '₦1,650,000.00', 'Car Title': 'KIA CARENS 2004', 'Condition': 'KNEFC523145320212', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=583&itemType=Vehicle', 'Reference Number': 'NCS/01TC/OVT/03/2024/583', 'Price': '₦1,300,000.00', 'Car Title': 'HONDA ACCORD 2003', 'Condition': '1HGCM56313A015171', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=584&itemType=Vehicle', 'Reference Number': 'NCS/01TC/OVT/03/2024/584', 'Price': '₦1,900,000.00', 'Car Title': 'NISSAN ALTIMA ALTIMA 2007', 'Condition': '1N4AL21E37C172751', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=585&itemType=Vehicle', 'Reference Number': 'NCS/01TC/OVT/03/2024/585', 'Price': '₦2,700,000.00', 'Car Title': 'MAZDA CX-9 2008', 'Condition': 'JM3TB28A580123733', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=560&itemType=Vehicle', 'Reference Number': 'NCS/01TC/OVT/03/2024/560', 'Price': '₦3,200,000.00', 'Car Title': 'TOYOTA COROLLA COROLLA 0', 'Condition': '358509', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=586&itemType=Vehicle', 'Reference Number': 'NCS/01TC/OVT/03/2024/586', 'Price': '₦890,000.00', 'Car Title': 'TOYOTA CAMRY 0', 'Condition': 'U171054', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=588&itemType=Vehicle', 'Reference Number': 'NCS/01TC/OVT/03/2024/588', 'Price': '₦1,000,000.00', 'Car Title': 'VOLVO S4 0', 'Condition': '2026566', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=589&itemType=Vehicle', 'Reference Number': 'NCS/01TC/OVT/03/2024/589', 'Price': '₦600,000.00', 'Car Title': 'HONDA PASSPORT 0', 'Condition': 'X4427165', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=590&itemType=Vehicle', 'Reference Number': 'NCS/01TC/OVT/03/2024/590', 'Price': '₦1,200,000.00', 'Car Title': 'MAZDA  PICKUP 4X4 0', 'Condition': 'M13678', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=591&itemType=Vehicle', 'Reference Number': 'NCS/01TC/OVT/03/2024/591', 'Price': '₦3,300,000.00', 'Car Title': 'VOLCKSWAGEN GOLF 0', 'Condition': 'W438934', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=592&itemType=Vehicle', 'Reference Number': 'NCS/01TC/OVT/03/2024/592', 'Price': '₦2,500,001.00', 'Car Title': 'TOYOTA PREVIA 0', 'Condition': '1095565', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=593&itemType=Vehicle', 'Reference Number': 'NCS/01TC/OVT/03/2024/593', 'Price': '₦2,500,000.00', 'Car Title': 'TOYOTA COROLLA 0', 'Condition': 'Z190759', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=594&itemType=Vehicle', 'Reference Number': 'NCS/01TC/OVT/03/2024/594', 'Price': '₦1,000,000.00', 'Car Title': 'FORD  FOCUS 0', 'Condition': 'R14269', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=595&itemType=Vehicle', 'Reference Number': 'NCS/01TC/OVT/03/2024/595', 'Price': '₦1,005,000.00', 'Car Title': 'MERCURY   JEEP AWD V8 0', 'Condition': 'J12414', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=596&itemType=Vehicle', 'Reference Number': 'NCS/01TC/OVT/03/2024/596', 'Price': '₦1,700,000.00', 'Car Title': 'MERCEDES  BENZ 0', 'Condition': '584913', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=597&itemType=Vehicle', 'Reference Number': 'NCS/01TC/OVT/03/2024/597', 'Price': '₦650,000.00', 'Car Title': 'TOYOTA CAMRY 0', 'Condition': '573427', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=599&itemType=Vehicle', 'Reference Number': 'NCS/01TC/OVT/03/2024/599', 'Price': '₦2,330,000.00', 'Car Title': 'TOYOTA SIENNA 0', 'Condition': '288263', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=600&itemType=Vehicle', 'Reference Number': 'NCS/01TC/OVT/03/2024/600', 'Price': '₦2,800,000.00', 'Car Title': 'TOYOTA SIENNA 0', 'Condition': 'U266185', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=601&itemType=Vehicle', 'Reference Number': 'NCS/01TC/OVT/03/2024/601', 'Price': '₦2,220,000.00', 'Car Title': 'HONDA PILOT 0', 'Condition': 'B027945', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=602&itemType=Vehicle', 'Reference Number': 'NCS/01TC/OVT/03/2024/602', 'Price': '₦1,110,000.00', 'Car Title': 'MERCEDES BENZ ML300 2000', 'Condition': '4JGAB5EXWA010468', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=603&itemType=Vehicle', 'Reference Number': 'NCS/01TC/OVT/03/2024/603', 'Price': '₦1,300,000.00', 'Car Title': 'FORD  FUSION 0', 'Condition': 'R212955', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=605&itemType=Vehicle', 'Reference Number': 'NCS/01TC/OVT/03/2024/605', 'Price': '₦1,200,000.00', 'Car Title': 'TOYOTA CAMRY 0', 'Condition': 'U861931', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=606&itemType=Vehicle', 'Reference Number': 'NCS/01TC/OVT/03/2024/606', 'Price': '₦2,500,000.00', 'Car Title': 'TOYOTA COROLLA 0', 'Condition': '530956', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=608&itemType=Vehicle', 'Reference Number': 'NCS/01TC/OVT/03/2024/608', 'Price': '₦2,555,665.00', 'Car Title': 'NISSAN  XTERRA 0', 'Condition': 'C552702', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=609&itemType=Vehicle', 'Reference Number': 'NCS/01TC/OVT/03/2024/609', 'Price': '₦2,100,000.00', 'Car Title': 'HYNDAI  ELANTRA 0', 'Condition': 'U922641', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=610&itemType=Vehicle', 'Reference Number': 'NCS/01TC/OVT/03/2024/610', 'Price': '₦800,000.00', 'Car Title': 'NISSAN  MAXIMA 0', 'Condition': '512275', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=611&itemType=Vehicle', 'Reference Number': 'NCS/01TC/OVT/03/2024/611', 'Price': '₦2,000,000.00', 'Car Title': 'HONDA ACCORD 0', 'Condition': 'A003789', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=635&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/03/2024/635', 'Price': '₦999,999.00', 'Car Title': 'MAZDA MPV 2003', 'Condition': '730371950', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=636&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/03/2024/636', 'Price': '₦699,999.00', 'Car Title': 'CHRYSLER Voyager 1999', 'Condition': 'IC4GYB4R4XU126070', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=637&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/03/2024/637', 'Price': '₦6,800,000.00', 'Car Title': 'HONDA ACCORD 2014', 'Condition': 'IAGCR2E56EA027502', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=638&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/03/2024/638', 'Price': '₦850,000.00', 'Car Title': 'TOYOTA MATRIX 2001', 'Condition': '2T1KR30316L613223', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=640&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/03/2024/640', 'Price': '₦1,700,000.00', 'Car Title': 'HONDA ODYSSEY 2007', 'Condition': '5FNRL38467B045981', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=641&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/03/2024/641', 'Price': '₦1,150,000.00', 'Car Title': 'TOYOTA 4-RUNNER 2001', 'Condition': 'JT3HN86RX10334924', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=642&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/03/2024/642', 'Price': '₦1,300,000.00', 'Car Title': 'TOYOTA SIENNA 1999', 'Condition': '4T32F13C5XE136650', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=643&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/03/2024/643', 'Price': '₦1,500,000.00', 'Car Title': 'HONDA PILOT 2005', 'Condition': '5FNYF18635B009977', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=644&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/03/2024/644', 'Price': '₦780,000.00', 'Car Title': 'TOYOTA AVALON 1998', 'Condition': '4T1BF18B4WU265858', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=645&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/03/2024/645', 'Price': '₦710,000.00', 'Car Title': 'RENAULT Megane 2002', 'Condition': 'VF1JA0WN523467341', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=646&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/03/2024/646', 'Price': '₦1,750,000.00', 'Car Title': 'PONTIC VIBE 2005', 'Condition': '5425L638X52447135', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=647&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/03/2024/647', 'Price': '₦1,700,000.00', 'Car Title': 'TOYOTA SIENNA 2002', 'Condition': '4T32F19L62U484893', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=648&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/03/2024/648', 'Price': '₦670,000.00', 'Car Title': 'TOYOTA SOLARA 2005', 'Condition': '4T1CE38P25U96716', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=649&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/03/2024/649', 'Price': '₦800,000.00', 'Car Title': 'NISSAN QUEST 1998', 'Condition': '4N2ZN1118WD806169', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=650&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/03/2024/650', 'Price': '₦800,999.00', 'Car Title': 'HONDA CRV 1998', 'Condition': '1THRD1750WC253666', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=651&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/03/2024/651', 'Price': '₦1,010,000.00', 'Car Title': 'HONDA CIVIC 2004', 'Condition': 'JHMES96634S004245', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=652&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/03/2024/652', 'Price': '₦700,000.00', 'Car Title': 'CHRYSLER Pacifica 2005', 'Condition': 'ZC4GF68445R366693', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=653&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/03/2024/653', 'Price': '₦1,400,000.00', 'Car Title': 'TOYOTA CAMRY LE 2004', 'Condition': '4T1BE32K74U935021', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=654&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/03/2024/654', 'Price': '₦2,000,000.00', 'Car Title': 'TOYOTA  COROLLA 2000', 'Condition': 'JT172AEB107071446', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=655&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/03/2024/655', 'Price': '₦1,104,000.00', 'Car Title': 'HONDA ACCORD 2005', 'Condition': 'IHGCF56475A136590', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=656&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/03/2024/656', 'Price': '₦1,650,000.00', 'Car Title': 'HONDA ACCORD 2006', 'Condition': 'IHGCM56136A162160', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=657&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/03/2024/657', 'Price': '₦1,070,000.00', 'Car Title': 'TOYOTA  CAMRY 2001', 'Condition': '4TIBE32K1ZU546825', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=658&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/03/2024/658', 'Price': '₦890,000.00', 'Car Title': 'NISSAN ALTIMA 2003', 'Condition': '1N4AL11D93C342896', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=659&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/03/2024/659', 'Price': '₦930,000.00', 'Car Title': 'HYNDAI  ELANTRA 2004', 'Condition': 'KMHDN46D24U922641', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=660&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/03/2024/660', 'Price': '₦1,500,000.00', 'Car Title': 'HONDA PILOT 2001', 'Condition': '2HKF18574H502749', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=661&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/03/2024/661', 'Price': '₦2,600,000.00', 'Car Title': 'HONDA ODYSSEY 2007', 'Condition': '5WFRL38637B427001', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=662&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/03/2024/662', 'Price': '₦790,780.00', 'Car Title': 'TOYOTA  CAMRY 2002', 'Condition': '4T1BE32K32U097664', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=664&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/03/2024/664', 'Price': '₦900,000.00', 'Car Title': 'TOYOTA  AVALON 2011', 'Condition': '4TIBK3DOBU395613', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=665&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/03/2024/665', 'Price': '₦2,500,000.00', 'Car Title': 'VOLVO VOLVO 2005', 'Condition': '6YV1CZ5928511407486', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=666&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/03/2024/666', 'Price': '₦3,100,000.00', 'Car Title': 'TOYOTA  4RUNNER 2000', 'Condition': 'JTE2U14R260064975', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=667&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/03/2024/667', 'Price': '₦620,555.00', 'Car Title': 'VOYAGER VOYAGER 2000', 'Condition': '659418X', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=668&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/03/2024/668', 'Price': '₦1,130,000.00', 'Car Title': 'HYUNDAI  SANTAFE 1994', 'Condition': 'KMHSC81ARU121964', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=670&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/03/2024/670', 'Price': '₦990,000.00', 'Car Title': 'VOLVO 580 1998', 'Condition': 'YVTTS97D7X1043771', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=671&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/03/2024/671', 'Price': '₦1,030,000.00', 'Car Title': 'HONDA ACCORD 2006', 'Condition': '1HGCM551X6A006778', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=672&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/03/2024/672', 'Price': '₦2,900,000.00', 'Car Title': 'TOYOTA CAMRY 2007', 'Condition': '45139', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=673&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/03/2024/673', 'Price': '₦2,500,001.00', 'Car Title': 'LEXUS  E330 2004', 'Condition': 'JTHBA30G845028236', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=674&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/03/2024/674', 'Price': '₦1,650,000.00', 'Car Title': 'HONDA ACCORD 2012', 'Condition': '1HGCP2F44CA011680', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=675&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/03/2024/675', 'Price': '₦1,500,000.00', 'Car Title': 'BMW  325Xi 2001', 'Condition': 'WBAAV33421EE75997', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=676&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/03/2024/676', 'Price': '₦910,000.00', 'Car Title': 'HONDA ACCORD 2000', 'Condition': '1HGCG6650YA089967', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=677&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/03/2024/677', 'Price': '₦1,200,000.00', 'Car Title': 'NISSAN  NISSAN 2004', 'Condition': '1N4BA41E44C38853A', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=678&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/03/2024/678', 'Price': '₦1,400,000.00', 'Car Title': 'RANGE ROVER 2004', 'Condition': 'SALME11484A167791', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=679&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/03/2024/679', 'Price': '₦1,010,000.00', 'Car Title': 'MERCEDES BENZ C CLASS 2003', 'Condition': 'WDBRF61183A496243', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=680&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/03/2024/680', 'Price': '₦1,650,000.00', 'Car Title': 'TOYOTA CAMRY 2011', 'Condition': '4T1BE3EK2BU155336', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=681&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/03/2024/681', 'Price': '₦1,000,000.00', 'Car Title': 'HONDA PILOT 2001', 'Condition': 'A232679', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=682&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/03/2024/682', 'Price': '₦1,100,000.00', 'Car Title': 'HYUNDAI ELANTRA 2005', 'Condition': 'KMHDN46D05U188762', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=683&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/03/2024/683', 'Price': '₦1,920,000.00', 'Car Title': 'VOLKSWAGON GOLF 2000', 'Condition': 'WWWZZZ3AZSE083021', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'container_details.php?refNo=82&itemType=Container', 'Reference Number': 'NCS/TCIP/OVT/03/2024/82', 'Price': '₦1,800,000.00', 'Car Title': 'CAXU7016430', 'Condition': 'Nigeria', 'VIN': '0KG', 'Transmission': 'N/A', 'Mileage': 'N/A', 'Fuel Type': 'N/A'}
    {'URL': 'container_details.php?refNo=84&itemType=Container', 'Reference Number': 'NCS/TCIP/OVT/03/2024/84', 'Price': '₦3,000,000.00', 'Car Title': 'CSNU6953627', 'Condition': 'Nigeria', 'VIN': '0KG', 'Transmission': 'N/A', 'Mileage': 'N/A', 'Fuel Type': 'N/A'}
    {'URL': 'container_details.php?refNo=85&itemType=Container', 'Reference Number': 'NCS/TCIP/OVT/03/2024/85', 'Price': '₦3,200,000.00', 'Car Title': 'CSNU6986976', 'Condition': 'Nigeria', 'VIN': '0KG', 'Transmission': 'N/A', 'Mileage': 'N/A', 'Fuel Type': 'N/A'}
    {'URL': 'container_details.php?refNo=86&itemType=Container', 'Reference Number': 'NCS/TCIP/OVT/03/2024/86', 'Price': '₦2,800,000.00', 'Car Title': 'FCIU9150070', 'Condition': 'Nigeria', 'VIN': '0KG', 'Transmission': 'N/A', 'Mileage': 'N/A', 'Fuel Type': 'N/A'}
    {'URL': 'container_details.php?refNo=89&itemType=Container', 'Reference Number': 'NCS/TCIP/OVT/03/2024/89', 'Price': '₦2,611,111.00', 'Car Title': 'GLDU7661929', 'Condition': 'Nigeria', 'VIN': '0KG', 'Transmission': 'N/A', 'Mileage': 'N/A', 'Fuel Type': 'N/A'}
    {'URL': 'container_details.php?refNo=91&itemType=Container', 'Reference Number': 'NCS/TCIP/OVT/03/2024/91', 'Price': '₦3,100,000.00', 'Car Title': 'HLXU5332118', 'Condition': 'Nigeria', 'VIN': '0KG', 'Transmission': 'N/A', 'Mileage': 'N/A', 'Fuel Type': 'N/A'}
    {'URL': 'container_details.php?refNo=92&itemType=Container', 'Reference Number': 'NCS/TCIP/OVT/03/2024/92', 'Price': '₦2,800,000.00', 'Car Title': 'JOLU4084779', 'Condition': 'Nigeria', 'VIN': '0KG', 'Transmission': 'N/A', 'Mileage': 'N/A', 'Fuel Type': 'N/A'}
    {'URL': 'container_details.php?refNo=83&itemType=Container', 'Reference Number': 'NCS/TCIP/OVT/03/2024/83', 'Price': '₦1,550,000.00', 'Car Title': 'CBHU7014672', 'Condition': 'Nigeria', 'VIN': '0KG', 'Transmission': 'N/A', 'Mileage': 'N/A', 'Fuel Type': 'N/A'}
    {'URL': 'container_details.php?refNo=94&itemType=Container', 'Reference Number': 'NCS/PTML/OVT/03/2024/94', 'Price': '₦4,711,110.00', 'Car Title': 'APHU6646756', 'Condition': 'Nigeria', 'VIN': '0KG', 'Transmission': 'N/A', 'Mileage': 'N/A', 'Fuel Type': 'N/A'}
    {'URL': 'container_details.php?refNo=95&itemType=Container', 'Reference Number': 'NCS/PTML/OVT/03/2024/95', 'Price': '₦1,603,000.00', 'Car Title': 'BMOU3080589', 'Condition': 'Nigeria', 'VIN': '0KG', 'Transmission': 'N/A', 'Mileage': 'N/A', 'Fuel Type': 'N/A'}
    {'URL': 'container_details.php?refNo=96&itemType=Container', 'Reference Number': 'NCS/PTML/OVT/03/2024/96', 'Price': '₦2,030,000.00', 'Car Title': 'CMAU6004121', 'Condition': 'Nigeria', 'VIN': '0KG', 'Transmission': 'N/A', 'Mileage': 'N/A', 'Fuel Type': 'N/A'}
    {'URL': 'container_details.php?refNo=97&itemType=Container', 'Reference Number': 'NCS/PTML/OVT/03/2024/97', 'Price': '₦1,740,000.00', 'Car Title': 'PCIU4650313', 'Condition': 'Nigeria', 'VIN': '0KG', 'Transmission': 'N/A', 'Mileage': 'N/A', 'Fuel Type': 'N/A'}
    {'URL': 'container_details.php?refNo=98&itemType=Container', 'Reference Number': 'NCS/PTML/OVT/03/2024/98', 'Price': '₦2,050,000.00', 'Car Title': 'UACU5562311', 'Condition': 'Nigeria', 'VIN': '0KG', 'Transmission': 'N/A', 'Mileage': 'N/A', 'Fuel Type': 'N/A'}
    {'URL': 'container_details.php?refNo=99&itemType=Container', 'Reference Number': 'NCS/PTML/OVT/03/2024/99', 'Price': '₦1,560,000.00', 'Car Title': 'TRLU9113617', 'Condition': 'Nigeria', 'VIN': '0KG', 'Transmission': 'N/A', 'Mileage': 'N/A', 'Fuel Type': 'N/A'}
    {'URL': 'container_details.php?refNo=100&itemType=Container', 'Reference Number': 'NCS/PTML/OVT/03/2024/100', 'Price': '₦2,010,000.00', 'Car Title': 'SEGU1053215', 'Condition': 'Nigeria', 'VIN': '0KG', 'Transmission': 'N/A', 'Mileage': 'N/A', 'Fuel Type': 'N/A'}
    {'URL': 'container_details.php?refNo=101&itemType=Container', 'Reference Number': 'NCS/PTML/OVT/03/2024/101', 'Price': '₦1,550,000.00', 'Car Title': 'PCIU8578546', 'Condition': 'Nigeria', 'VIN': '0KG', 'Transmission': 'N/A', 'Mileage': 'N/A', 'Fuel Type': 'N/A'}
    {'URL': 'container_details.php?refNo=102&itemType=Container', 'Reference Number': 'NCS/PTML/OVT/03/2024/102', 'Price': '₦1,805,000.00', 'Car Title': 'ECMU4071329', 'Condition': 'Nigeria', 'VIN': '0KG', 'Transmission': 'N/A', 'Mileage': 'N/A', 'Fuel Type': 'N/A'}
    {'URL': 'container_details.php?refNo=103&itemType=Container', 'Reference Number': 'NCS/PTML/OVT/03/2024/103', 'Price': '₦1,600,000.00', 'Car Title': 'PIDU4056232', 'Condition': 'Nigeria', 'VIN': '0KG', 'Transmission': 'N/A', 'Mileage': 'N/A', 'Fuel Type': 'N/A'}
    {'URL': 'container_details.php?refNo=104&itemType=Container', 'Reference Number': 'NCS/PTML/OVT/03/2024/104', 'Price': '₦1,600,000.00', 'Car Title': 'PCIU1653078', 'Condition': 'Nigeria', 'VIN': '0KG', 'Transmission': 'N/A', 'Mileage': 'N/A', 'Fuel Type': 'N/A'}
    {'URL': 'container_details.php?refNo=105&itemType=Container', 'Reference Number': 'NCS/PTML/OVT/03/2024/105', 'Price': '₦1,900,000.00', 'Car Title': 'TLLU5831786', 'Condition': 'Nigeria', 'VIN': '0KG', 'Transmission': 'N/A', 'Mileage': 'N/A', 'Fuel Type': 'N/A'}
    {'URL': 'container_details.php?refNo=106&itemType=Container', 'Reference Number': 'NCS/PTML/OVT/03/2024/106', 'Price': '₦1,650,000.00', 'Car Title': 'CMAU5776938', 'Condition': 'Nigeria', 'VIN': '0KG', 'Transmission': 'N/A', 'Mileage': 'N/A', 'Fuel Type': 'N/A'}
    {'URL': 'container_details.php?refNo=107&itemType=Container', 'Reference Number': 'NCS/PTML/OVT/03/2024/107', 'Price': '₦1,600,000.00', 'Car Title': 'CLHU2795905', 'Condition': 'Nigeria', 'VIN': '0KG', 'Transmission': 'N/A', 'Mileage': 'N/A', 'Fuel Type': 'N/A'}
    {'URL': 'container_details.php?refNo=108&itemType=Container', 'Reference Number': 'NCS/PTML/OVT/03/2024/108', 'Price': '₦2,250,509.00', 'Car Title': 'TCNU2380311', 'Condition': 'Nigeria', 'VIN': '0KG', 'Transmission': 'N/A', 'Mileage': 'N/A', 'Fuel Type': 'N/A'}
    {'URL': 'container_details.php?refNo=109&itemType=Container', 'Reference Number': 'NCS/PTML/OVT/03/2024/109', 'Price': '₦1,999,766.00', 'Car Title': 'CSNU6979220', 'Condition': 'Nigeria', 'VIN': '0KG', 'Transmission': 'N/A', 'Mileage': 'N/A', 'Fuel Type': 'N/A'}
    {'URL': 'container_details.php?refNo=110&itemType=Container', 'Reference Number': 'NCS/PTML/OVT/03/2024/110', 'Price': '₦1,700,000.00', 'Car Title': 'PCIU0169958', 'Condition': 'Nigeria', 'VIN': '0KG', 'Transmission': 'N/A', 'Mileage': 'N/A', 'Fuel Type': 'N/A'}
    {'URL': 'container_details.php?refNo=111&itemType=Container', 'Reference Number': 'NCS/PTML/OVT/03/2024/111', 'Price': '₦4,511,100.00', 'Car Title': 'ACLU9779415', 'Condition': 'Nigeria', 'VIN': '0KG', 'Transmission': 'N/A', 'Mileage': 'N/A', 'Fuel Type': 'N/A'}
    {'URL': 'container_details.php?refNo=112&itemType=Container', 'Reference Number': 'NCS/PTML/OVT/03/2024/112', 'Price': '₦3,677,777.00', 'Car Title': 'GCNU1220147', 'Condition': 'Nigeria', 'VIN': '0KG', 'Transmission': 'N/A', 'Mileage': 'N/A', 'Fuel Type': 'N/A'}
    {'URL': 'container_details.php?refNo=113&itemType=Container', 'Reference Number': 'NCS/PTML/OVT/03/2024/113', 'Price': '₦4,500,000.00', 'Car Title': 'ACLU9699006', 'Condition': 'Nigeria', 'VIN': '0KG', 'Transmission': 'N/A', 'Mileage': 'N/A', 'Fuel Type': 'N/A'}
    {'URL': 'previous_vehicle_details.php?refNo=684&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/03/2024/684', 'Price': '₦1,600,000.00', 'Car Title': 'TOYOTA CAMRY 2000', 'Condition': 'JT2BG22K9Y0437532', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=685&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/03/2024/685', 'Price': '₦2,200,000.00', 'Car Title': 'TOYOTA RV4 2001', 'Condition': 'JTEHH20V910079507', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=686&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/03/2024/686', 'Price': '₦655,610.00', 'Car Title': 'LIBERTY JEEP 2003', 'Condition': '1J4GL58K23W586141', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=687&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/03/2024/687', 'Price': '₦650,000.00', 'Car Title': 'JAGUAR XF 1999', 'Condition': 'SAJAA01E5XFL19415', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=688&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/03/2024/688', 'Price': '₦456,765.00', 'Car Title': 'CHRYSLER SEBRING 2004', 'Condition': '4C3AG42GX4E151571', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=689&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/03/2024/689', 'Price': '₦800,000.00', 'Car Title': 'TRANSIT BUS 1994', 'Condition': 'WV2ZZZ70ZRHO77227', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=690&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/03/2024/690', 'Price': '₦1,150,000.00', 'Car Title': 'HONDA CIVIC 2006', 'Condition': '2HGFA16856H525653', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=691&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/03/2024/691', 'Price': '₦1,810,000.00', 'Car Title': 'NISSAN VERSA 2004', 'Condition': '3N1CN7AP4FL837450', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=692&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/03/2024/692', 'Price': '₦890,000.00', 'Car Title': 'NISSAN PATHFINDER 2009', 'Condition': '5N1AR18U49C609607', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=693&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/03/2024/693', 'Price': '₦602,151.00', 'Car Title': 'HONDA PILOT 2004', 'Condition': '5FNYF18584B008605', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=694&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/03/2024/694', 'Price': '₦1,089,000.00', 'Car Title': 'VOLKSWAGEN PASSAT 2000', 'Condition': 'WVWZZZ3BZYE266788', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=695&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/03/2024/695', 'Price': '₦1,300,666.00', 'Car Title': 'TOYOTA SIENNA 1999', 'Condition': '4T3ZF13C9XU147764', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=696&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/03/2024/696', 'Price': '₦1,354,500.00', 'Car Title': 'BMW X3 2006', 'Condition': 'WBXPA93426WG87024', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=697&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/03/2024/697', 'Price': '₦850,000.00', 'Car Title': 'HONDA ACCORD 2008', 'Condition': 'IHGCM56785A189025', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=698&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/03/2024/698', 'Price': '₦800,000.00', 'Car Title': 'NISSAN QUEST 2003', 'Condition': '5N1BV28U36N117544', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=699&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/03/2024/699', 'Price': '₦1,300,000.00', 'Car Title': 'TOYOTA HIGHLANDER 2002', 'Condition': 'JTEHF21AX20086663', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=700&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/03/2024/700', 'Price': '₦630,000.00', 'Car Title': 'HONDA CIVIC 2005', 'Condition': '2HGES16365H613199', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=701&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/03/2024/701', 'Price': '₦470,000.00', 'Car Title': 'HONDA ELEMENT 2003', 'Condition': '5J6YH286X3L053849', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=702&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/03/2024/702', 'Price': '₦691,202.00', 'Car Title': 'M BEZ ML ML 2001', 'Condition': '4JGAB57E13A407509', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=703&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/03/2024/703', 'Price': '₦1,001,023.00', 'Car Title': 'TOYOTA SIENNA 2003', 'Condition': '4T3ZF13C3WU054948', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=704&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/03/2024/704', 'Price': '₦550,000.00', 'Car Title': 'MITSUBISHI MONTERO 2000', 'Condition': 'JA4MW51R01J002654', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=705&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/03/2024/705', 'Price': '₦750,000.00', 'Car Title': 'TOYOTA 4Runner 2002', 'Condition': 'JT3GN87R2W0062564', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=706&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/03/2024/706', 'Price': '₦1,900,000.00', 'Car Title': 'LEXUS IS 2007', 'Condition': 'JTHCK262276012397', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=707&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/03/2024/707', 'Price': '₦901,000.00', 'Car Title': 'NISSAN ALTIMA 2002', 'Condition': '1N4BL2AP2CC173888', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=708&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/03/2024/708', 'Price': '₦2,003,500.00', 'Car Title': 'TOYOTA COROLLA S 2009', 'Condition': '2T18R32E93C157142', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=709&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/03/2024/709', 'Price': '₦1,777,777.00', 'Car Title': 'VOLKWAGEN PASSAT 2003', 'Condition': 'WVWZZZ3BZ3E317835', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=710&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/03/2024/710', 'Price': '₦800,000.00', 'Car Title': 'HONDA PILOT 2005', 'Condition': 'HKFY18615H569805', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=711&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/03/2024/711', 'Price': '₦1,310,000.00', 'Car Title': 'Mercedes C CLASS 2007', 'Condition': 'WDBRF92H87F919165', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=712&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/03/2024/712', 'Price': '₦950,000.00', 'Car Title': 'MAZDA 5 2007', 'Condition': 'JM1CR29L270136880', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=713&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/03/2024/713', 'Price': '₦800,000.00', 'Car Title': 'TOYOTA CAMRY 2001', 'Condition': '4T1BF22K11U130389', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=714&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/03/2024/714', 'Price': '₦560,000.00', 'Car Title': 'VOLKSWAGEN NEW BEETLE 2001', 'Condition': '3VWCK21C21M422505', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=715&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/03/2024/715', 'Price': '₦1,021,500.00', 'Car Title': 'FORD GALAXY 1999', 'Condition': 'WF0GXXPSWGXL30775', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=716&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/03/2024/716', 'Price': '₦656,450.00', 'Car Title': 'HONDA ACCORD 2007', 'Condition': '1HGCM66447A089415', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=717&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/03/2024/717', 'Price': '₦1,300,000.00', 'Car Title': 'Mercedes E 500 2004', 'Condition': 'WDBUF70J34A397879', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=718&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/03/2024/718', 'Price': '₦550,000.00', 'Car Title': 'HONDA CIVIC 2005', 'Condition': '2HGES15515H568160', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=719&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/03/2024/719', 'Price': '₦500,000.00', 'Car Title': 'SUBARU FORESTER 2003', 'Condition': 'JF1SG656038719474', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=720&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/03/2024/720', 'Price': '₦640,000.00', 'Car Title': 'TOYOTA CAMRY 2005', 'Condition': '4T1BE32K65U037673', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=721&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/03/2024/721', 'Price': '₦700,000.00', 'Car Title': 'JAGUAR XJ 1990', 'Condition': 'SAJFY1743LC625630', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=722&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/03/2024/722', 'Price': '₦1,000,100.00', 'Car Title': 'HONDA ODESSEY 2004', 'Condition': '5FNRL18554B008168', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=723&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/03/2024/723', 'Price': '₦1,300,000.00', 'Car Title': 'TOYOTA SIENNA 2000', 'Condition': '4T3ZF13C2YU202072', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=724&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/03/2024/724', 'Price': '₦900,000.00', 'Car Title': 'HONDA ACCORD 2005', 'Condition': '1HGCM56405A037965', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=725&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/03/2024/725', 'Price': '₦2,502,150.00', 'Car Title': 'TOYOTA CAMRY 2004', 'Condition': '4T1BF30K84U583373', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=726&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/03/2024/726', 'Price': '₦630,000.00', 'Car Title': 'MAZDA MPV 2007', 'Condition': 'JM3LMW28A720308216', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=727&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/03/2024/727', 'Price': '₦1,900,000.00', 'Car Title': 'TOYOTA CAMRY 2002', 'Condition': '4T1BF30K72U511237', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=728&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/03/2024/728', 'Price': '₦1,100,000.00', 'Car Title': 'TOYOTA Previa 1991', 'Condition': 'JT3AC11R0M0072082', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=729&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/03/2024/729', 'Price': '₦711,111.00', 'Car Title': 'TOYOTA CAMRY 1999', 'Condition': '4T1BG22K4XU494098', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=730&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/03/2024/730', 'Price': '₦712,611.00', 'Car Title': 'TOYOTA HIGHLANDER 2006', 'Condition': 'JTEDW21AX60011126', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=731&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/03/2024/731', 'Price': '₦860,000.00', 'Car Title': 'TOYOTA Corolla 1999', 'Condition': '2T1BR12E1XC106597', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=732&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/03/2024/732', 'Price': '₦800,000.00', 'Car Title': 'VOLKSWAGEN Golf 2000', 'Condition': 'WVWGC21J6YW750116', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=733&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/03/2024/733', 'Price': '₦1,250,000.00', 'Car Title': 'LEXUS ES 2007', 'Condition': 'JTHBJ46G672048407', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=734&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/04/2024/734', 'Price': '₦1,002,100.00', 'Car Title': 'LEXUS ES350 2009', 'Condition': 'JTHBJ46G092308349', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=735&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/04/2024/735', 'Price': '₦1,116,550.00', 'Car Title': 'FORD EDGE 2011', 'Condition': '2FMDK4JC8BBA66238', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=736&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/04/2024/736', 'Price': '₦1,021,850.00', 'Car Title': 'TOYOTA COROLLA 2003', 'Condition': '2T1BR38E73C127399', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=737&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/04/2024/737', 'Price': '₦756,320.00', 'Car Title': 'FORD E250 ECONOLINE VAN 2005', 'Condition': '1FTNE24L35HA80183', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=738&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/04/2024/738', 'Price': '₦454,333.00', 'Car Title': 'MERCEDES BENZ S430 2000', 'Condition': 'WDBNG70J9YA006824', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=739&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/04/2024/739', 'Price': '₦578,827.00', 'Car Title': 'FORD E350 ECONOLINE VAN 2002', 'Condition': '1FDSE35L42HA45022', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=740&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/04/2024/740', 'Price': '₦1,002,140.00', 'Car Title': 'TOYOTA HIGHLANDER 2006', 'Condition': 'JTEDP21A160113055', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=741&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/04/2024/741', 'Price': '₦970,122.00', 'Car Title': 'CHEVROLET CRUZE 2011', 'Condition': '1G1PC5SH4B7169429', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=742&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/04/2024/742', 'Price': '₦850,000.00', 'Car Title': 'SUBARU B9 TRIBECA 2007', 'Condition': '4S4WX82D974410718', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=743&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/04/2024/743', 'Price': '₦1,051,000.00', 'Car Title': 'LEXUS IS 250 AWD 2008', 'Condition': 'JTHCK262585025114', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=744&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/04/2024/744', 'Price': '₦485,000.00', 'Car Title': 'VOLVO XC70 2004', 'Condition': 'YV1SZ59H541127101', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=745&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/04/2024/745', 'Price': '₦701,850.00', 'Car Title': 'HYUNDAI SANTA FE 2000', 'Condition': 'KMHSC81BP5U869767', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=746&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/04/2024/746', 'Price': '₦1,054,453.00', 'Car Title': 'HONDA ACCORD 2010', 'Condition': '1HGCP2F47AA026672', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=747&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/04/2024/747', 'Price': '₦964,683.00', 'Car Title': 'VOLVO XC90 2010', 'Condition': 'YV4982CZXA1555228', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=748&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/04/2024/748', 'Price': '₦620,000.00', 'Car Title': 'FORD GALAXY 2000', 'Condition': 'WF0GXXPSWGWP69055', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=749&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/04/2024/749', 'Price': '₦678,977.00', 'Car Title': 'VOLKSWAGAN GOLF 1996', 'Condition': 'WVWZZZ1HZTW322364', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=750&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/04/2024/750', 'Price': '₦962,209.00', 'Car Title': 'LEXUS IS 250 AWD 2006', 'Condition': 'JTHCK262062002998', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=751&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/04/2024/751', 'Price': '₦821,011.00', 'Car Title': 'LEXUS RX300 2002', 'Condition': 'JTJGF10U920146581', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=752&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/04/2024/752', 'Price': '₦550,000.00', 'Car Title': 'FORD ESCAPE 2009', 'Condition': '1FMCU93GX9KA60931', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=753&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/04/2024/753', 'Price': '₦670,000.00', 'Car Title': 'NISSAN X-TRAIL 2005', 'Condition': 'JN1TBNT30U0105618', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=754&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/04/2024/754', 'Price': '₦670,000.00', 'Car Title': 'NISSAN PICK UP 2003', 'Condition': 'JN1BPUD22U0084502', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=755&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/04/2024/755', 'Price': '₦853,150.00', 'Car Title': 'TOYOTA HIGHLANDER 2002', 'Condition': 'JTEGF21A820039272', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=756&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/04/2024/756', 'Price': '₦780,000.00', 'Car Title': 'TOYOTA CAMRY 1998', 'Condition': 'JT2BF22K1W0137502', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=757&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/04/2024/757', 'Price': '₦727,110.00', 'Car Title': 'LEXUS ES300 2003', 'Condition': 'JTHBF30G230138972', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=758&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/04/2024/758', 'Price': '₦670,000.00', 'Car Title': 'OPEL OMEGA 2001', 'Condition': 'W0L0VBF6911100330', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=759&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/04/2024/759', 'Price': '₦585,000.00', 'Car Title': 'VOLKSWAGAN PASSAT 2003', 'Condition': 'WVWWH63B63E011711', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=760&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/04/2024/760', 'Price': '₦530,000.00', 'Car Title': 'VOLVO S80 2009', 'Condition': 'YV1AH992891094703', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=761&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/04/2024/761', 'Price': '₦1,351,900.00', 'Car Title': 'TOYOTA COROLLA 2006', 'Condition': '1NXBR32E96Z584579', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=762&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/04/2024/762', 'Price': '₦690,000.00', 'Car Title': 'HONDA ACCORD 2003', 'Condition': '1HGCM56894A007297', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=763&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/04/2024/763', 'Price': '₦2,701,150.00', 'Car Title': 'FORD EXPLORER 2013', 'Condition': '1FM5K8D80DGA05870', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=764&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/04/2024/764', 'Price': '₦721,000.00', 'Car Title': 'VOLKSWAGEN GOLF 2008', 'Condition': 'WVWZZZ1KZ8M364549', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=765&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/04/2024/765', 'Price': '₦800,000.00', 'Car Title': 'TOYOTA SIENNA XLE 2000', 'Condition': '4T3ZF13C8YU178778', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=766&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/04/2024/766', 'Price': '₦530,000.00', 'Car Title': 'FORD TRANSIT 2000', 'Condition': 'WF0LXXGBVLXT74051', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=767&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/04/2024/767', 'Price': '₦520,009.00', 'Car Title': 'INFINITI QX4 2002', 'Condition': 'JNRDR09Y32W258271Z', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=768&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/04/2024/768', 'Price': '₦561,111.00', 'Car Title': 'MERCEDES BENZ GENERAL 1976', 'Condition': '10702412013014', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=769&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/04/2024/769', 'Price': '₦860,989.00', 'Car Title': 'SATURN VUE 2009', 'Condition': '3GSDL43N79S562141', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=770&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/04/2024/770', 'Price': '₦500,000.00', 'Car Title': 'MITSUBUSHI SPACE STAR 2001', 'Condition': 'XMCLRDG3A2F019795', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=771&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/04/2024/771', 'Price': '₦1,251,850.00', 'Car Title': 'PONTIAC VIBE 2009', 'Condition': '5Y2SP67039Z467466', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=772&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/04/2024/772', 'Price': '₦1,011,111.00', 'Car Title': 'KIA SOUL 2010', 'Condition': 'KNDJT2A20A7176370', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=773&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/04/2024/773', 'Price': '₦571,400.00', 'Car Title': 'BMW MODEL 3 2003', 'Condition': 'WBAEU33463PH88627', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=774&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/04/2024/774', 'Price': '₦780,000.00', 'Car Title': 'FORD EDGE 2009', 'Condition': '2FMDK48C09BA82143', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=775&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/04/2024/775', 'Price': '₦600,000.00', 'Car Title': 'TOYOTA COROLLA 2002', 'Condition': '2T1BR12E22C532775', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=776&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/04/2024/776', 'Price': '₦1,313,000.00', 'Car Title': 'FORD FOCUS 2016', 'Condition': '1FADP3E25GL360923', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=777&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/04/2024/777', 'Price': '₦1,052,498.00', 'Car Title': 'TOYOTA SIENNA 2005', 'Condition': '5TDZA23C25S332712', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=778&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/04/2024/778', 'Price': '₦650,000.00', 'Car Title': 'VOLKSWAGEN GOLF 1995', 'Condition': 'WVWZZZ1HZSB136654', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=779&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/04/2024/779', 'Price': '₦641,809.00', 'Car Title': 'MERCEDES BENZ C200 2006', 'Condition': 'WDB2032451F129281', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=780&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/04/2024/780', 'Price': '₦800,000.00', 'Car Title': 'FORD FOCUS 2006', 'Condition': '1FAFP34N26W206641', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=781&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/04/2024/781', 'Price': '₦1,193,080.00', 'Car Title': 'HYUNDAI ELANTRA 2010', 'Condition': 'KMHDU4AD3AU017704', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=783&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/04/2024/783', 'Price': '₦1,033,333.00', 'Car Title': 'HONDA ODYSSEY 2006', 'Condition': '5FNRL38816B071101', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=784&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/04/2024/784', 'Price': '₦700,000.00', 'Car Title': 'TOYOTA SIENNA 2004', 'Condition': '5TDZA23C04S124388', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=785&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/04/2024/785', 'Price': '₦800,000.00', 'Car Title': 'MERCEDES BENZ C180 2006', 'Condition': 'WDB2020781F913465', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=786&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/04/2024/786', 'Price': '₦1,201,149.00', 'Car Title': 'MERCEDES BENZ C180 2006', 'Condition': 'WDB2020781F844902', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=787&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/04/2024/787', 'Price': '₦590,000.00', 'Car Title': 'MERCEDES BENZ C180 1997', 'Condition': 'WDB2020781F829338', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=788&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/04/2024/788', 'Price': '₦690,000.00', 'Car Title': 'TOYOTA PREVIA 1992', 'Condition': 'JT3AC11R9N1019294', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=789&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/04/2024/789', 'Price': '₦830,000.00', 'Car Title': 'HONDA ODYSSEY 2005', 'Condition': '5FNRL38295B090991', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=790&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/04/2024/790', 'Price': '₦734,433.00', 'Car Title': 'JAGUAR XJ8 1998', 'Condition': 'SAJHX1249WC848763', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=791&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/04/2024/791', 'Price': '₦1,015,000.00', 'Car Title': 'VOLVO XC90 2008', 'Condition': 'YV4CZ982681418935', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=792&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/04/2024/792', 'Price': '₦900,000.00', 'Car Title': 'NISSAN VERSA 2007', 'Condition': '3N1BC13E17L360584', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=793&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/04/2024/793', 'Price': '₦610,111.00', 'Car Title': 'NISSAN TINO 2005', 'Condition': 'VSKTBAV10U0197909', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=794&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/04/2024/794', 'Price': '₦653,410.00', 'Car Title': 'NISSAN ALTIMA 2011', 'Condition': '1N4AL2AP9BN404025', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=795&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/04/2024/795', 'Price': '₦590,000.00', 'Car Title': 'FORD FOCUS 2007', 'Condition': '1FAFP36N97W146646', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=796&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/04/2024/796', 'Price': '₦905,409.00', 'Car Title': 'TOYOTA AVALON 2002', 'Condition': '4T1BF28B22U248931', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=797&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/04/2024/797', 'Price': '₦1,418,333.00', 'Car Title': 'LEXUS ES350 2008', 'Condition': 'JTHBJ46G082210629', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=798&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/04/2024/798', 'Price': '₦475,900.00', 'Car Title': 'BMW 740 2000', 'Condition': 'WBAGH8341YDP16475', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=799&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/04/2024/799', 'Price': '₦623,999.00', 'Car Title': 'VOLKSWAGEN POLO 2004', 'Condition': 'WVWZZZ9NZ4Y007483', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=800&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/04/2024/800', 'Price': '₦580,000.00', 'Car Title': 'KIA SEDONA 2007', 'Condition': 'KNDMB233476106164', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=801&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/04/2024/801', 'Price': '₦850,000.00', 'Car Title': 'NISSAN VERSA 2009', 'Condition': '3N1BC13E99L419433', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=802&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/04/2024/802', 'Price': '₦550,000.00', 'Car Title': 'CHRYSLER PACIFICA 2006', 'Condition': '2A8GF68446R698594', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=803&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/04/2024/803', 'Price': '₦677,000.00', 'Car Title': 'ACURA MDX 2001', 'Condition': '2HNYD18811H512963', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=804&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/04/2024/804', 'Price': '₦650,000.00', 'Car Title': 'MERCEDES BENZ C200 2002', 'Condition': 'WDB2032421F297683', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=805&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/04/2024/805', 'Price': '₦802,099.00', 'Car Title': 'HONDA CIVIC 2010', 'Condition': '2HGFA1F53AH530171', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=806&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/04/2024/806', 'Price': '₦600,000.00', 'Car Title': 'MITSUBISHI LANCER 2001', 'Condition': 'JMBLREA5WWZ000193', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=807&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/04/2024/807', 'Price': '₦865,000.00', 'Car Title': 'TOYOTA SIENNA 2005', 'Condition': '5TDBA23C05S052921', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=808&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/04/2024/808', 'Price': '₦750,000.00', 'Car Title': 'SUZUKI FORENZA 2008', 'Condition': 'KL5JD56Z08K301837', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=809&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/04/2024/809', 'Price': '₦1,422,200.00', 'Car Title': 'TOYOTA CAMRY 2009', 'Condition': '4T1BE46K39U873351', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=810&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/04/2024/810', 'Price': '₦984,330.00', 'Car Title': 'VOLVO XC90 2007', 'Condition': 'YV4CZ982471407463', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=811&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/04/2024/811', 'Price': '₦912,410.00', 'Car Title': 'TOYOTA SIENNA 2002', 'Condition': '4T3ZF13C52U416805', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=812&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/04/2024/812', 'Price': '₦800,000.00', 'Car Title': 'NISSAN PATHFINDER 2003', 'Condition': 'JN8DR09Y13W810677', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=813&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/04/2024/813', 'Price': '₦1,058,509.00', 'Car Title': 'TOYOTA COROLLA 2006', 'Condition': '2T1BR32E56C584080', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=814&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/04/2024/814', 'Price': '₦730,222.00', 'Car Title': 'MITSUBISHI SPACE WAGON 1998', 'Condition': 'JMBLNN84WYZ002072', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=815&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/04/2024/815', 'Price': '₦555,555.00', 'Car Title': 'MERCEDES BENZ E320 2003', 'Condition': 'WDEUF65JX3A157200', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=816&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/04/2024/816', 'Price': '₦684,000.00', 'Car Title': 'KIA FORTE 2010', 'Condition': 'KNAFU4AZXA5852699', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=817&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/04/2024/817', 'Price': '₦501,000.00', 'Car Title': 'TOYOTA SOLARA 2005', 'Condition': '4T1CE3825U969716', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=818&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/04/2024/818', 'Price': '₦611,001.00', 'Car Title': 'HYUNDAI ACCENT 2006', 'Condition': 'KMHCN46C76U051077', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=819&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/04/2024/819', 'Price': '₦452,189.00', 'Car Title': 'MISTIBUSHI SPACE STAR 1999', 'Condition': 'XMCLNDG5AXF070530', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=820&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/04/2024/820', 'Price': '₦500,000.00', 'Car Title': 'MERCEDES BENZ C300 0', 'Condition': '463502', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=821&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/04/2024/821', 'Price': '₦580,524.00', 'Car Title': 'HONDA PILOT 2004', 'Condition': '2HKYF18404H597061', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=822&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/04/2024/822', 'Price': '₦492,200.00', 'Car Title': 'NISSAN ALTIMA 3.5SE V6 2003', 'Condition': '1N4BL11D33C178498', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=823&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/04/2024/823', 'Price': '₦445,812.00', 'Car Title': 'TOYOTA COROLLA 2007', 'Condition': '1NXBR32E57Z912954', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=824&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/04/2024/824', 'Price': '₦631,000.00', 'Car Title': 'TOYOTA CAMRY LE 2002', 'Condition': '4T4DF1FK40RZ51950', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=825&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/04/2024/825', 'Price': '₦425,000.00', 'Car Title': 'MERCEDES BENZ E320 1998', 'Condition': 'WDBJF6SF8WA643250', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=826&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/04/2024/826', 'Price': '₦445,000.00', 'Car Title': 'MERCEDES BENZ C320 2001', 'Condition': 'WDBRF64J21F076344', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=827&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/04/2024/827', 'Price': '₦450,000.00', 'Car Title': 'TOYOTA AVALON 2003', 'Condition': '4T1BF2BB33U301539', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=828&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/04/2024/828', 'Price': '₦510,000.00', 'Car Title': 'HYUNDAI NELSON 2008', 'Condition': '5NPEU46F38H367518', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=829&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/04/2024/829', 'Price': '₦540,000.00', 'Car Title': 'TOYOTA AVENSIS 2010', 'Condition': 'SB164ABN10E078537', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=830&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/04/2024/830', 'Price': '₦530,000.00', 'Car Title': 'PEUGEOT 807 2001', 'Condition': 'BF3EB4HWB613089597', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=831&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/04/2024/831', 'Price': '₦1,560,000.00', 'Car Title': 'HONDA CIVIC 2006', 'Condition': '2HGFG12866H562926', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=832&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/04/2024/832', 'Price': '₦460,999.00', 'Car Title': 'NISSAN XTERRA 2000', 'Condition': '5N1ED28TXYC552941', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=833&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/04/2024/833', 'Price': '₦480,000.00', 'Car Title': 'TOYOTA CAMRY 2009', 'Condition': '4T1BE46K2912387', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=834&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/04/2024/834', 'Price': '₦580,000.00', 'Car Title': 'TOYOTA CAMRY LE 2001', 'Condition': '4T1BG22K614068579', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=835&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/04/2024/835', 'Price': '₦480,000.00', 'Car Title': 'MISTIBUSHI GALLANT 2007', 'Condition': '4A3AB36F47E041818', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=836&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/04/2024/836', 'Price': '₦610,000.00', 'Car Title': 'VOLKSWAGEN GOLF 1996', 'Condition': 'WVW2221K26B161317', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=837&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/04/2024/837', 'Price': '₦600,000.00', 'Car Title': 'OPEL ASTRA 1.9 2005', 'Condition': 'W0L0AHL3555191406', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=838&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/04/2024/838', 'Price': '₦772,000.00', 'Car Title': 'HONDA FIT 2008', 'Condition': 'JHMGD38658S047178', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=839&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/04/2024/839', 'Price': '₦501,200.00', 'Car Title': 'BMW 520i 2000', 'Condition': 'WBADR11080GT00742', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=840&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/04/2024/840', 'Price': '₦490,000.00', 'Car Title': 'MAZDA MPV ES 2000', 'Condition': 'JM3LW28G6Y0116783', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=841&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/04/2024/841', 'Price': '₦480,000.00', 'Car Title': 'FORD FOCUS 2010', 'Condition': 'WX0AXXGCDAWB65028', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=842&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/04/2024/842', 'Price': '₦490,000.00', 'Car Title': 'TOYOTA SIENNA LE 2002', 'Condition': '5TDYKEDC4ES509080', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=843&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/04/2024/843', 'Price': '₦470,000.00', 'Car Title': 'AUDI A4 2008', 'Condition': 'WAUDF78E18A133104', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=844&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/04/2024/844', 'Price': '₦588,111.00', 'Car Title': 'KIA SORENTO 2009', 'Condition': 'KNDJDF35X95868998', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=845&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/04/2024/845', 'Price': '₦609,111.00', 'Car Title': 'TOYOTA CAMRY XLE 2007', 'Condition': '4T1BE46K07U1A3927', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=846&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/04/2024/846', 'Price': '₦874,000.00', 'Car Title': 'FORD FOCUS 2016', 'Condition': '1FADP3F28GL305266', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=847&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/04/2024/847', 'Price': '₦420,000.00', 'Car Title': 'MAZDA 3 1998', 'Condition': 'JM1BK12F681824956', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=848&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/04/2024/848', 'Price': '₦485,000.00', 'Car Title': 'HONDA ACCORD 2007', 'Condition': '1HGCM71747A001924', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=849&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/04/2024/849', 'Price': '₦503,600.00', 'Car Title': 'TOYOTA CAMRY LE 2007', 'Condition': '4T1BE46KX7U073322', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=850&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/04/2024/850', 'Price': '₦522,900.00', 'Car Title': 'LEXUS ES350 2003', 'Condition': 'JTHBF30G336019051', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=851&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/04/2024/851', 'Price': '₦582,828.00', 'Car Title': 'VOLKSWAGEN GOLF 3 1996', 'Condition': 'WVWZZZ1HZTW438934', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=852&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/04/2024/852', 'Price': '₦570,000.00', 'Car Title': 'TOYOTA CAMRY LE 2007', 'Condition': '4T1BE46K67U088285', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=853&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/04/2024/853', 'Price': '₦435,000.00', 'Car Title': 'MERCEDES BEN A Class 2001', 'Condition': '007805', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=854&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/04/2024/854', 'Price': '₦440,010.00', 'Car Title': 'TOYOTA CAMRY LE 2001', 'Condition': '4T1BG22K91U823126', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=855&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/04/2024/855', 'Price': '₦490,000.00', 'Car Title': 'TOYOTA MATRIX XR 2005', 'Condition': '2T1KR32E25C875022', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=856&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/04/2024/856', 'Price': '₦450,000.00', 'Car Title': 'MAZDA 6 2005', 'Condition': '1YVHP80D565M51284', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=857&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/04/2024/857', 'Price': '₦525,000.00', 'Car Title': 'VOLVO S40 2005', 'Condition': 'YVIMH682X52114659', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=858&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/04/2024/858', 'Price': '₦490,000.00', 'Car Title': 'TOYOTA CAMRY LE 2001', 'Condition': '4T1UG22K41U086692', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=859&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/04/2024/859', 'Price': '₦560,000.00', 'Car Title': 'MAZDA MPV 2003', 'Condition': 'JM3W28A330378782', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=860&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/04/2024/860', 'Price': '₦460,111.00', 'Car Title': 'TOYOTA CAMRY LE 2004', 'Condition': '4T1BE32K74U935021', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=861&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/04/2024/861', 'Price': '₦480,000.00', 'Car Title': 'HONDA CIVIC 2000', 'Condition': '5HHMB2710YU156707', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=862&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/04/2024/862', 'Price': '₦500,000.00', 'Car Title': 'NISSAN MURANO 2003', 'Condition': 'JN8A205W23W210351', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=863&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/04/2024/863', 'Price': '₦470,000.00', 'Car Title': 'MERCEDES BENZ A190 2001', 'Condition': 'WTE16803211310362', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=864&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/04/2024/864', 'Price': '₦430,000.00', 'Car Title': 'HONDA ODYSSEY 2000', 'Condition': '2HKRL1861YA553140', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=865&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/04/2024/865', 'Price': '₦608,619.00', 'Car Title': 'LEXUS ES330 2004', 'Condition': 'JTHBA30GX45020347', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=866&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/04/2024/866', 'Price': '₦520,000.00', 'Car Title': 'MERCEDES BENZ C240 0', 'Condition': '569606', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=867&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/04/2024/867', 'Price': '₦1,017,542.00', 'Car Title': 'TOYOTA COROLLA 2009', 'Condition': 'JTDBL40E19J003578', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=868&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/04/2024/868', 'Price': '₦480,007.00', 'Car Title': 'CHEVROLET OPENBODY 2001', 'Condition': '1GCEC14W012333796', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=869&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/04/2024/869', 'Price': '₦610,000.00', 'Car Title': 'FORD ESCAPE 2008', 'Condition': '1FMCU03128KA78751', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=870&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/04/2024/870', 'Price': '₦426,700.00', 'Car Title': 'HONDA ACCORD LX 2001', 'Condition': '1HGCG65571A061342', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=871&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/04/2024/871', 'Price': '₦425,999.00', 'Car Title': 'TOYOTA COROLLA 2010', 'Condition': '1NXBU4EE6AZ383909', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=872&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/04/2024/872', 'Price': '₦470,300.00', 'Car Title': 'HYUNDAI SANTA FE 2004', 'Condition': 'KM8SC73E94U727003', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=873&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/04/2024/873', 'Price': '₦580,000.00', 'Car Title': 'PONTIAC VIBE TORRENT 2008', 'Condition': '2CKD143F886050799', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=874&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/04/2024/874', 'Price': '₦575,000.00', 'Car Title': 'TOYOTA SIENNA 2000', 'Condition': '4T32F19C8YU268777', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=875&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/04/2024/875', 'Price': '₦440,999.00', 'Car Title': 'NISSAN ALMERA 2000', 'Condition': '5JFDAN16U0105224', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=876&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/04/2024/876', 'Price': '₦455,000.00', 'Car Title': 'FORD FOCUS 2001', 'Condition': 'WF0AXXGCDA1K02264', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=877&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/04/2024/877', 'Price': '₦500,000.00', 'Car Title': 'HONDA ACCORD 2003', 'Condition': '1HGCM563838067221', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=878&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/04/2024/878', 'Price': '₦700,000.00', 'Car Title': 'TOYOTA SIENNA XLE 2005', 'Condition': '4T3ZF13XYU28863', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=881&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/05/2024/881', 'Price': '₦675,460.00', 'Car Title': 'MERCEDES BENZ C32 2001', 'Condition': 'WDBRF64J71F125201', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=882&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/05/2024/882', 'Price': '₦864,470.00', 'Car Title': 'TOYOTA MATRIX 2003', 'Condition': '2T1KR32E03C098319', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=883&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/05/2024/883', 'Price': '₦475,500.00', 'Car Title': 'JAGUAR STYPE 1999', 'Condition': 'SAJAA01E5XF1L19415', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=884&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/05/2024/884', 'Price': '₦924,000.00', 'Car Title': 'BMW 745LI 2003', 'Condition': 'WBAGN63473DR12961', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=885&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/05/2024/885', 'Price': '₦720,022.00', 'Car Title': 'TOYOTA CAMRY 2000', 'Condition': '4T1UG22K7YU674810', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=886&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/05/2024/886', 'Price': '₦595,000.00', 'Car Title': 'CHEVROLET PICKUP 2001', 'Condition': '1GCCS145418193744', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=887&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/05/2024/887', 'Price': '₦601,000.00', 'Car Title': 'HYUNDAI ELENTRA 2002', 'Condition': 'KMHDN54022U371237', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=888&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/05/2024/888', 'Price': '₦1,508,090.00', 'Car Title': 'TOYOTA CAMRY 2004', 'Condition': '4T1BE32K94U933755', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=889&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/05/2024/889', 'Price': '₦879,221.00', 'Car Title': 'TOYOTA CAMRY 2003', 'Condition': '4T1BE32K83U124312', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=890&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/05/2024/890', 'Price': '₦530,000.00', 'Car Title': 'HONDA ACCORD 2004', 'Condition': '1HGCN66554A089282', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=891&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/05/2024/891', 'Price': '₦900,000.00', 'Car Title': 'MAZDA LX 2003', 'Condition': 'JM3LW28A830345535', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=892&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/05/2024/892', 'Price': '₦540,000.00', 'Car Title': 'FORD MONDEO 2010', 'Condition': 'WF0AXXGBBAXJ20155', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=893&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/05/2024/893', 'Price': '₦877,777.00', 'Car Title': 'TOYOTA CAMRY 1999', 'Condition': '4T1BG22K3XU403418', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=894&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/05/2024/894', 'Price': '₦920,000.00', 'Car Title': 'HONDA ACCORD 2010', 'Condition': 'IHGCP2F87CAA147952', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=895&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/05/2024/895', 'Price': '₦735,160.00', 'Car Title': 'TOYOTA CAMRY 2005', 'Condition': '4T1BF30K25U107508', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=896&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/05/2024/896', 'Price': '₦490,000.00', 'Car Title': 'RANGE ROVER 46 SE 2001', 'Condition': 'SALPL164X1A451320', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=897&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/05/2024/897', 'Price': '₦734,121.00', 'Car Title': 'TOYOTA COROLLA 2003', 'Condition': '1NXBR32E03Z045683', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=899&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/05/2024/899', 'Price': '₦580,000.00', 'Car Title': 'AUDI TDI 2002', 'Condition': 'WAUZZZ8EX2A216496', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=900&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/05/2024/900', 'Price': '₦662,000.00', 'Car Title': 'MAZDA MPV 2010', 'Condition': 'JM3WW28A330378782', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=901&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/05/2024/901', 'Price': '₦560,000.00', 'Car Title': 'OPEL VECTRA 1998', 'Condition': 'W0L0JBF19W1032590', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=902&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/05/2024/902', 'Price': '₦1,763,090.00', 'Car Title': 'TOYOTA SIENNA 2010', 'Condition': '5TDYK4CC0AS295707', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=904&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/05/2024/904', 'Price': '₦452,002.00', 'Car Title': 'NISSAN PATHFINDER 2001', 'Condition': 'JN80R09XB1W561443', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=905&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/05/2024/905', 'Price': '₦822,222.00', 'Car Title': 'NISSAN ALTIMA 2003', 'Condition': '1N4BL11D33C178498', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=906&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/05/2024/906', 'Price': '₦602,000.00', 'Car Title': 'TOYOTA SIENNA 2001', 'Condition': '4T32F13C41U328536', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=907&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/05/2024/907', 'Price': '₦927,090.00', 'Car Title': 'HYUNDAI  SUNATA 2007', 'Condition': '5NPETA6CX7H252194', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=908&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/05/2024/908', 'Price': '₦921,000.00', 'Car Title': 'HYUNDAI  ELANTRA 2008', 'Condition': 'KMHD446D584525014', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=909&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/05/2024/909', 'Price': '₦1,890,000.00', 'Car Title': 'NISSAN  MURANO SL 2010', 'Condition': 'JN8AZ1MU4AW005945', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=910&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/05/2024/910', 'Price': '₦670,000.00', 'Car Title': 'NISSAN  FRONTIER 2004', 'Condition': '1N6ED27T04C430134', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=911&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/05/2024/911', 'Price': '₦510,000.00', 'Car Title': 'MERCEDES BENZ  E320 2004', 'Condition': 'WDBUH65J54A460008', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=912&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/05/2024/912', 'Price': '₦520,111.00', 'Car Title': 'FORD  RANGER 1994', 'Condition': '1FTCR15U0RTA51627', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=913&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/05/2024/913', 'Price': '₦720,999.00', 'Car Title': 'CHEVROLET  EQUINOR LS 2005', 'Condition': '2CNDI13F856109797', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=914&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/05/2024/914', 'Price': '₦560,000.00', 'Car Title': 'HONDA ODESSEY 2007', 'Condition': '5FNRL38777B115773', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=915&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/05/2024/915', 'Price': '₦500,320.00', 'Car Title': 'INFINITI  QX4 1998', 'Condition': 'JNRAR05Y9WW024424', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=916&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/05/2024/916', 'Price': '₦760,005.00', 'Car Title': 'OPEL  ASTRA 1.9 2005', 'Condition': 'W0L0AHL3555191406', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=917&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/05/2024/917', 'Price': '₦900,000.00', 'Car Title': 'VOLKSWAGEN PASSAT 2.0I 2006', 'Condition': 'WVWAK73C26P046796', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=918&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/05/2024/918', 'Price': '₦803,000.00', 'Car Title': 'TOYOTA CAMRY  2002', 'Condition': '4T1BE32K82U595858', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=919&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/05/2024/919', 'Price': '₦1,311,460.00', 'Car Title': 'PEUGEOT  406 2008', 'Condition': 'VF38BLFYT80993857', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=920&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/05/2024/920', 'Price': '₦630,000.00', 'Car Title': 'HONDA  ACCORD 2001', 'Condition': '1HGCG22501A012854', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=922&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/05/2024/922', 'Price': '₦551,161.00', 'Car Title': 'TOYOTA  AVENSIS 2001', 'Condition': 'XBI64ABX110E078537', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=923&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/05/2024/923', 'Price': '₦590,135.00', 'Car Title': 'MAZDA  MPV 2000', 'Condition': 'JM3LW2HT3Y0113615', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=924&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/05/2024/924', 'Price': '₦3,003,390.00', 'Car Title': 'TOYOTA  VENZA 2009', 'Condition': '4T3ZK11A69U006747', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=925&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/05/2024/925', 'Price': '₦1,551,140.00', 'Car Title': 'TOYOTA  RAV 4 2006', 'Condition': 'JTMBK31V265011026', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=926&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/05/2024/926', 'Price': '₦630,999.00', 'Car Title': 'HONDA  ACCORD 2012', 'Condition': '1HGCP3F85CA024236', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=927&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/05/2024/927', 'Price': '₦608,566.00', 'Car Title': 'MERCEDES BENZ  C230 2007', 'Condition': 'WDBRF52H17E026236', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=928&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/05/2024/928', 'Price': '₦801,375.00', 'Car Title': 'MAZDA  CX-9 2007', 'Condition': 'JM3TB28Y370112273', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=929&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/05/2024/929', 'Price': '₦872,720.00', 'Car Title': 'TOYOTA  SIENNA 1999', 'Condition': '4T3ZF13C4XU170370', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=930&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/05/2024/930', 'Price': '₦782,140.00', 'Car Title': 'TOYOTA  TUNDRA 2002', 'Condition': '5TBBT44162S265430', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=931&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/05/2024/931', 'Price': '₦650,000.00', 'Car Title': 'MAZDA   MAZDA 3 2006', 'Condition': 'JM1BK12F361400812', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=932&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/05/2024/932', 'Price': '₦530,000.00', 'Car Title': 'MERCEDES BENZ  C230 2006', 'Condition': 'WDBRF52H86881893', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=933&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/05/2024/933', 'Price': '₦1,344,111.00', 'Car Title': 'BMW  X2 2020', 'Condition': 'WBXYJ1C04L5P32644', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=934&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/05/2024/934', 'Price': '₦552,222.00', 'Car Title': 'NISSAN  MAXIMA 2008', 'Condition': '1N4BA41E58C820498', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=935&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/05/2024/935', 'Price': '₦803,000.00', 'Car Title': 'LEXUS  GS350 2008', 'Condition': 'JTHBE96S980030230', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=936&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/05/2024/936', 'Price': '₦684,000.00', 'Car Title': 'HONDA  ACCORD COUPE 2017', 'Condition': '1HGCT2B89HA001044', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=937&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/05/2024/937', 'Price': '₦1,122,140.00', 'Car Title': 'HONDA  CROSSTOUR EX-L 2012', 'Condition': '5J6TFBH34CL002262', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=938&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/05/2024/938', 'Price': '₦480,900.00', 'Car Title': 'HONDA  ACCORD 1993', 'Condition': '1HGCB7653PA168465', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=939&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/05/2024/939', 'Price': '₦821,240.00', 'Car Title': 'TOYOTA  CAMRY 2002', 'Condition': '4T1BE32K82U501171', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=940&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/05/2024/940', 'Price': '₦1,003,539.00', 'Car Title': 'TOYOTA  TACOMA 2009', 'Condition': '5TETX22N29Z644111', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=941&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/05/2024/941', 'Price': '₦762,439.00', 'Car Title': 'CITROEN  JUMPER HAIL 2006', 'Condition': 'VF7ZBPMNC17724454', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=942&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/05/2024/942', 'Price': '₦700,000.00', 'Car Title': 'PORSCHE  CAYENNE  2005', 'Condition': 'WP1AB29P65LA63909', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=943&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/05/2024/943', 'Price': '₦660,000.00', 'Car Title': 'FORD  EDGE 2015', 'Condition': '2FMPK4K89FBC31467', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=945&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/05/2024/945', 'Price': '₦1,406,110.00', 'Car Title': 'TOYOTA  CAMRY 2012', 'Condition': '4T1BF1FKXCU030654', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=946&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/05/2024/946', 'Price': '₦525,000.00', 'Car Title': 'HONDA  ACCORD 2004', 'Condition': '1HGCM56624A088030', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=947&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/05/2024/947', 'Price': '₦585,000.00', 'Car Title': 'HONDA  CIVIC 2006', 'Condition': '1HGFA16516L094351', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=948&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/05/2024/948', 'Price': '₦600,000.00', 'Car Title': 'HONDA  ACCORD 2005', 'Condition': '1HGCM56475A137030', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=949&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/05/2024/949', 'Price': '₦485,000.00', 'Car Title': 'VOLKSWAGEN  PASSAT 2001', 'Condition': 'WVWPH63B41E153069', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=950&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/05/2024/950', 'Price': '₦560,000.00', 'Car Title': 'VOLVO   XC90 2005', 'Condition': 'YV1CM592251158046', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=951&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/05/2024/951', 'Price': '₦635,640.00', 'Car Title': 'HONDA  ACCORD 2016', 'Condition': '1HGCR2F90GA159806', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=952&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/05/2024/952', 'Price': '₦820,000.00', 'Car Title': 'TOYOTA  COROLLA 2004', 'Condition': '1NXBR32E04Z341983', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=953&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/05/2024/953', 'Price': '₦802,140.00', 'Car Title': 'TOYOTA  CAMRY 2017', 'Condition': '4T1BF1FK2HU387138', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=954&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/05/2024/954', 'Price': '₦600,000.00', 'Car Title': 'MERCEDES BENZ  C240 4MATIC 2004', 'Condition': 'WDBRF81J84F493181', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=955&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/05/2024/955', 'Price': '₦1,050,000.00', 'Car Title': 'UNIC  TRUCK+1 1992', 'Condition': 'ZCFA6581002993426', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=956&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/05/2024/956', 'Price': '₦621,000.00', 'Car Title': 'DODGE RAM  PICK-UP 1999', 'Condition': '187GG22XXYS555974', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=957&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/05/2024/957', 'Price': '₦501,000.00', 'Car Title': 'MERCEDES BENZ  ML430 1997', 'Condition': '4JGAB57E83A410407', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=958&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/05/2024/958', 'Price': '₦459,999.00', 'Car Title': 'MITSUBISHI  ENDEAVOR 4WD 2008', 'Condition': '444MN21S78E018405', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=959&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/05/2024/959', 'Price': '₦898,321.00', 'Car Title': 'Lexus IS 250 2008', 'Condition': 'JTHBK262085066665', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=960&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/05/2024/960', 'Price': '₦600,500.00', 'Car Title': 'HONDA  PILOT 2005', 'Condition': '2HKYF18615H569305', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=961&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/05/2024/961', 'Price': '₦600,000.00', 'Car Title': 'RENAULT  MEGANE 2002', 'Condition': 'VF1BA040222216471', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=962&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/05/2024/962', 'Price': '₦460,000.00', 'Car Title': 'ACURA  TSX 2002', 'Condition': '19UUA56942A008277', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=963&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/05/2024/963', 'Price': '₦642,144.00', 'Car Title': 'HONDA  CIVIC  2010', 'Condition': '2HGFA1FS5AH3203333', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=944&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/05/2024/944', 'Price': '₦1,026,410.00', 'Car Title': 'LEXUS  RX 330 2005', 'Condition': '2T2GA31UX5C029500', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=964&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/06/2024/964', 'Price': '₦445,000.00', 'Car Title': 'HONDA  ACCORD 1994', 'Condition': '1HGCD563XRA125709', 'VIN': 'Used', 'Transmission': 'AUTOMATIC', 'Mileage': '0.00KM', 'Fuel Type': 'PETROL'}
    {'URL': 'previous_vehicle_details.php?refNo=965&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/06/2024/965', 'Price': '₦1,700,001.00', 'Car Title': 'TOYOTA CAMRY 2000', 'Condition': '4T1BF28K0YU956118', 'VIN': 'Used', 'Transmission': 'AUTOMATIC', 'Mileage': '0.00KM', 'Fuel Type': 'PETROL'}
    {'URL': 'previous_vehicle_details.php?refNo=966&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/06/2024/966', 'Price': '₦3,100,000.00', 'Car Title': 'VOLKSWAGEN  GOLF 1997', 'Condition': 'WVWZZZ1HZVW357268', 'VIN': 'Used', 'Transmission': 'AUTOMATIC', 'Mileage': '0.00KM', 'Fuel Type': 'PETROL'}
    {'URL': 'previous_vehicle_details.php?refNo=967&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/06/2024/967', 'Price': '₦666,666.00', 'Car Title': 'HONDA  ACCORD 1992', 'Condition': '1HGCB7555NA232679', 'VIN': 'Used', 'Transmission': 'AUTOMATIC', 'Mileage': '0.00KM', 'Fuel Type': 'PETROL'}
    {'URL': 'previous_vehicle_details.php?refNo=968&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/06/2024/968', 'Price': '₦1,000,000.00', 'Car Title': 'HONDA  ACCORD 2003', 'Condition': '1HGCM66583A082406', 'VIN': 'Used', 'Transmission': 'AUTOMATIC', 'Mileage': '0.00KM', 'Fuel Type': 'PETROL'}
    {'URL': 'previous_vehicle_details.php?refNo=969&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/06/2024/969', 'Price': '₦550,000.00', 'Car Title': 'NISSAN  PATHFINDER  1999', 'Condition': 'JN8AR07Y5XW379031', 'VIN': 'Used', 'Transmission': 'AUTOMATIC', 'Mileage': '0.00KM', 'Fuel Type': 'PETROL'}
    {'URL': 'previous_vehicle_details.php?refNo=970&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/06/2024/970', 'Price': '₦1,650,000.00', 'Car Title': 'NISSAN  FRONTIER 2004', 'Condition': 'W6ED27T046430134', 'VIN': 'Used', 'Transmission': 'AUTOMATIC', 'Mileage': '0.00KM', 'Fuel Type': 'PETROL'}
    {'URL': 'previous_vehicle_details.php?refNo=971&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/06/2024/971', 'Price': '₦5,000,000.00', 'Car Title': 'MERCEDES BENZ  C300 2011', 'Condition': 'WDDGF8BB9BR186216', 'VIN': 'Used', 'Transmission': 'AUTOMATIC', 'Mileage': '0.00KM', 'Fuel Type': 'PETROL'}
    {'URL': 'previous_vehicle_details.php?refNo=972&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/06/2024/972', 'Price': '₦8,500,000.00', 'Car Title': 'TOYOTA  COROLLA 2014', 'Condition': '2T1BURHE3EC156175', 'VIN': 'Used', 'Transmission': 'AUTOMATIC', 'Mileage': '0.00KM', 'Fuel Type': 'PETROL'}
    {'URL': 'previous_vehicle_details.php?refNo=973&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/06/2024/973', 'Price': '₦2,600,000.00', 'Car Title': 'TOYOTA  CAMRY 2003', 'Condition': '4T1BE32K53U730389', 'VIN': 'Used', 'Transmission': 'AUTOMATIC', 'Mileage': '0.00KM', 'Fuel Type': 'PETROL'}
    {'URL': 'previous_vehicle_details.php?refNo=974&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/06/2024/974', 'Price': '₦1,070,222.00', 'Car Title': 'OPEL  ASTRA 2000', 'Condition': 'WOLOTGF48Y6051547', 'VIN': 'Used', 'Transmission': 'AUTOMATIC', 'Mileage': '0.00KM', 'Fuel Type': 'PETROL'}
    {'URL': 'previous_vehicle_details.php?refNo=975&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/06/2024/975', 'Price': '₦1,123,333.00', 'Car Title': 'BMW  X5 2003', 'Condition': '5UXFA53563LV86085', 'VIN': 'Used', 'Transmission': 'AUTOMATIC', 'Mileage': '0.00KM', 'Fuel Type': 'PETROL'}
    {'URL': 'previous_vehicle_details.php?refNo=976&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/06/2024/976', 'Price': '₦2,010,010.00', 'Car Title': 'TOYOTA  MATRIX 2004', 'Condition': '2T1KR38E34C217490', 'VIN': 'Used', 'Transmission': 'AUTOMATIC', 'Mileage': '0.00KM', 'Fuel Type': 'PETROL'}
    {'URL': 'previous_vehicle_details.php?refNo=977&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/06/2024/977', 'Price': '₦650,000.00', 'Car Title': 'CHRYSLER  TOWN&COUNTRY  2006', 'Condition': '2A4GP54L26R688457', 'VIN': 'Used', 'Transmission': 'AUTOMATIC', 'Mileage': '0.00KM', 'Fuel Type': 'PETROL'}
    {'URL': 'previous_vehicle_details.php?refNo=978&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/06/2024/978', 'Price': '₦4,500,000.00', 'Car Title': 'BMW  328i 2016', 'Condition': 'WBA8E9G54GNT44161', 'VIN': 'Used', 'Transmission': 'AUTOMATIC', 'Mileage': '0.00KM', 'Fuel Type': 'PETROL'}
    {'URL': 'previous_vehicle_details.php?refNo=979&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/06/2024/979', 'Price': '₦900,000.00', 'Car Title': 'VOLVO  S60 T5 2001', 'Condition': 'YV1RX53D312001611', 'VIN': 'Used', 'Transmission': 'AUTOMATIC', 'Mileage': '0.00KM', 'Fuel Type': 'PETROL'}
    {'URL': 'previous_vehicle_details.php?refNo=980&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/06/2024/980', 'Price': '₦951,000.00', 'Car Title': 'MAZDA  626 2000', 'Condition': 'JMZGF12P201122355', 'VIN': 'Used', 'Transmission': 'AUTOMATIC', 'Mileage': '0.00KM', 'Fuel Type': 'PETROL'}
    {'URL': 'previous_vehicle_details.php?refNo=981&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/06/2024/981', 'Price': '₦3,500,000.00', 'Car Title': 'HYUNDAI  SONATA 2008', 'Condition': '5NPET46C48H342782', 'VIN': 'Used', 'Transmission': 'AUTOMATIC', 'Mileage': '0.00KM', 'Fuel Type': 'PETROL'}
    {'URL': 'previous_vehicle_details.php?refNo=982&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/06/2024/982', 'Price': '₦1,920,000.00', 'Car Title': 'TOYOTA  CAMRY 2003', 'Condition': '4T1BF30K83U056996', 'VIN': 'Used', 'Transmission': 'AUTOMATIC', 'Mileage': '0.00KM', 'Fuel Type': 'PETROL'}
    {'URL': 'previous_vehicle_details.php?refNo=983&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/06/2024/983', 'Price': '₦650,000.00', 'Car Title': 'JEEP 2.7L LIBERTY 2003', 'Condition': '1J4GL48K53W610023', 'VIN': 'Used', 'Transmission': 'AUTOMATIC', 'Mileage': '0.00KM', 'Fuel Type': 'PETROL'}
    {'URL': 'previous_vehicle_details.php?refNo=984&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/06/2024/984', 'Price': '₦1,050,000.00', 'Car Title': 'MERCEDES BENZ  ML 320 2002', 'Condition': '4JGAB54272A325633', 'VIN': 'Used', 'Transmission': 'AUTOMATIC', 'Mileage': '0.00KM', 'Fuel Type': 'PETROL'}
    {'URL': 'previous_vehicle_details.php?refNo=985&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/06/2024/985', 'Price': '₦1,299,999.00', 'Car Title': 'TOYOTA  CAMRY 2000', 'Condition': 'JT2BG22K6Y0424575', 'VIN': 'Used', 'Transmission': 'AUTOMATIC', 'Mileage': '0.00KM', 'Fuel Type': 'PETROL'}
    {'URL': 'previous_vehicle_details.php?refNo=986&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/06/2024/986', 'Price': '₦730,000.00', 'Car Title': 'VOLKSWAGEN  VENTO 1994', 'Condition': 'WVWZZZ1HZRW219590', 'VIN': 'Used', 'Transmission': 'AUTOMATIC', 'Mileage': '0.00KM', 'Fuel Type': 'PETROL'}
    {'URL': 'previous_vehicle_details.php?refNo=987&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/06/2024/987', 'Price': '₦620,000.00', 'Car Title': 'TOYOTA  CAMRY 1997', 'Condition': '4T1BF22KXVU907478', 'VIN': 'Used', 'Transmission': 'AUTOMATIC', 'Mileage': '0.00KM', 'Fuel Type': 'PETROL'}
    {'URL': 'previous_vehicle_details.php?refNo=988&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/06/2024/988', 'Price': '₦3,450,000.00', 'Car Title': 'LEXUS  ES 330 2006', 'Condition': 'JTHBA30G165155171', 'VIN': 'Used', 'Transmission': 'AUTOMATIC', 'Mileage': '0.00KM', 'Fuel Type': 'PETROL'}
    {'URL': 'previous_vehicle_details.php?refNo=989&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/06/2024/989', 'Price': '₦900,000.00', 'Car Title': 'JEEP  LIBERTY 2004', 'Condition': '1J8GL38K94W199686', 'VIN': 'Used', 'Transmission': 'AUTOMATIC', 'Mileage': '0.00KM', 'Fuel Type': 'PETROL'}
    {'URL': 'previous_vehicle_details.php?refNo=990&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/06/2024/990', 'Price': '₦4,900,000.00', 'Car Title': 'TOYOTA  COROLLA 0', 'Condition': '218859', 'VIN': 'Used', 'Transmission': 'AUTOMATIC', 'Mileage': '0.00KM', 'Fuel Type': 'PETROL'}
    {'URL': 'previous_vehicle_details.php?refNo=991&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/06/2024/991', 'Price': '₦1,700,000.00', 'Car Title': 'HONDA  PILOT 2006', 'Condition': '2HKYF18536H560405', 'VIN': 'Used', 'Transmission': 'AUTOMATIC', 'Mileage': '0.00KM', 'Fuel Type': 'PETROL'}
    {'URL': 'previous_vehicle_details.php?refNo=992&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/06/2024/992', 'Price': '₦1,000,000.00', 'Car Title': 'TOYOTA COROLLA 2000', 'Condition': '1NXBR12EXYZ340494', 'VIN': 'Used', 'Transmission': 'AUTOMATIC', 'Mileage': '0.00KM', 'Fuel Type': 'PETROL'}
    {'URL': 'previous_vehicle_details.php?refNo=993&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/06/2024/993', 'Price': '₦877,000.00', 'Car Title': 'DODGE  CHARGE SE 2008', 'Condition': '2B3KA43R68H112916', 'VIN': 'Used', 'Transmission': 'AUTOMATIC', 'Mileage': '0.00KM', 'Fuel Type': 'PETROL'}
    {'URL': 'previous_vehicle_details.php?refNo=994&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/06/2024/994', 'Price': '₦510,000.00', 'Car Title': 'MERCEDES BENZ  ML 1998', 'Condition': '4JGAB54EXWA010468', 'VIN': 'Used', 'Transmission': 'AUTOMATIC', 'Mileage': '0.00KM', 'Fuel Type': 'PETROL'}
    {'URL': 'previous_vehicle_details.php?refNo=995&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/06/2024/995', 'Price': '₦3,780,000.00', 'Car Title': 'TOYOTA  CAMRY 2003', 'Condition': '4T1BE32K23U157936', 'VIN': 'Used', 'Transmission': 'AUTOMATIC', 'Mileage': '0.00KM', 'Fuel Type': 'PETROL'}
    {'URL': 'previous_vehicle_details.php?refNo=996&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/06/2024/996', 'Price': '₦3,900,000.00', 'Car Title': 'BMW  SERIES 328i 2010', 'Condition': '2010', 'VIN': 'Used', 'Transmission': 'AUTOMATIC', 'Mileage': '0.00KM', 'Fuel Type': 'PETROL'}
    {'URL': 'previous_vehicle_details.php?refNo=997&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/06/2024/997', 'Price': '₦600,000.00', 'Car Title': 'MERCEDES BENZ  S320 1997', 'Condition': 'WDBGA33G9VA334338', 'VIN': 'Used', 'Transmission': 'AUTOMATIC', 'Mileage': '0.00KM', 'Fuel Type': 'PETROL'}
    {'URL': 'previous_vehicle_details.php?refNo=998&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/06/2024/998', 'Price': '₦1,500,000.00', 'Car Title': 'FORD  EDGE SEL 2012', 'Condition': '2FMDK4JC3CBA75933', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=999&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/06/2024/999', 'Price': '₦1,420,000.00', 'Car Title': 'FORD  RANGER 2001', 'Condition': '1FTYR14E41TA23141', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1000&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/06/2024/1000', 'Price': '₦739,777.00', 'Car Title': 'HONDA  ACCORD 2006', 'Condition': 'A062687', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1001&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/06/2024/1001', 'Price': '₦1,100,000.00', 'Car Title': 'TOYOTA  PRIUS 2007', 'Condition': 'JTDKB20U940006225', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1002&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/06/2024/1002', 'Price': '₦1,254,100.00', 'Car Title': 'MAZDA  3 2009', 'Condition': 'JM1BK344191212754', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1003&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/06/2024/1003', 'Price': '₦890,000.00', 'Car Title': 'CHEVROLET  EXPRESS VAN 2000', 'Condition': '1GCHG39R3Y1206484', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1004&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/06/2024/1004', 'Price': '₦1,300,999.00', 'Car Title': 'LEXUS  GS430 2003', 'Condition': '2687', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1005&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/06/2024/1005', 'Price': '₦1,100,000.00', 'Car Title': 'PONTIAC  VIBE 2003', 'Condition': '5Y2SL65886Z438979', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1006&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/06/2024/1006', 'Price': '₦810,000.00', 'Car Title': 'VOLSKWAGON  JETTA 2008', 'Condition': '3VWJM71K68M037058', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1007&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/06/2024/1007', 'Price': '₦606,999.00', 'Car Title': 'TOYOTA  HIGHLANDER 1998', 'Condition': '5T0YKR5H3G5159052', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1008&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/06/2024/1008', 'Price': '₦698,000.00', 'Car Title': 'TOYOTA  COROLLA 2003', 'Condition': '2T1BR32E43C029892', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1009&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/06/2024/1009', 'Price': '₦1,805,000.00', 'Car Title': 'TOYOTA  CAMRY 2011', 'Condition': '685312', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1010&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/06/2024/1010', 'Price': '₦1,680,000.00', 'Car Title': 'TOYOTA MATRIX 2009', 'Condition': '2T1KE40E29C002106', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1011&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/06/2024/1011', 'Price': '₦851,000.00', 'Car Title': 'VOLSKWAGON  GOLF 0', 'Condition': '565520', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1012&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/06/2024/1012', 'Price': '₦2,000,000.00', 'Car Title': 'FORD  F-150 PICK-UP 2010', 'Condition': '1FTEX1E85AFB86512', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1013&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/06/2024/1013', 'Price': '₦950,000.00', 'Car Title': 'NISSAN   XTERRA 2004', 'Condition': '661192', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1014&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/06/2024/1014', 'Price': '₦720,000.00', 'Car Title': 'DODGE  CARAVAN 1996', 'Condition': '2B4FP25B0TR753837', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1015&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/06/2024/1015', 'Price': '₦720,000.00', 'Car Title': 'NISSAN  PATHFINDER 0', 'Condition': '269742', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1016&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/06/2024/1016', 'Price': '₦512,000.00', 'Car Title': 'INFINITI INFINITY 2003', 'Condition': 'JNKAY41E43M004773', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1017&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/06/2024/1017', 'Price': '₦850,000.00', 'Car Title': 'VOLSKWAGON PASSAT WAGON 1995', 'Condition': 'WVWZZZ3AZSE019843', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1018&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/06/2024/1018', 'Price': '₦741,234.00', 'Car Title': 'HONDA  ACCORD 2003', 'Condition': '58473', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1019&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/06/2024/1019', 'Price': '₦650,000.00', 'Car Title': 'HONDA  CRV 2001', 'Condition': '29212', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1020&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/06/2024/1020', 'Price': '₦1,200,000.00', 'Car Title': 'CHEVROLET  MALIBU 0', 'Condition': '159284', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1021&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/06/2024/1021', 'Price': '₦640,876.00', 'Car Title': 'CHEVROLET  TAHOE 0', 'Condition': '300591', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1022&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/06/2024/1022', 'Price': '₦2,700,000.00', 'Car Title': 'FORD  EXPLORER XLT 0', 'Condition': 'A48638', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1023&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/06/2024/1023', 'Price': '₦4,079,000.00', 'Car Title': 'TOYOTA  COROLLA 2012', 'Condition': '209782', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1024&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/06/2024/1024', 'Price': '₦1,000,084.00', 'Car Title': 'FORD  F150 2005', 'Condition': 'B38189', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1025&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/06/2024/1025', 'Price': '₦2,127,000.00', 'Car Title': 'TOYOTA  SIENNA LE 2012', 'Condition': '5TDKK3DC3CS274691', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1026&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/06/2024/1026', 'Price': '₦1,100,000.00', 'Car Title': 'VOLVO  XC-90 2008', 'Condition': 'YV4CZ982181480775', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1027&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/06/2024/1027', 'Price': '₦580,000.00', 'Car Title': 'INTINITI  FX-35 0', 'Condition': '101862', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1028&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/06/2024/1028', 'Price': '₦1,250,000.00', 'Car Title': 'TOYOTA  HIGHLANDER 2011', 'Condition': '5TDBK3EH4BS069177', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1029&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/06/2024/1029', 'Price': '₦1,111,111.00', 'Car Title': 'KIA  RIO 2009', 'Condition': 'KNADE223X96445827', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1030&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/06/2024/1030', 'Price': '₦1,400,000.00', 'Car Title': 'FIAT  DUCATO VAN 0', 'Condition': '721023', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1031&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/06/2024/1031', 'Price': '₦1,200,000.00', 'Car Title': 'MERCEDEZ BENZ  E320 0', 'Condition': '681232', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1032&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/06/2024/1032', 'Price': '₦620,000.00', 'Car Title': 'TOYOTA  TUNDRA V8 1999', 'Condition': '5TBRT3417YS023599', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1033&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/06/2024/1033', 'Price': '₦671,000.00', 'Car Title': 'TOYOTA  CAMRY 1999', 'Condition': '962284', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1034&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/06/2024/1034', 'Price': '₦1,301,000.00', 'Car Title': 'LEXUS  RX300 2001', 'Condition': 'JTJGF10U810115367', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1035&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/06/2024/1035', 'Price': '₦760,000.00', 'Car Title': 'NISSAN  PATHFINDER 0', 'Condition': '713983', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1036&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/06/2024/1036', 'Price': '₦1,330,000.00', 'Car Title': 'TOYOTA  SIENNA 2000', 'Condition': '4T3ZF13C9YU233027', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1037&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/06/2024/1037', 'Price': '₦850,000.00', 'Car Title': 'TOYOTA  CAMRY 2001', 'Condition': '4T1BG28K61U819803', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1038&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/06/2024/1038', 'Price': '₦1,800,000.00', 'Car Title': 'HONDA  ACCORD 2006', 'Condition': 'C003792', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1039&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/06/2024/1039', 'Price': '₦4,073,000.00', 'Car Title': 'TOYOTA  CAMRY 2011', 'Condition': '175937', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1040&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/06/2024/1040', 'Price': '₦1,900,500.00', 'Car Title': 'FIAT  DUCATO VAN 0', 'Condition': '964945', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1041&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/06/2024/1041', 'Price': '₦1,350,999.00', 'Car Title': 'TOYOTA  CAMRY 2002', 'Condition': '4T1BE32K02U557928', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=442&itemType=Vehicle', 'Reference Number': 'NCS/01TC/OVT/02/2024/442', 'Price': '₦820,000.00', 'Car Title': 'NISSAN ALTIMA 2009', 'Condition': '1N4AL21E79C169368', 'VIN': 'Used', 'Transmission': 'AUTOMATIC', 'Mileage': '0.00KM', 'Fuel Type': 'NIL'}
    {'URL': 'previous_vehicle_details.php?refNo=454&itemType=Vehicle', 'Reference Number': 'NCS/01TC/OVT/02/2024/454', 'Price': '₦2,728,203.00', 'Car Title': 'FORD FUSION 2013', 'Condition': '3FA6P0G73DR298838', 'VIN': 'Used', 'Transmission': 'AUTOMATIC', 'Mileage': '0.00KM', 'Fuel Type': 'NIL'}
    {'URL': 'previous_vehicle_details.php?refNo=522&itemType=Vehicle', 'Reference Number': 'NCS/01TC/OVT/02/2024/522', 'Price': '₦480,000.00', 'Car Title': 'FORD  MONDEO 2010', 'Condition': 'UF0AXX6BBAWA24713', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=856&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/04/2024/856', 'Price': '₦620,700.00', 'Car Title': 'MAZDA 6 2005', 'Condition': '1YVHP80D565M51284', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1042&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/07/2024/1042', 'Price': '₦1,000,990.00', 'Car Title': 'HYUNDAI H100 0', 'Condition': '391624', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1043&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/07/2024/1043', 'Price': '₦655,999.00', 'Car Title': 'TOYOTA CAMRY 1999', 'Condition': 'U053718', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1044&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/07/2024/1044', 'Price': '₦1,400,000.00', 'Car Title': 'TOYOTA HIGHLANDER 0', 'Condition': '005477', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1045&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/07/2024/1045', 'Price': '₦500,000.00', 'Car Title': 'DODGE GRAND CARAVAN 0', 'Condition': '583633', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1046&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/07/2024/1046', 'Price': '₦1,244,711.00', 'Car Title': 'TOYOTA CAMRY 2009', 'Condition': '390938', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1048&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/07/2024/1048', 'Price': '₦801,999.00', 'Car Title': 'MAZDA MAZDA 6 0', 'Condition': 'M36366', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1049&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/07/2024/1049', 'Price': '₦550,000.00', 'Car Title': 'HONDA ACCORD 2003', 'Condition': '080974', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1050&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/07/2024/1050', 'Price': '₦2,018,504.00', 'Car Title': 'VOLKSWAGEN PASSAT 2015', 'Condition': '56605', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1051&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/07/2024/1051', 'Price': '₦1,300,000.00', 'Car Title': 'PONTIAC VIBE 2005', 'Condition': '424204', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1052&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/07/2024/1052', 'Price': '₦600,400.00', 'Car Title': 'FORD EXPLORER 0', 'Condition': 'B47810', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1053&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/07/2024/1053', 'Price': '₦1,100,000.00', 'Car Title': 'HYUNDAI TUCSON 2005', 'Condition': 'U191345', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1054&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/07/2024/1054', 'Price': '₦600,000.00', 'Car Title': 'FORD EXPLORER 2006', 'Condition': 'A03952', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1055&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/07/2024/1055', 'Price': '₦800,000.00', 'Car Title': 'VOLKSWAGEN JETTA 2007', 'Condition': 'M161272', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1056&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/07/2024/1056', 'Price': '₦2,000,000.00', 'Car Title': 'TOYOTA SIENNA 2002', 'Condition': 'U434195', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1057&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/07/2024/1057', 'Price': '₦600,010.00', 'Car Title': 'ACURA MDX 2003', 'Condition': 'H521190', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1058&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/07/2024/1058', 'Price': '₦1,368,000.00', 'Car Title': 'MAZDA CX-9 2008', 'Condition': '129280', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1065&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/07/2024/1065', 'Price': '₦1,600,000.00', 'Car Title': 'TOYOTA CAMRY 2008', 'Condition': '31752', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1081&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/07/2024/1081', 'Price': '₦620,000.00', 'Car Title': 'NISSAN XTERRA 0', 'Condition': '508099', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1059&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/07/2024/1059', 'Price': '₦650,002.00', 'Car Title': 'NISSAN PRIMERA 0', 'Condition': '521271', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1069&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/07/2024/1069', 'Price': '₦700,000.00', 'Car Title': 'HONDA  ODYSSEY VAN 2002', 'Condition': '508246', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1070&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/07/2024/1070', 'Price': '₦1,050,000.00', 'Car Title': 'LEXUS IS250 2009', 'Condition': '84860', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1071&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/07/2024/1071', 'Price': '₦803,000.00', 'Car Title': 'MAZDA MAZDA 3 2003', 'Condition': '114384', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1072&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/07/2024/1072', 'Price': '₦800,000.00', 'Car Title': 'MAZDA MPV 2001', 'Condition': '109234', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1073&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/07/2024/1073', 'Price': '₦1,900,000.00', 'Car Title': 'TOYOTA CAMRY 2009', 'Condition': '264598', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1075&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/07/2024/1075', 'Price': '₦1,000,990.00', 'Car Title': 'TOYOTA CAMRY 2000', 'Condition': '101093', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1066&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/07/2024/1066', 'Price': '₦975,000.00', 'Car Title': 'PEUGEOT 307 2000', 'Condition': '441022', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1067&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/07/2024/1067', 'Price': '₦1,510,123.00', 'Car Title': 'SCION XD 2009', 'Condition': '34744', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1068&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/07/2024/1068', 'Price': '₦679,254.00', 'Car Title': 'HONDA ACCORD 2007', 'Condition': '071177', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1074&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/07/2024/1074', 'Price': '₦1,150,000.00', 'Car Title': 'HYUNDAI SONATA 0', 'Condition': '667199', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1076&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/07/2024/1076', 'Price': '₦700,000.00', 'Car Title': 'DODGE DAKOTA 2005', 'Condition': '139422', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1077&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/07/2024/1077', 'Price': '₦1,300,000.00', 'Car Title': 'TOYOTA SIENNA 0', 'Condition': '237149', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1078&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/07/2024/1078', 'Price': '₦1,718,000.00', 'Car Title': 'TOYOTA COROLLA 2008', 'Condition': '913711', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1079&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/07/2024/1079', 'Price': '₦760,000.00', 'Car Title': 'VOLVO S60 2005', 'Condition': '430815', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1080&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/07/2024/1080', 'Price': '₦1,100,000.00', 'Car Title': 'HONDA ODYSSEY 2006', 'Condition': '133419', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1082&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/07/2024/1082', 'Price': '₦800,000.00', 'Car Title': 'TOYOTA SIENNA 0', 'Condition': '219940', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1083&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/07/2024/1083', 'Price': '₦520,000.00', 'Car Title': 'MITSUBISHI GALLANT 0', 'Condition': '119335', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1086&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/07/2024/1086', 'Price': '₦470,000.00', 'Car Title': 'SUZUKI SUZUKI 2004', 'Condition': '116371', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1084&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/07/2024/1084', 'Price': '₦430,000.00', 'Car Title': 'ROVER ROVER 75 0', 'Condition': '150676', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1085&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/07/2024/1085', 'Price': '₦902,000.00', 'Car Title': 'HYUNDAI SONATA 0', 'Condition': '020964', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1087&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/07/2024/1087', 'Price': '₦702,500.00', 'Car Title': 'CHEVROLET EQUINOX 2005', 'Condition': '186907', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=429&itemType=Vehicle', 'Reference Number': 'NCS/01TC/OVT/02/2024/429', 'Price': '₦900,000.00', 'Car Title': 'LEXUS  ES350 2003', 'Condition': 'JTHBF30GX30098236', 'VIN': 'Used', 'Transmission': 'AUTOMATIC', 'Mileage': '0.00KM', 'Fuel Type': 'NIL'}
    {'URL': 'previous_vehicle_details.php?refNo=1088&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/07/2024/1088', 'Price': '₦1,550,000.00', 'Car Title': 'TOYOTA COROLLA 2010', 'Condition': '361229', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1089&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/07/2024/1089', 'Price': '₦700,000.00', 'Car Title': 'MAZDA PREMACY 2000', 'Condition': '122722', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1090&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/07/2024/1090', 'Price': '₦905,700.00', 'Car Title': 'NISSAN ROGUE 0', 'Condition': '664341', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1091&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/07/2024/1091', 'Price': '₦980,000.00', 'Car Title': 'TOYOTA CAMRY 2002', 'Condition': '050870', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1092&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/07/2024/1092', 'Price': '₦700,000.00', 'Car Title': 'CHEVROLET VAN 2004', 'Condition': '117360', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1047&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/07/2024/1047', 'Price': '₦950,000.00', 'Car Title': 'VOLKSWAGEN JETTA 0', 'Condition': '076890', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1093&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/07/2024/1093', 'Price': '₦2,200,000.00', 'Car Title': 'BMW  3 SERIES 2007', 'Condition': 'WBAVC93557KZ70222', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1094&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/07/2024/1094', 'Price': '₦1,266,098.00', 'Car Title': 'ACURA  MDX 2008', 'Condition': '2HNYD28218H506771', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1095&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/07/2024/1095', 'Price': '₦1,000,000.00', 'Car Title': 'FORD  GALAXY 1998', 'Condition': 'WF0GXXPSWGTG40874', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1096&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/07/2024/1096', 'Price': '₦748,800.00', 'Car Title': 'HONDA  CR-V 2006', 'Condition': 'JHLRD78516C010941', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1097&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/07/2024/1097', 'Price': '₦880,760.00', 'Car Title': 'DODGE  GRAND CARAVAN 2004', 'Condition': '582557', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1098&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/07/2024/1098', 'Price': '₦802,870.58', 'Car Title': 'FORD  VICTORIA 2010', 'Condition': '2FABP7AV8AX140782', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1099&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/07/2024/1099', 'Price': '₦1,798,650.00', 'Car Title': 'TOYOTA  CAMRY 2002', 'Condition': '4T1BF30K42U023282', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1100&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/07/2024/1100', 'Price': '₦1,225,479.15', 'Car Title': 'LEXUS  ES330 2004', 'Condition': 'JTHBA30G840017329', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1101&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/07/2024/1101', 'Price': '₦676,577.20', 'Car Title': 'NISSAN  MAXIMA 3.5 SE 2004', 'Condition': '1N4BA41E44C888334', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1102&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/07/2024/1102', 'Price': '₦2,218,999.00', 'Car Title': 'PONTIAC  VIBE 2005', 'Condition': '456303', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1103&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/07/2024/1103', 'Price': '₦620,000.00', 'Car Title': 'FORD  RANGER 1999', 'Condition': '1FTYR10C6XUA71280', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1104&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/07/2024/1104', 'Price': '₦1,250,000.00', 'Car Title': 'MERCEDES BENZ  C180 2001', 'Condition': 'WDB2020181A425204', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1105&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/07/2024/1105', 'Price': '₦1,417,501.05', 'Car Title': 'HONDA  ODYSSEY 2003', 'Condition': 'B076681', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1106&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/07/2024/1106', 'Price': '₦543,888.00', 'Car Title': 'MERCEDES BENZ  ML500 2002', 'Condition': '4JGAB75E22A363341', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1107&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/07/2024/1107', 'Price': '₦790,111.00', 'Car Title': 'HONDA  ELEMENT 2003', 'Condition': 'L004038', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1108&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/07/2024/1108', 'Price': '₦670,000.00', 'Car Title': 'NISSAN  PATHFINDER 2001', 'Condition': 'W561271', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1109&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/07/2024/1109', 'Price': '₦1,000,000.00', 'Car Title': 'ACURA  TL 2004', 'Condition': 'JH4CL95824C009812', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1111&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/07/2024/1111', 'Price': '₦794,851.05', 'Car Title': 'JEEP LIBERTY  2004', 'Condition': '1J8GW58N64C104810', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1112&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/07/2024/1112', 'Price': '₦861,000.00', 'Car Title': 'FORD  FOCUS 2008', 'Condition': '1FAHP35N28W287411', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1113&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/07/2024/1113', 'Price': '₦650,000.00', 'Car Title': 'MERCEDES BENZ  ML 350 2004', 'Condition': '4JGAB57E34A484044', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1114&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/07/2024/1114', 'Price': '₦600,222.00', 'Car Title': 'CHEVROLET  S-10 PICK UP  2001', 'Condition': '1GCDT19W418122773', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1115&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/07/2024/1115', 'Price': '₦818,000.00', 'Car Title': 'VOLKSWAGEN  VAN 1994', 'Condition': 'WV2ZZZ70ZRH023252', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1116&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/07/2024/1116', 'Price': '₦1,000,000.00', 'Car Title': 'TOYOTA  PREVIA 1991', 'Condition': '005385', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1117&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/07/2024/1117', 'Price': '₦604,000.00', 'Car Title': 'MERCEDES BENZ  ML320 1999', 'Condition': '192594', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1118&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/07/2024/1118', 'Price': '₦710,000.00', 'Car Title': 'JEEP  4X4 2003', 'Condition': '587144', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1119&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/07/2024/1119', 'Price': '₦800,000.00', 'Car Title': 'TOYOTA  SIENNA 2000', 'Condition': '198371', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1120&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/07/2024/1120', 'Price': '₦1,187,200.00', 'Car Title': 'TOYOTA  CAMRY 2002', 'Condition': '4T1BF1FK5FU621445', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1121&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/07/2024/1121', 'Price': '₦650,000.00', 'Car Title': 'ACURA  MDX 2004', 'Condition': '523777', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1122&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/07/2024/1122', 'Price': '₦1,092,102.96', 'Car Title': 'HONDA  PILOT 2007', 'Condition': '5FNYF18537B022853', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1123&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/07/2024/1123', 'Price': '₦559,883.10', 'Car Title': 'FORD  PICKUP 2004', 'Condition': '1FTPW14514FA29597', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1124&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/07/2024/1124', 'Price': '₦670,000.00', 'Car Title': 'FORD  MUSTANG 1972', 'Condition': '2F01F108675', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1125&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/07/2024/1125', 'Price': '₦1,000,000.00', 'Car Title': 'TOYOTA  HIGHLANDER 2004', 'Condition': 'JTEG021A640090505', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1126&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/07/2024/1126', 'Price': '₦1,060,000.00', 'Car Title': 'TOYOTA  RAV 4 2004', 'Condition': 'JTEHD20V540009857', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1127&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/07/2024/1127', 'Price': '₦1,125,672.00', 'Car Title': 'OPEL  ZAFIRA 2001', 'Condition': 'W0L0TGF7522078069', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1128&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/07/2024/1128', 'Price': '₦1,146,504.33', 'Car Title': 'VOLKSWAGEN  PASSAT 2006', 'Condition': 'WVWAK73C16P137817', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1129&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/07/2024/1129', 'Price': '₦1,325,000.00', 'Car Title': 'JEEP  COMMANDER 2007', 'Condition': '1J8HG48K97C690263', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1130&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/07/2024/1130', 'Price': '₦630,000.00', 'Car Title': 'MAZDA  323 2002', 'Condition': 'JMZBA145201303140', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1131&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/07/2024/1131', 'Price': '₦1,680,000.00', 'Car Title': 'TOYOTA  HIGHLANDER 2005', 'Condition': 'JTEDP21A250086348', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1132&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/07/2024/1132', 'Price': '₦650,000.00', 'Car Title': 'VolkSWAGEN  GOLF 1995', 'Condition': 'WVWZZ1HZSW254762', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1133&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/07/2024/1133', 'Price': '₦1,000,000.00', 'Car Title': 'MERCEDES-BENZ  C240 2001', 'Condition': 'WDB2032611F379590', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1134&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/07/2024/1134', 'Price': '₦975,450.00', 'Car Title': 'TOYOTA  CAMRY 1995', 'Condition': 'S0298401', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1135&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/07/2024/1135', 'Price': '₦1,284,000.00', 'Car Title': 'DODGE  GRAND CARAVAN 2012', 'Condition': '2C4RDGBG1CR121497', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1136&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/07/2024/1136', 'Price': '₦680,000.00', 'Car Title': 'TOYOTA  RAV 4 1998', 'Condition': 'JT3HP10V8W7089952', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1110&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/07/2024/1110', 'Price': '₦800,000.00', 'Car Title': 'FORD  MONDEO 0', 'Condition': 'T29202', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1137&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/08/2024/1137', 'Price': '₦515,480.00', 'Car Title': 'NISSAN  ALTIMA 2008', 'Condition': 'C163344', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1139&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/08/2024/1139', 'Price': '₦470,900.00', 'Car Title': 'HONDA  ODYSSEY 2002', 'Condition': 'H007189', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1140&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/08/2024/1140', 'Price': '₦630,000.00', 'Car Title': 'TOYOTA  SIENNA 2000', 'Condition': '294937', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1141&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/08/2024/1141', 'Price': '₦850,000.00', 'Car Title': 'HYUNDAI  VERACRUZ 2010', 'Condition': '128825', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1142&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/08/2024/1142', 'Price': '₦540,000.00', 'Car Title': 'ISUZU  RODEO 2001', 'Condition': '4339865', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1143&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/08/2024/1143', 'Price': '₦1,297,274.00', 'Car Title': 'MERCEDES-BENZ  C300 2008', 'Condition': 'WDDGF81X38F135267', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1144&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/08/2024/1144', 'Price': '₦500,000.00', 'Car Title': 'SUBARU  FORESTER 2004', 'Condition': '701858', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1145&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/08/2024/1145', 'Price': '₦904,000.00', 'Car Title': 'volkswagen JETTA 2007', 'Condition': 'M135037', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1146&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/08/2024/1146', 'Price': '₦680,000.00', 'Car Title': 'TOYOTA  TACOMA 2004', 'Condition': '331164', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1147&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/08/2024/1147', 'Price': '₦521,111.00', 'Car Title': 'CHEVROLET  TOWN&COUNTRY 2008', 'Condition': '774913', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1148&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/08/2024/1148', 'Price': '₦613,335.00', 'Car Title': 'ACURA  MDX 2002', 'Condition': 'H532435', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1149&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/08/2024/1149', 'Price': '₦580,000.00', 'Car Title': 'HONDA  ODYSSEY 2002', 'Condition': '516323', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1150&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/08/2024/1150', 'Price': '₦750,000.00', 'Car Title': 'FORD  EXPLORER 2006', 'Condition': 'A08625', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1151&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/08/2024/1151', 'Price': '₦1,199,064.00', 'Car Title': 'TOYOTA  MATRIX 2008', 'Condition': '697338', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1152&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/08/2024/1152', 'Price': '₦1,053,481.00', 'Car Title': 'TOYOTA  SIENNA 2006', 'Condition': '022773', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1153&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/08/2024/1153', 'Price': '₦500,000.00', 'Car Title': 'VOLVO  S40 2003', 'Condition': '2158033', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1154&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/08/2024/1154', 'Price': '₦530,000.00', 'Car Title': 'ACURA  TSX 2004', 'Condition': '014438', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1155&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/08/2024/1155', 'Price': '₦750,009.00', 'Car Title': 'SCION  TC 2008', 'Condition': '0255999', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1156&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/08/2024/1156', 'Price': '₦603,000.00', 'Car Title': 'FORD  EDGE 2007', 'Condition': 'BA51170', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1157&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/08/2024/1157', 'Price': '₦500,999.00', 'Car Title': 'TOYOTA  SIENNA 1999', 'Condition': '103695', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1159&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/08/2024/1159', 'Price': '₦711,111.00', 'Car Title': 'TOYOTA  CAMRY 2003', 'Condition': '057276', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1160&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/08/2024/1160', 'Price': '₦550,000.00', 'Car Title': 'OPEL  FRONTERA 1999', 'Condition': '614245', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1161&itemType=Vehicle', 'Reference Number': 'NCS/PTML/OVT/08/2024/1161', 'Price': '₦1,200,000.00', 'Car Title': 'TOYOTA  COROLLA 2005', 'Condition': '536465', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1162&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/08/2024/1162', 'Price': '₦598,500.00', 'Car Title': 'LEXUS RX 300 2001', 'Condition': '0091551', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1163&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/08/2024/1163', 'Price': '₦650,888.00', 'Car Title': 'NISSAN  ALTIMA 2010', 'Condition': '437704', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1164&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/08/2024/1164', 'Price': '₦752,000.00', 'Car Title': 'TOYOTA  CAMRY 2001', 'Condition': '829091', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1165&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/08/2024/1165', 'Price': '₦678,999.00', 'Car Title': 'MERCEDES BENZ  ML 350 2004', 'Condition': '503680', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1166&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/08/2024/1166', 'Price': '₦755,000.00', 'Car Title': 'MERCEDES BENZ  C230  2003', 'Condition': 'F401100', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1167&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/08/2024/1167', 'Price': '₦570,999.00', 'Car Title': 'TOYOTA  SIENNA 2000', 'Condition': '069289', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1168&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/08/2024/1168', 'Price': '₦770,000.00', 'Car Title': 'PEUGEOT  407 SW  2002', 'Condition': '532157', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1169&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/08/2024/1169', 'Price': '₦1,388,000.00', 'Car Title': 'TOYOTA  COROLLA 2005', 'Condition': '518628', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1171&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/08/2024/1171', 'Price': '₦510,000.00', 'Car Title': 'CHEVROLET  VENTURE 2004', 'Condition': '180433', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1172&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/08/2024/1172', 'Price': '₦567,000.00', 'Car Title': 'KIA  SPORTAGE 2007', 'Condition': '374479', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1173&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/08/2024/1173', 'Price': '₦520,009.00', 'Car Title': 'LEXUS  ES 300 1998', 'Condition': '014139', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1174&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/08/2024/1174', 'Price': '₦1,631,000.00', 'Car Title': 'KIA  SORENTO 2007', 'Condition': '690372', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1175&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/08/2024/1175', 'Price': '₦963,101.00', 'Car Title': 'SCION  XA 2004', 'Condition': '054841', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1176&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/08/2024/1176', 'Price': '₦570,000.00', 'Car Title': 'TOYOTA  CAMRY 1999', 'Condition': '609098', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1177&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/08/2024/1177', 'Price': '₦700,000.00', 'Car Title': 'CHEVROLET  HHR  2009', 'Condition': '607875', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1178&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/08/2024/1178', 'Price': '₦648,000.00', 'Car Title': 'FORD  FREESTAR 2004', 'Condition': 'B29970', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1179&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/08/2024/1179', 'Price': '₦1,200,000.00', 'Car Title': 'TOYOTA  HIGHLANDER 2012', 'Condition': '5TDYK3EH5CS070513', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1180&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/08/2024/1180', 'Price': '₦1,626,898.00', 'Car Title': 'HONDA  CROSSTOUR 2014', 'Condition': '000016', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1181&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/08/2024/1181', 'Price': '₦533,333.00', 'Car Title': 'HYUNDAI  SANTA FE 2004', 'Condition': 'U572121', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    {'URL': 'previous_vehicle_details.php?refNo=1182&itemType=Vehicle', 'Reference Number': 'NCS/TCIP/OVT/08/2024/1182', 'Price': '₦520,000.00', 'Car Title': 'TOYOTA CAMRY 1996', 'Condition': '824426', 'VIN': 'Used', 'Transmission': 'Automatic', 'Mileage': '0.00KM', 'Fuel Type': 'Petrol'}
    


```python
# finally scraped all the data i needed
import pandas as pd

bidding = pd.DataFrame(scrapped_data)
print(bidding)
```

                                                        URL  \
    0     previous_vehicle_details.php?refNo=1&itemType=...   
    1     previous_vehicle_details.php?refNo=2&itemType=...   
    2     previous_vehicle_details.php?refNo=3&itemType=...   
    3     previous_vehicle_details.php?refNo=4&itemType=...   
    4     previous_vehicle_details.php?refNo=5&itemType=...   
    ...                                                 ...   
    1200  previous_vehicle_details.php?refNo=1178&itemTy...   
    1201  previous_vehicle_details.php?refNo=1179&itemTy...   
    1202  previous_vehicle_details.php?refNo=1180&itemTy...   
    1203  previous_vehicle_details.php?refNo=1181&itemTy...   
    1204  previous_vehicle_details.php?refNo=1182&itemTy...   
    
                   Reference Number          Price  \
    0          NCS/PTML/OVT/01/24/1    ₦892,000.00   
    1          NCS/PTML/OVT/01/24/2    ₦500,000.00   
    2          NCS/PTML/OVT/01/24/3    ₦420,000.00   
    3          NCS/PTML/OVT/01/24/4    ₦800,000.00   
    4          NCS/PTML/OVT/01/24/5    ₦715,000.00   
    ...                         ...            ...   
    1200  NCS/TCIP/OVT/08/2024/1178    ₦648,000.00   
    1201  NCS/TCIP/OVT/08/2024/1179  ₦1,200,000.00   
    1202  NCS/TCIP/OVT/08/2024/1180  ₦1,626,898.00   
    1203  NCS/TCIP/OVT/08/2024/1181    ₦533,333.00   
    1204  NCS/TCIP/OVT/08/2024/1182    ₦520,000.00   
    
                                      Car Title          Condition   VIN  \
    0     TOYOTA CAMRY HYBRID LE 4DR SEDAN 2006  4T1BE32K86U111063  Used   
    1                             ACURA TL 2004  19UUA66214A013030  Used   
    2       HONDA ACCORD EX 1.5T 4DR SEDAN 2004  1HGCM66554A098192  Used   
    3           TOYOTA COROLLA L 4DR SEDAN 2007  2T1BR32E27C777272  Used   
    4                          PEUGEOT 307 2008  VF33CNFUL84568049  Used   
    ...                                     ...                ...   ...   
    1200                    FORD  FREESTAR 2004             B29970  Used   
    1201                TOYOTA  HIGHLANDER 2012  5TDYK3EH5CS070513  Used   
    1202                  HONDA  CROSSTOUR 2014             000016  Used   
    1203                 HYUNDAI  SANTA FE 2004            U572121  Used   
    1204                      TOYOTA CAMRY 1996             824426  Used   
    
         Transmission Mileage Fuel Type  
    0       Automatic  0.00KM    Petrol  
    1       Automatic  0.00KM    Petrol  
    2       Automatic  0.00KM    Petrol  
    3       Automatic  0.00KM    Petrol  
    4       Automatic  0.00KM    Petrol  
    ...           ...     ...       ...  
    1200    Automatic  0.00KM    Petrol  
    1201    Automatic  0.00KM    Petrol  
    1202    Automatic  0.00KM    Petrol  
    1203    Automatic  0.00KM    Petrol  
    1204    Automatic  0.00KM    Petrol  
    
    [1205 rows x 9 columns]
    


```python
from IPython.display import display

# Display the DataFrame as an HTML table in Jupyter
display(bidding)
```


<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>URL</th>
      <th>Reference Number</th>
      <th>Price</th>
      <th>Car Title</th>
      <th>Condition</th>
      <th>VIN</th>
      <th>Transmission</th>
      <th>Mileage</th>
      <th>Fuel Type</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>previous_vehicle_details.php?refNo=1&amp;itemType=...</td>
      <td>NCS/PTML/OVT/01/24/1</td>
      <td>₦892,000.00</td>
      <td>TOYOTA CAMRY HYBRID LE 4DR SEDAN 2006</td>
      <td>4T1BE32K86U111063</td>
      <td>Used</td>
      <td>Automatic</td>
      <td>0.00KM</td>
      <td>Petrol</td>
    </tr>
    <tr>
      <th>1</th>
      <td>previous_vehicle_details.php?refNo=2&amp;itemType=...</td>
      <td>NCS/PTML/OVT/01/24/2</td>
      <td>₦500,000.00</td>
      <td>ACURA TL 2004</td>
      <td>19UUA66214A013030</td>
      <td>Used</td>
      <td>Automatic</td>
      <td>0.00KM</td>
      <td>Petrol</td>
    </tr>
    <tr>
      <th>2</th>
      <td>previous_vehicle_details.php?refNo=3&amp;itemType=...</td>
      <td>NCS/PTML/OVT/01/24/3</td>
      <td>₦420,000.00</td>
      <td>HONDA ACCORD EX 1.5T 4DR SEDAN 2004</td>
      <td>1HGCM66554A098192</td>
      <td>Used</td>
      <td>Automatic</td>
      <td>0.00KM</td>
      <td>Petrol</td>
    </tr>
    <tr>
      <th>3</th>
      <td>previous_vehicle_details.php?refNo=4&amp;itemType=...</td>
      <td>NCS/PTML/OVT/01/24/4</td>
      <td>₦800,000.00</td>
      <td>TOYOTA COROLLA L 4DR SEDAN 2007</td>
      <td>2T1BR32E27C777272</td>
      <td>Used</td>
      <td>Automatic</td>
      <td>0.00KM</td>
      <td>Petrol</td>
    </tr>
    <tr>
      <th>4</th>
      <td>previous_vehicle_details.php?refNo=5&amp;itemType=...</td>
      <td>NCS/PTML/OVT/01/24/5</td>
      <td>₦715,000.00</td>
      <td>PEUGEOT 307 2008</td>
      <td>VF33CNFUL84568049</td>
      <td>Used</td>
      <td>Automatic</td>
      <td>0.00KM</td>
      <td>Petrol</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>1200</th>
      <td>previous_vehicle_details.php?refNo=1178&amp;itemTy...</td>
      <td>NCS/TCIP/OVT/08/2024/1178</td>
      <td>₦648,000.00</td>
      <td>FORD  FREESTAR 2004</td>
      <td>B29970</td>
      <td>Used</td>
      <td>Automatic</td>
      <td>0.00KM</td>
      <td>Petrol</td>
    </tr>
    <tr>
      <th>1201</th>
      <td>previous_vehicle_details.php?refNo=1179&amp;itemTy...</td>
      <td>NCS/TCIP/OVT/08/2024/1179</td>
      <td>₦1,200,000.00</td>
      <td>TOYOTA  HIGHLANDER 2012</td>
      <td>5TDYK3EH5CS070513</td>
      <td>Used</td>
      <td>Automatic</td>
      <td>0.00KM</td>
      <td>Petrol</td>
    </tr>
    <tr>
      <th>1202</th>
      <td>previous_vehicle_details.php?refNo=1180&amp;itemTy...</td>
      <td>NCS/TCIP/OVT/08/2024/1180</td>
      <td>₦1,626,898.00</td>
      <td>HONDA  CROSSTOUR 2014</td>
      <td>000016</td>
      <td>Used</td>
      <td>Automatic</td>
      <td>0.00KM</td>
      <td>Petrol</td>
    </tr>
    <tr>
      <th>1203</th>
      <td>previous_vehicle_details.php?refNo=1181&amp;itemTy...</td>
      <td>NCS/TCIP/OVT/08/2024/1181</td>
      <td>₦533,333.00</td>
      <td>HYUNDAI  SANTA FE 2004</td>
      <td>U572121</td>
      <td>Used</td>
      <td>Automatic</td>
      <td>0.00KM</td>
      <td>Petrol</td>
    </tr>
    <tr>
      <th>1204</th>
      <td>previous_vehicle_details.php?refNo=1182&amp;itemTy...</td>
      <td>NCS/TCIP/OVT/08/2024/1182</td>
      <td>₦520,000.00</td>
      <td>TOYOTA CAMRY 1996</td>
      <td>824426</td>
      <td>Used</td>
      <td>Automatic</td>
      <td>0.00KM</td>
      <td>Petrol</td>
    </tr>
  </tbody>
</table>
<p>1205 rows × 9 columns</p>
</div>



```python
# save your result as CSV file
bidding.to_csv('C:\\Users\HP\Desktop\Phyton for everybody with Dr Chuck\\Scrapped_Data\Scrapped_bidding_data.csv')
print('Table saved as "Scrapped_bidding_data"')
```

    Table saved as "Scrapped_bidding_data"
    


```python
# View my data in a dataframe
import pandas as pd
import numpy as np

auction_results = pd.read_csv('C:\\Users\\HP\\Desktop\\Phyton for everybody with Dr Chuck\\Scrapped_Data\\Unclean_Raw_Scrapped_bidding_data.csv')
auction_results

```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Unnamed: 0</th>
      <th>URL</th>
      <th>Reference Number</th>
      <th>Price</th>
      <th>Car Title</th>
      <th>Condition</th>
      <th>VIN</th>
      <th>Transmission</th>
      <th>Mileage</th>
      <th>Fuel Type</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0</td>
      <td>previous_vehicle_details.php?refNo=1&amp;itemType=...</td>
      <td>NCS/PTML/OVT/01/24/1</td>
      <td>₦892,000.00</td>
      <td>TOYOTA CAMRY HYBRID LE 4DR SEDAN 2006</td>
      <td>4T1BE32K86U111063</td>
      <td>Used</td>
      <td>Automatic</td>
      <td>0.00KM</td>
      <td>Petrol</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1</td>
      <td>previous_vehicle_details.php?refNo=2&amp;itemType=...</td>
      <td>NCS/PTML/OVT/01/24/2</td>
      <td>₦500,000.00</td>
      <td>ACURA TL 2004</td>
      <td>19UUA66214A013030</td>
      <td>Used</td>
      <td>Automatic</td>
      <td>0.00KM</td>
      <td>Petrol</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2</td>
      <td>previous_vehicle_details.php?refNo=3&amp;itemType=...</td>
      <td>NCS/PTML/OVT/01/24/3</td>
      <td>₦420,000.00</td>
      <td>HONDA ACCORD EX 1.5T 4DR SEDAN 2004</td>
      <td>1HGCM66554A098192</td>
      <td>Used</td>
      <td>Automatic</td>
      <td>0.00KM</td>
      <td>Petrol</td>
    </tr>
    <tr>
      <th>3</th>
      <td>3</td>
      <td>previous_vehicle_details.php?refNo=4&amp;itemType=...</td>
      <td>NCS/PTML/OVT/01/24/4</td>
      <td>₦800,000.00</td>
      <td>TOYOTA COROLLA L 4DR SEDAN 2007</td>
      <td>2T1BR32E27C777272</td>
      <td>Used</td>
      <td>Automatic</td>
      <td>0.00KM</td>
      <td>Petrol</td>
    </tr>
    <tr>
      <th>4</th>
      <td>4</td>
      <td>previous_vehicle_details.php?refNo=5&amp;itemType=...</td>
      <td>NCS/PTML/OVT/01/24/5</td>
      <td>₦715,000.00</td>
      <td>PEUGEOT 307 2008</td>
      <td>VF33CNFUL84568049</td>
      <td>Used</td>
      <td>Automatic</td>
      <td>0.00KM</td>
      <td>Petrol</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>1200</th>
      <td>1200</td>
      <td>previous_vehicle_details.php?refNo=1178&amp;itemTy...</td>
      <td>NCS/TCIP/OVT/08/2024/1178</td>
      <td>₦648,000.00</td>
      <td>FORD  FREESTAR 2004</td>
      <td>B29970</td>
      <td>Used</td>
      <td>Automatic</td>
      <td>0.00KM</td>
      <td>Petrol</td>
    </tr>
    <tr>
      <th>1201</th>
      <td>1201</td>
      <td>previous_vehicle_details.php?refNo=1179&amp;itemTy...</td>
      <td>NCS/TCIP/OVT/08/2024/1179</td>
      <td>₦1,200,000.00</td>
      <td>TOYOTA  HIGHLANDER 2012</td>
      <td>5TDYK3EH5CS070513</td>
      <td>Used</td>
      <td>Automatic</td>
      <td>0.00KM</td>
      <td>Petrol</td>
    </tr>
    <tr>
      <th>1202</th>
      <td>1202</td>
      <td>previous_vehicle_details.php?refNo=1180&amp;itemTy...</td>
      <td>NCS/TCIP/OVT/08/2024/1180</td>
      <td>₦1,626,898.00</td>
      <td>HONDA  CROSSTOUR 2014</td>
      <td>000016</td>
      <td>Used</td>
      <td>Automatic</td>
      <td>0.00KM</td>
      <td>Petrol</td>
    </tr>
    <tr>
      <th>1203</th>
      <td>1203</td>
      <td>previous_vehicle_details.php?refNo=1181&amp;itemTy...</td>
      <td>NCS/TCIP/OVT/08/2024/1181</td>
      <td>₦533,333.00</td>
      <td>HYUNDAI  SANTA FE 2004</td>
      <td>U572121</td>
      <td>Used</td>
      <td>Automatic</td>
      <td>0.00KM</td>
      <td>Petrol</td>
    </tr>
    <tr>
      <th>1204</th>
      <td>1204</td>
      <td>previous_vehicle_details.php?refNo=1182&amp;itemTy...</td>
      <td>NCS/TCIP/OVT/08/2024/1182</td>
      <td>₦520,000.00</td>
      <td>TOYOTA CAMRY 1996</td>
      <td>824426</td>
      <td>Used</td>
      <td>Automatic</td>
      <td>0.00KM</td>
      <td>Petrol</td>
    </tr>
  </tbody>
</table>
<p>1205 rows × 10 columns</p>
</div>



# DATA CLEANING WITH PANDAS AND NUMPY



```python
# I cleaned the first row called URL by extracting only bidding items which were either a vehicle or a container
auction_results['URL']
```




    0       previous_vehicle_details.php?refNo=1&itemType=...
    1       previous_vehicle_details.php?refNo=2&itemType=...
    2       previous_vehicle_details.php?refNo=3&itemType=...
    3       previous_vehicle_details.php?refNo=4&itemType=...
    4       previous_vehicle_details.php?refNo=5&itemType=...
                                  ...                        
    1200    previous_vehicle_details.php?refNo=1178&itemTy...
    1201    previous_vehicle_details.php?refNo=1179&itemTy...
    1202    previous_vehicle_details.php?refNo=1180&itemTy...
    1203    previous_vehicle_details.php?refNo=1181&itemTy...
    1204    previous_vehicle_details.php?refNo=1182&itemTy...
    Name: URL, Length: 1205, dtype: object




```python
auction_results['URL'].to_frame()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>URL</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>previous_vehicle_details.php?refNo=1&amp;itemType=...</td>
    </tr>
    <tr>
      <th>1</th>
      <td>previous_vehicle_details.php?refNo=2&amp;itemType=...</td>
    </tr>
    <tr>
      <th>2</th>
      <td>previous_vehicle_details.php?refNo=3&amp;itemType=...</td>
    </tr>
    <tr>
      <th>3</th>
      <td>previous_vehicle_details.php?refNo=4&amp;itemType=...</td>
    </tr>
    <tr>
      <th>4</th>
      <td>previous_vehicle_details.php?refNo=5&amp;itemType=...</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
    </tr>
    <tr>
      <th>1200</th>
      <td>previous_vehicle_details.php?refNo=1178&amp;itemTy...</td>
    </tr>
    <tr>
      <th>1201</th>
      <td>previous_vehicle_details.php?refNo=1179&amp;itemTy...</td>
    </tr>
    <tr>
      <th>1202</th>
      <td>previous_vehicle_details.php?refNo=1180&amp;itemTy...</td>
    </tr>
    <tr>
      <th>1203</th>
      <td>previous_vehicle_details.php?refNo=1181&amp;itemTy...</td>
    </tr>
    <tr>
      <th>1204</th>
      <td>previous_vehicle_details.php?refNo=1182&amp;itemTy...</td>
    </tr>
  </tbody>
</table>
<p>1205 rows × 1 columns</p>
</div>




```python
#split all the rows in the URL column to extract the text we want which in this case is the last text
auction_results['URL'] = auction_results['URL'].apply(lambda a: a.split('=')[-1])

print(auction_results)

```

          Unnamed: 0      URL           Reference Number          Price  \
    0              0  Vehicle       NCS/PTML/OVT/01/24/1    ₦892,000.00   
    1              1  Vehicle       NCS/PTML/OVT/01/24/2    ₦500,000.00   
    2              2  Vehicle       NCS/PTML/OVT/01/24/3    ₦420,000.00   
    3              3  Vehicle       NCS/PTML/OVT/01/24/4    ₦800,000.00   
    4              4  Vehicle       NCS/PTML/OVT/01/24/5    ₦715,000.00   
    ...          ...      ...                        ...            ...   
    1200        1200  Vehicle  NCS/TCIP/OVT/08/2024/1178    ₦648,000.00   
    1201        1201  Vehicle  NCS/TCIP/OVT/08/2024/1179  ₦1,200,000.00   
    1202        1202  Vehicle  NCS/TCIP/OVT/08/2024/1180  ₦1,626,898.00   
    1203        1203  Vehicle  NCS/TCIP/OVT/08/2024/1181    ₦533,333.00   
    1204        1204  Vehicle  NCS/TCIP/OVT/08/2024/1182    ₦520,000.00   
    
                                      Car Title          Condition   VIN  \
    0     TOYOTA CAMRY HYBRID LE 4DR SEDAN 2006  4T1BE32K86U111063  Used   
    1                             ACURA TL 2004  19UUA66214A013030  Used   
    2       HONDA ACCORD EX 1.5T 4DR SEDAN 2004  1HGCM66554A098192  Used   
    3           TOYOTA COROLLA L 4DR SEDAN 2007  2T1BR32E27C777272  Used   
    4                          PEUGEOT 307 2008  VF33CNFUL84568049  Used   
    ...                                     ...                ...   ...   
    1200                    FORD  FREESTAR 2004             B29970  Used   
    1201                TOYOTA  HIGHLANDER 2012  5TDYK3EH5CS070513  Used   
    1202                  HONDA  CROSSTOUR 2014             000016  Used   
    1203                 HYUNDAI  SANTA FE 2004            U572121  Used   
    1204                      TOYOTA CAMRY 1996             824426  Used   
    
         Transmission Mileage Fuel Type  
    0       Automatic  0.00KM    Petrol  
    1       Automatic  0.00KM    Petrol  
    2       Automatic  0.00KM    Petrol  
    3       Automatic  0.00KM    Petrol  
    4       Automatic  0.00KM    Petrol  
    ...           ...     ...       ...  
    1200    Automatic  0.00KM    Petrol  
    1201    Automatic  0.00KM    Petrol  
    1202    Automatic  0.00KM    Petrol  
    1203    Automatic  0.00KM    Petrol  
    1204    Automatic  0.00KM    Petrol  
    
    [1205 rows x 10 columns]
    


```python
auction_results['URL'] = 'Vehicle'

auction_results['URL'].to_frame()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>URL</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Vehicle</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Vehicle</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Vehicle</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Vehicle</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Vehicle</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
    </tr>
    <tr>
      <th>1200</th>
      <td>Vehicle</td>
    </tr>
    <tr>
      <th>1201</th>
      <td>Vehicle</td>
    </tr>
    <tr>
      <th>1202</th>
      <td>Vehicle</td>
    </tr>
    <tr>
      <th>1203</th>
      <td>Vehicle</td>
    </tr>
    <tr>
      <th>1204</th>
      <td>Vehicle</td>
    </tr>
  </tbody>
</table>
<p>1205 rows × 1 columns</p>
</div>




```python
auction_results['URL'] = 'Container'
auction_results['URL'].to_frame()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>URL</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Container</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Container</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Container</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Container</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Container</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
    </tr>
    <tr>
      <th>1200</th>
      <td>Container</td>
    </tr>
    <tr>
      <th>1201</th>
      <td>Container</td>
    </tr>
    <tr>
      <th>1202</th>
      <td>Container</td>
    </tr>
    <tr>
      <th>1203</th>
      <td>Container</td>
    </tr>
    <tr>
      <th>1204</th>
      <td>Container</td>
    </tr>
  </tbody>
</table>
<p>1205 rows × 1 columns</p>
</div>




```python

import pandas as pd

auction_results = pd.read_csv('C:\\Users\\HP\\Desktop\\Phyton for everybody with Dr Chuck\\Scrapped_Data\\Unclean_Raw_Scrapped_bidding_data.csv')
auction_results['URL'] = auction_results['URL'].apply(lambda a: a.split('=')[-1])
auction_results

print(auction_results)
```

          Unnamed: 0      URL           Reference Number          Price  \
    0              0  Vehicle       NCS/PTML/OVT/01/24/1    ₦892,000.00   
    1              1  Vehicle       NCS/PTML/OVT/01/24/2    ₦500,000.00   
    2              2  Vehicle       NCS/PTML/OVT/01/24/3    ₦420,000.00   
    3              3  Vehicle       NCS/PTML/OVT/01/24/4    ₦800,000.00   
    4              4  Vehicle       NCS/PTML/OVT/01/24/5    ₦715,000.00   
    ...          ...      ...                        ...            ...   
    1200        1200  Vehicle  NCS/TCIP/OVT/08/2024/1178    ₦648,000.00   
    1201        1201  Vehicle  NCS/TCIP/OVT/08/2024/1179  ₦1,200,000.00   
    1202        1202  Vehicle  NCS/TCIP/OVT/08/2024/1180  ₦1,626,898.00   
    1203        1203  Vehicle  NCS/TCIP/OVT/08/2024/1181    ₦533,333.00   
    1204        1204  Vehicle  NCS/TCIP/OVT/08/2024/1182    ₦520,000.00   
    
                                      Car Title          Condition   VIN  \
    0     TOYOTA CAMRY HYBRID LE 4DR SEDAN 2006  4T1BE32K86U111063  Used   
    1                             ACURA TL 2004  19UUA66214A013030  Used   
    2       HONDA ACCORD EX 1.5T 4DR SEDAN 2004  1HGCM66554A098192  Used   
    3           TOYOTA COROLLA L 4DR SEDAN 2007  2T1BR32E27C777272  Used   
    4                          PEUGEOT 307 2008  VF33CNFUL84568049  Used   
    ...                                     ...                ...   ...   
    1200                    FORD  FREESTAR 2004             B29970  Used   
    1201                TOYOTA  HIGHLANDER 2012  5TDYK3EH5CS070513  Used   
    1202                  HONDA  CROSSTOUR 2014             000016  Used   
    1203                 HYUNDAI  SANTA FE 2004            U572121  Used   
    1204                      TOYOTA CAMRY 1996             824426  Used   
    
         Transmission Mileage Fuel Type  
    0       Automatic  0.00KM    Petrol  
    1       Automatic  0.00KM    Petrol  
    2       Automatic  0.00KM    Petrol  
    3       Automatic  0.00KM    Petrol  
    4       Automatic  0.00KM    Petrol  
    ...           ...     ...       ...  
    1200    Automatic  0.00KM    Petrol  
    1201    Automatic  0.00KM    Petrol  
    1202    Automatic  0.00KM    Petrol  
    1203    Automatic  0.00KM    Petrol  
    1204    Automatic  0.00KM    Petrol  
    
    [1205 rows x 10 columns]
    


```python
from IPython.display import display
import pandas as pd

auction_results = pd.read_csv('C:\\Users\\HP\\Desktop\\Phyton for everybody with Dr Chuck\\Scrapped_Data\\Unclean_Raw_Scrapped_bidding_data.csv')
auction_results['URL'] = auction_results['URL'].apply(lambda a: a.split('=')[-1])

display(auction_results)
```


<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Unnamed: 0</th>
      <th>URL</th>
      <th>Reference Number</th>
      <th>Price</th>
      <th>Car Title</th>
      <th>Condition</th>
      <th>VIN</th>
      <th>Transmission</th>
      <th>Mileage</th>
      <th>Fuel Type</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0</td>
      <td>Vehicle</td>
      <td>NCS/PTML/OVT/01/24/1</td>
      <td>₦892,000.00</td>
      <td>TOYOTA CAMRY HYBRID LE 4DR SEDAN 2006</td>
      <td>4T1BE32K86U111063</td>
      <td>Used</td>
      <td>Automatic</td>
      <td>0.00KM</td>
      <td>Petrol</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1</td>
      <td>Vehicle</td>
      <td>NCS/PTML/OVT/01/24/2</td>
      <td>₦500,000.00</td>
      <td>ACURA TL 2004</td>
      <td>19UUA66214A013030</td>
      <td>Used</td>
      <td>Automatic</td>
      <td>0.00KM</td>
      <td>Petrol</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2</td>
      <td>Vehicle</td>
      <td>NCS/PTML/OVT/01/24/3</td>
      <td>₦420,000.00</td>
      <td>HONDA ACCORD EX 1.5T 4DR SEDAN 2004</td>
      <td>1HGCM66554A098192</td>
      <td>Used</td>
      <td>Automatic</td>
      <td>0.00KM</td>
      <td>Petrol</td>
    </tr>
    <tr>
      <th>3</th>
      <td>3</td>
      <td>Vehicle</td>
      <td>NCS/PTML/OVT/01/24/4</td>
      <td>₦800,000.00</td>
      <td>TOYOTA COROLLA L 4DR SEDAN 2007</td>
      <td>2T1BR32E27C777272</td>
      <td>Used</td>
      <td>Automatic</td>
      <td>0.00KM</td>
      <td>Petrol</td>
    </tr>
    <tr>
      <th>4</th>
      <td>4</td>
      <td>Vehicle</td>
      <td>NCS/PTML/OVT/01/24/5</td>
      <td>₦715,000.00</td>
      <td>PEUGEOT 307 2008</td>
      <td>VF33CNFUL84568049</td>
      <td>Used</td>
      <td>Automatic</td>
      <td>0.00KM</td>
      <td>Petrol</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>1200</th>
      <td>1200</td>
      <td>Vehicle</td>
      <td>NCS/TCIP/OVT/08/2024/1178</td>
      <td>₦648,000.00</td>
      <td>FORD  FREESTAR 2004</td>
      <td>B29970</td>
      <td>Used</td>
      <td>Automatic</td>
      <td>0.00KM</td>
      <td>Petrol</td>
    </tr>
    <tr>
      <th>1201</th>
      <td>1201</td>
      <td>Vehicle</td>
      <td>NCS/TCIP/OVT/08/2024/1179</td>
      <td>₦1,200,000.00</td>
      <td>TOYOTA  HIGHLANDER 2012</td>
      <td>5TDYK3EH5CS070513</td>
      <td>Used</td>
      <td>Automatic</td>
      <td>0.00KM</td>
      <td>Petrol</td>
    </tr>
    <tr>
      <th>1202</th>
      <td>1202</td>
      <td>Vehicle</td>
      <td>NCS/TCIP/OVT/08/2024/1180</td>
      <td>₦1,626,898.00</td>
      <td>HONDA  CROSSTOUR 2014</td>
      <td>000016</td>
      <td>Used</td>
      <td>Automatic</td>
      <td>0.00KM</td>
      <td>Petrol</td>
    </tr>
    <tr>
      <th>1203</th>
      <td>1203</td>
      <td>Vehicle</td>
      <td>NCS/TCIP/OVT/08/2024/1181</td>
      <td>₦533,333.00</td>
      <td>HYUNDAI  SANTA FE 2004</td>
      <td>U572121</td>
      <td>Used</td>
      <td>Automatic</td>
      <td>0.00KM</td>
      <td>Petrol</td>
    </tr>
    <tr>
      <th>1204</th>
      <td>1204</td>
      <td>Vehicle</td>
      <td>NCS/TCIP/OVT/08/2024/1182</td>
      <td>₦520,000.00</td>
      <td>TOYOTA CAMRY 1996</td>
      <td>824426</td>
      <td>Used</td>
      <td>Automatic</td>
      <td>0.00KM</td>
      <td>Petrol</td>
    </tr>
  </tbody>
</table>
<p>1205 rows × 10 columns</p>
</div>



```python
# Changing the Condition column values whose name will be changed in the future
# it is vital to know that the Condition column is supposed to be the TIN and vice versa
# Give the values in Condition Column some meaning

auction_results['Condition'].replace({'Nigeria': 'Cont23456'}, inplace=True)

auction_results
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Unnamed: 0</th>
      <th>URL</th>
      <th>Reference Number</th>
      <th>Price</th>
      <th>Car Title</th>
      <th>Condition</th>
      <th>VIN</th>
      <th>Transmission</th>
      <th>Mileage</th>
      <th>Fuel Type</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0</td>
      <td>Vehicle</td>
      <td>NCS/PTML/OVT/01/24/1</td>
      <td>₦892,000.00</td>
      <td>TOYOTA CAMRY HYBRID LE 4DR SEDAN 2006</td>
      <td>4T1BE32K86U111063</td>
      <td>Used</td>
      <td>Automatic</td>
      <td>0.00KM</td>
      <td>Petrol</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1</td>
      <td>Vehicle</td>
      <td>NCS/PTML/OVT/01/24/2</td>
      <td>₦500,000.00</td>
      <td>ACURA TL 2004</td>
      <td>19UUA66214A013030</td>
      <td>Used</td>
      <td>Automatic</td>
      <td>0.00KM</td>
      <td>Petrol</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2</td>
      <td>Vehicle</td>
      <td>NCS/PTML/OVT/01/24/3</td>
      <td>₦420,000.00</td>
      <td>HONDA ACCORD EX 1.5T 4DR SEDAN 2004</td>
      <td>1HGCM66554A098192</td>
      <td>Used</td>
      <td>Automatic</td>
      <td>0.00KM</td>
      <td>Petrol</td>
    </tr>
    <tr>
      <th>3</th>
      <td>3</td>
      <td>Vehicle</td>
      <td>NCS/PTML/OVT/01/24/4</td>
      <td>₦800,000.00</td>
      <td>TOYOTA COROLLA L 4DR SEDAN 2007</td>
      <td>2T1BR32E27C777272</td>
      <td>Used</td>
      <td>Automatic</td>
      <td>0.00KM</td>
      <td>Petrol</td>
    </tr>
    <tr>
      <th>4</th>
      <td>4</td>
      <td>Vehicle</td>
      <td>NCS/PTML/OVT/01/24/5</td>
      <td>₦715,000.00</td>
      <td>PEUGEOT 307 2008</td>
      <td>VF33CNFUL84568049</td>
      <td>Used</td>
      <td>Automatic</td>
      <td>0.00KM</td>
      <td>Petrol</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>1200</th>
      <td>1200</td>
      <td>Vehicle</td>
      <td>NCS/TCIP/OVT/08/2024/1178</td>
      <td>₦648,000.00</td>
      <td>FORD  FREESTAR 2004</td>
      <td>B29970</td>
      <td>Used</td>
      <td>Automatic</td>
      <td>0.00KM</td>
      <td>Petrol</td>
    </tr>
    <tr>
      <th>1201</th>
      <td>1201</td>
      <td>Vehicle</td>
      <td>NCS/TCIP/OVT/08/2024/1179</td>
      <td>₦1,200,000.00</td>
      <td>TOYOTA  HIGHLANDER 2012</td>
      <td>5TDYK3EH5CS070513</td>
      <td>Used</td>
      <td>Automatic</td>
      <td>0.00KM</td>
      <td>Petrol</td>
    </tr>
    <tr>
      <th>1202</th>
      <td>1202</td>
      <td>Vehicle</td>
      <td>NCS/TCIP/OVT/08/2024/1180</td>
      <td>₦1,626,898.00</td>
      <td>HONDA  CROSSTOUR 2014</td>
      <td>000016</td>
      <td>Used</td>
      <td>Automatic</td>
      <td>0.00KM</td>
      <td>Petrol</td>
    </tr>
    <tr>
      <th>1203</th>
      <td>1203</td>
      <td>Vehicle</td>
      <td>NCS/TCIP/OVT/08/2024/1181</td>
      <td>₦533,333.00</td>
      <td>HYUNDAI  SANTA FE 2004</td>
      <td>U572121</td>
      <td>Used</td>
      <td>Automatic</td>
      <td>0.00KM</td>
      <td>Petrol</td>
    </tr>
    <tr>
      <th>1204</th>
      <td>1204</td>
      <td>Vehicle</td>
      <td>NCS/TCIP/OVT/08/2024/1182</td>
      <td>₦520,000.00</td>
      <td>TOYOTA CAMRY 1996</td>
      <td>824426</td>
      <td>Used</td>
      <td>Automatic</td>
      <td>0.00KM</td>
      <td>Petrol</td>
    </tr>
  </tbody>
</table>
<p>1205 rows × 10 columns</p>
</div>




```python
auction_results['Condition'] = 'Cont23456'

auction_results['Condition'].to_frame()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Condition</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Cont23456</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Cont23456</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Cont23456</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Cont23456</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Cont23456</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
    </tr>
    <tr>
      <th>1200</th>
      <td>Cont23456</td>
    </tr>
    <tr>
      <th>1201</th>
      <td>Cont23456</td>
    </tr>
    <tr>
      <th>1202</th>
      <td>Cont23456</td>
    </tr>
    <tr>
      <th>1203</th>
      <td>Cont23456</td>
    </tr>
    <tr>
      <th>1204</th>
      <td>Cont23456</td>
    </tr>
  </tbody>
</table>
<p>1205 rows × 1 columns</p>
</div>




```python
# Changing the TIN column values whose name will be changed in the future
# it is vital to know that the TIN column is supposed to be the condition and vice versa

auction_results['VIN'].replace({'Used': 'Used_Vehicle', 'Accidented': 'Used_Vehicle', '0KG': 'Used_Items_In_Container', 
                                  '1,020KG': 'Used_items_In_Container', '19,958KG': 'Used_Items_In_Container'}, inplace=True)

auction_results
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Unnamed: 0</th>
      <th>URL</th>
      <th>Reference Number</th>
      <th>Price</th>
      <th>Car Title</th>
      <th>Condition</th>
      <th>VIN</th>
      <th>Transmission</th>
      <th>Mileage</th>
      <th>Fuel Type</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0</td>
      <td>Vehicle</td>
      <td>NCS/PTML/OVT/01/24/1</td>
      <td>₦892,000.00</td>
      <td>TOYOTA CAMRY HYBRID LE 4DR SEDAN 2006</td>
      <td>Cont23456</td>
      <td>Used_Vehicle</td>
      <td>Automatic</td>
      <td>0.00KM</td>
      <td>Petrol</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1</td>
      <td>Vehicle</td>
      <td>NCS/PTML/OVT/01/24/2</td>
      <td>₦500,000.00</td>
      <td>ACURA TL 2004</td>
      <td>Cont23456</td>
      <td>Used_Vehicle</td>
      <td>Automatic</td>
      <td>0.00KM</td>
      <td>Petrol</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2</td>
      <td>Vehicle</td>
      <td>NCS/PTML/OVT/01/24/3</td>
      <td>₦420,000.00</td>
      <td>HONDA ACCORD EX 1.5T 4DR SEDAN 2004</td>
      <td>Cont23456</td>
      <td>Used_Vehicle</td>
      <td>Automatic</td>
      <td>0.00KM</td>
      <td>Petrol</td>
    </tr>
    <tr>
      <th>3</th>
      <td>3</td>
      <td>Vehicle</td>
      <td>NCS/PTML/OVT/01/24/4</td>
      <td>₦800,000.00</td>
      <td>TOYOTA COROLLA L 4DR SEDAN 2007</td>
      <td>Cont23456</td>
      <td>Used_Vehicle</td>
      <td>Automatic</td>
      <td>0.00KM</td>
      <td>Petrol</td>
    </tr>
    <tr>
      <th>4</th>
      <td>4</td>
      <td>Vehicle</td>
      <td>NCS/PTML/OVT/01/24/5</td>
      <td>₦715,000.00</td>
      <td>PEUGEOT 307 2008</td>
      <td>Cont23456</td>
      <td>Used_Vehicle</td>
      <td>Automatic</td>
      <td>0.00KM</td>
      <td>Petrol</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>1200</th>
      <td>1200</td>
      <td>Vehicle</td>
      <td>NCS/TCIP/OVT/08/2024/1178</td>
      <td>₦648,000.00</td>
      <td>FORD  FREESTAR 2004</td>
      <td>Cont23456</td>
      <td>Used_Vehicle</td>
      <td>Automatic</td>
      <td>0.00KM</td>
      <td>Petrol</td>
    </tr>
    <tr>
      <th>1201</th>
      <td>1201</td>
      <td>Vehicle</td>
      <td>NCS/TCIP/OVT/08/2024/1179</td>
      <td>₦1,200,000.00</td>
      <td>TOYOTA  HIGHLANDER 2012</td>
      <td>Cont23456</td>
      <td>Used_Vehicle</td>
      <td>Automatic</td>
      <td>0.00KM</td>
      <td>Petrol</td>
    </tr>
    <tr>
      <th>1202</th>
      <td>1202</td>
      <td>Vehicle</td>
      <td>NCS/TCIP/OVT/08/2024/1180</td>
      <td>₦1,626,898.00</td>
      <td>HONDA  CROSSTOUR 2014</td>
      <td>Cont23456</td>
      <td>Used_Vehicle</td>
      <td>Automatic</td>
      <td>0.00KM</td>
      <td>Petrol</td>
    </tr>
    <tr>
      <th>1203</th>
      <td>1203</td>
      <td>Vehicle</td>
      <td>NCS/TCIP/OVT/08/2024/1181</td>
      <td>₦533,333.00</td>
      <td>HYUNDAI  SANTA FE 2004</td>
      <td>Cont23456</td>
      <td>Used_Vehicle</td>
      <td>Automatic</td>
      <td>0.00KM</td>
      <td>Petrol</td>
    </tr>
    <tr>
      <th>1204</th>
      <td>1204</td>
      <td>Vehicle</td>
      <td>NCS/TCIP/OVT/08/2024/1182</td>
      <td>₦520,000.00</td>
      <td>TOYOTA CAMRY 1996</td>
      <td>Cont23456</td>
      <td>Used_Vehicle</td>
      <td>Automatic</td>
      <td>0.00KM</td>
      <td>Petrol</td>
    </tr>
  </tbody>
</table>
<p>1205 rows × 10 columns</p>
</div>




```python
auction_results['VIN'].to_frame()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>VIN</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Used_Vehicle</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Used_Vehicle</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Used_Vehicle</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Used_Vehicle</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Used_Vehicle</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
    </tr>
    <tr>
      <th>1200</th>
      <td>Used_Vehicle</td>
    </tr>
    <tr>
      <th>1201</th>
      <td>Used_Vehicle</td>
    </tr>
    <tr>
      <th>1202</th>
      <td>Used_Vehicle</td>
    </tr>
    <tr>
      <th>1203</th>
      <td>Used_Vehicle</td>
    </tr>
    <tr>
      <th>1204</th>
      <td>Used_Vehicle</td>
    </tr>
  </tbody>
</table>
<p>1205 rows × 1 columns</p>
</div>




```python
auction_results['VIN'] = 'Used_Items_In_Container'

auction_results['VIN'].to_frame()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>VIN</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Used_Items_In_Container</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Used_Items_In_Container</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Used_Items_In_Container</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Used_Items_In_Container</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Used_Items_In_Container</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
    </tr>
    <tr>
      <th>1200</th>
      <td>Used_Items_In_Container</td>
    </tr>
    <tr>
      <th>1201</th>
      <td>Used_Items_In_Container</td>
    </tr>
    <tr>
      <th>1202</th>
      <td>Used_Items_In_Container</td>
    </tr>
    <tr>
      <th>1203</th>
      <td>Used_Items_In_Container</td>
    </tr>
    <tr>
      <th>1204</th>
      <td>Used_Items_In_Container</td>
    </tr>
  </tbody>
</table>
<p>1205 rows × 1 columns</p>
</div>




```python
# checking for isna values in the transmission column
auction_results['Transmission'].isna().values.any()
```




    True




```python
auction_results.loc[auction_results['Transmission'].isna()]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Unnamed: 0</th>
      <th>URL</th>
      <th>Reference Number</th>
      <th>Price</th>
      <th>Car Title</th>
      <th>Condition</th>
      <th>VIN</th>
      <th>Transmission</th>
      <th>Mileage</th>
      <th>Fuel Type</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>253</th>
      <td>253</td>
      <td>Container</td>
      <td>NCS/TCIP/OVT/03/2024/1</td>
      <td>₦25,000,000.00</td>
      <td>DFSU6276690</td>
      <td>Cont23456</td>
      <td>Used_Items_In_Container</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>254</th>
      <td>254</td>
      <td>Container</td>
      <td>NCS/TCIP/OVT/03/2024/2</td>
      <td>₦19,000,500.00</td>
      <td>CSNU6062890</td>
      <td>Cont23456</td>
      <td>Used_Items_In_Container</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>255</th>
      <td>255</td>
      <td>Container</td>
      <td>NCS/TCIP/OVT/03/2024/3</td>
      <td>₦9,000,000.00</td>
      <td>CBHU8708359</td>
      <td>Cont23456</td>
      <td>Used_Items_In_Container</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>256</th>
      <td>256</td>
      <td>Container</td>
      <td>NCS/TCIP/OVT/03/2024/4</td>
      <td>₦8,700,000.00</td>
      <td>CSNU6999438</td>
      <td>Cont23456</td>
      <td>Used_Items_In_Container</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>257</th>
      <td>257</td>
      <td>Container</td>
      <td>NCS/TCIP/OVT/03/2024/5</td>
      <td>₦29,000,000.00</td>
      <td>CBHU7069227</td>
      <td>Cont23456</td>
      <td>Used_Items_In_Container</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>710</th>
      <td>710</td>
      <td>Container</td>
      <td>NCS/PTML/OVT/03/2024/109</td>
      <td>₦1,999,766.00</td>
      <td>CSNU6979220</td>
      <td>Cont23456</td>
      <td>Used_Items_In_Container</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>711</th>
      <td>711</td>
      <td>Container</td>
      <td>NCS/PTML/OVT/03/2024/110</td>
      <td>₦1,700,000.00</td>
      <td>PCIU0169958</td>
      <td>Cont23456</td>
      <td>Used_Items_In_Container</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>712</th>
      <td>712</td>
      <td>Container</td>
      <td>NCS/PTML/OVT/03/2024/111</td>
      <td>₦4,511,100.00</td>
      <td>ACLU9779415</td>
      <td>Cont23456</td>
      <td>Used_Items_In_Container</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>713</th>
      <td>713</td>
      <td>Container</td>
      <td>NCS/PTML/OVT/03/2024/112</td>
      <td>₦3,677,777.00</td>
      <td>GCNU1220147</td>
      <td>Cont23456</td>
      <td>Used_Items_In_Container</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>714</th>
      <td>714</td>
      <td>Container</td>
      <td>NCS/PTML/OVT/03/2024/113</td>
      <td>₦4,500,000.00</td>
      <td>ACLU9699006</td>
      <td>Cont23456</td>
      <td>Used_Items_In_Container</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
  </tbody>
</table>
<p>81 rows × 10 columns</p>
</div>




```python
# Give the values in the Transmission Column some meaning
auction_results['Transmission'].replace({'AUTOMATIC': 'Automatic_Vehicle', 'Automatic': 'Automatic_Vehicle', 
                                         'Manual': 'Manual_Vehicle'}, inplace=True)

auction_results
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Unnamed: 0</th>
      <th>URL</th>
      <th>Reference Number</th>
      <th>Price</th>
      <th>Car Title</th>
      <th>Condition</th>
      <th>VIN</th>
      <th>Transmission</th>
      <th>Mileage</th>
      <th>Fuel Type</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0</td>
      <td>Vehicle</td>
      <td>NCS/PTML/OVT/01/24/1</td>
      <td>₦892,000.00</td>
      <td>TOYOTA CAMRY HYBRID LE 4DR SEDAN 2006</td>
      <td>Cont23456</td>
      <td>Used_Items_In_Container</td>
      <td>Automatic_Vehicle</td>
      <td>0.00KM</td>
      <td>Petrol</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1</td>
      <td>Vehicle</td>
      <td>NCS/PTML/OVT/01/24/2</td>
      <td>₦500,000.00</td>
      <td>ACURA TL 2004</td>
      <td>Cont23456</td>
      <td>Used_Items_In_Container</td>
      <td>Automatic_Vehicle</td>
      <td>0.00KM</td>
      <td>Petrol</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2</td>
      <td>Vehicle</td>
      <td>NCS/PTML/OVT/01/24/3</td>
      <td>₦420,000.00</td>
      <td>HONDA ACCORD EX 1.5T 4DR SEDAN 2004</td>
      <td>Cont23456</td>
      <td>Used_Items_In_Container</td>
      <td>Automatic_Vehicle</td>
      <td>0.00KM</td>
      <td>Petrol</td>
    </tr>
    <tr>
      <th>3</th>
      <td>3</td>
      <td>Vehicle</td>
      <td>NCS/PTML/OVT/01/24/4</td>
      <td>₦800,000.00</td>
      <td>TOYOTA COROLLA L 4DR SEDAN 2007</td>
      <td>Cont23456</td>
      <td>Used_Items_In_Container</td>
      <td>Automatic_Vehicle</td>
      <td>0.00KM</td>
      <td>Petrol</td>
    </tr>
    <tr>
      <th>4</th>
      <td>4</td>
      <td>Vehicle</td>
      <td>NCS/PTML/OVT/01/24/5</td>
      <td>₦715,000.00</td>
      <td>PEUGEOT 307 2008</td>
      <td>Cont23456</td>
      <td>Used_Items_In_Container</td>
      <td>Automatic_Vehicle</td>
      <td>0.00KM</td>
      <td>Petrol</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>1200</th>
      <td>1200</td>
      <td>Vehicle</td>
      <td>NCS/TCIP/OVT/08/2024/1178</td>
      <td>₦648,000.00</td>
      <td>FORD  FREESTAR 2004</td>
      <td>Cont23456</td>
      <td>Used_Items_In_Container</td>
      <td>Automatic_Vehicle</td>
      <td>0.00KM</td>
      <td>Petrol</td>
    </tr>
    <tr>
      <th>1201</th>
      <td>1201</td>
      <td>Vehicle</td>
      <td>NCS/TCIP/OVT/08/2024/1179</td>
      <td>₦1,200,000.00</td>
      <td>TOYOTA  HIGHLANDER 2012</td>
      <td>Cont23456</td>
      <td>Used_Items_In_Container</td>
      <td>Automatic_Vehicle</td>
      <td>0.00KM</td>
      <td>Petrol</td>
    </tr>
    <tr>
      <th>1202</th>
      <td>1202</td>
      <td>Vehicle</td>
      <td>NCS/TCIP/OVT/08/2024/1180</td>
      <td>₦1,626,898.00</td>
      <td>HONDA  CROSSTOUR 2014</td>
      <td>Cont23456</td>
      <td>Used_Items_In_Container</td>
      <td>Automatic_Vehicle</td>
      <td>0.00KM</td>
      <td>Petrol</td>
    </tr>
    <tr>
      <th>1203</th>
      <td>1203</td>
      <td>Vehicle</td>
      <td>NCS/TCIP/OVT/08/2024/1181</td>
      <td>₦533,333.00</td>
      <td>HYUNDAI  SANTA FE 2004</td>
      <td>Cont23456</td>
      <td>Used_Items_In_Container</td>
      <td>Automatic_Vehicle</td>
      <td>0.00KM</td>
      <td>Petrol</td>
    </tr>
    <tr>
      <th>1204</th>
      <td>1204</td>
      <td>Vehicle</td>
      <td>NCS/TCIP/OVT/08/2024/1182</td>
      <td>₦520,000.00</td>
      <td>TOYOTA CAMRY 1996</td>
      <td>Cont23456</td>
      <td>Used_Items_In_Container</td>
      <td>Automatic_Vehicle</td>
      <td>0.00KM</td>
      <td>Petrol</td>
    </tr>
  </tbody>
</table>
<p>1205 rows × 10 columns</p>
</div>




```python
# Replacing NaN values
auction_results['Transmission'] = auction_results['Transmission'].fillna('Container_Like').replace('NaN', 'Container_Like')

auction_results
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Unnamed: 0</th>
      <th>URL</th>
      <th>Reference Number</th>
      <th>Price</th>
      <th>Car Title</th>
      <th>Condition</th>
      <th>VIN</th>
      <th>Transmission</th>
      <th>Mileage</th>
      <th>Fuel Type</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0</td>
      <td>Vehicle</td>
      <td>NCS/PTML/OVT/01/24/1</td>
      <td>₦892,000.00</td>
      <td>TOYOTA CAMRY HYBRID LE 4DR SEDAN 2006</td>
      <td>Cont23456</td>
      <td>Used_Items_In_Container</td>
      <td>Automatic_Vehicle</td>
      <td>0.00KM</td>
      <td>Petrol</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1</td>
      <td>Vehicle</td>
      <td>NCS/PTML/OVT/01/24/2</td>
      <td>₦500,000.00</td>
      <td>ACURA TL 2004</td>
      <td>Cont23456</td>
      <td>Used_Items_In_Container</td>
      <td>Automatic_Vehicle</td>
      <td>0.00KM</td>
      <td>Petrol</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2</td>
      <td>Vehicle</td>
      <td>NCS/PTML/OVT/01/24/3</td>
      <td>₦420,000.00</td>
      <td>HONDA ACCORD EX 1.5T 4DR SEDAN 2004</td>
      <td>Cont23456</td>
      <td>Used_Items_In_Container</td>
      <td>Automatic_Vehicle</td>
      <td>0.00KM</td>
      <td>Petrol</td>
    </tr>
    <tr>
      <th>3</th>
      <td>3</td>
      <td>Vehicle</td>
      <td>NCS/PTML/OVT/01/24/4</td>
      <td>₦800,000.00</td>
      <td>TOYOTA COROLLA L 4DR SEDAN 2007</td>
      <td>Cont23456</td>
      <td>Used_Items_In_Container</td>
      <td>Automatic_Vehicle</td>
      <td>0.00KM</td>
      <td>Petrol</td>
    </tr>
    <tr>
      <th>4</th>
      <td>4</td>
      <td>Vehicle</td>
      <td>NCS/PTML/OVT/01/24/5</td>
      <td>₦715,000.00</td>
      <td>PEUGEOT 307 2008</td>
      <td>Cont23456</td>
      <td>Used_Items_In_Container</td>
      <td>Automatic_Vehicle</td>
      <td>0.00KM</td>
      <td>Petrol</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>1200</th>
      <td>1200</td>
      <td>Vehicle</td>
      <td>NCS/TCIP/OVT/08/2024/1178</td>
      <td>₦648,000.00</td>
      <td>FORD  FREESTAR 2004</td>
      <td>Cont23456</td>
      <td>Used_Items_In_Container</td>
      <td>Automatic_Vehicle</td>
      <td>0.00KM</td>
      <td>Petrol</td>
    </tr>
    <tr>
      <th>1201</th>
      <td>1201</td>
      <td>Vehicle</td>
      <td>NCS/TCIP/OVT/08/2024/1179</td>
      <td>₦1,200,000.00</td>
      <td>TOYOTA  HIGHLANDER 2012</td>
      <td>Cont23456</td>
      <td>Used_Items_In_Container</td>
      <td>Automatic_Vehicle</td>
      <td>0.00KM</td>
      <td>Petrol</td>
    </tr>
    <tr>
      <th>1202</th>
      <td>1202</td>
      <td>Vehicle</td>
      <td>NCS/TCIP/OVT/08/2024/1180</td>
      <td>₦1,626,898.00</td>
      <td>HONDA  CROSSTOUR 2014</td>
      <td>Cont23456</td>
      <td>Used_Items_In_Container</td>
      <td>Automatic_Vehicle</td>
      <td>0.00KM</td>
      <td>Petrol</td>
    </tr>
    <tr>
      <th>1203</th>
      <td>1203</td>
      <td>Vehicle</td>
      <td>NCS/TCIP/OVT/08/2024/1181</td>
      <td>₦533,333.00</td>
      <td>HYUNDAI  SANTA FE 2004</td>
      <td>Cont23456</td>
      <td>Used_Items_In_Container</td>
      <td>Automatic_Vehicle</td>
      <td>0.00KM</td>
      <td>Petrol</td>
    </tr>
    <tr>
      <th>1204</th>
      <td>1204</td>
      <td>Vehicle</td>
      <td>NCS/TCIP/OVT/08/2024/1182</td>
      <td>₦520,000.00</td>
      <td>TOYOTA CAMRY 1996</td>
      <td>Cont23456</td>
      <td>Used_Items_In_Container</td>
      <td>Automatic_Vehicle</td>
      <td>0.00KM</td>
      <td>Petrol</td>
    </tr>
  </tbody>
</table>
<p>1205 rows × 10 columns</p>
</div>




```python
auction_results.loc[auction_results['Transmission'].isna()]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Unnamed: 0</th>
      <th>URL</th>
      <th>Reference Number</th>
      <th>Price</th>
      <th>Car Title</th>
      <th>Condition</th>
      <th>VIN</th>
      <th>Transmission</th>
      <th>Mileage</th>
      <th>Fuel Type</th>
    </tr>
  </thead>
  <tbody>
  </tbody>
</table>
</div>




```python
auction_results['Transmission'].to_frame()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Transmission</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Automatic_Vehicle</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Automatic_Vehicle</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Automatic_Vehicle</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Automatic_Vehicle</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Automatic_Vehicle</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
    </tr>
    <tr>
      <th>1200</th>
      <td>Automatic_Vehicle</td>
    </tr>
    <tr>
      <th>1201</th>
      <td>Automatic_Vehicle</td>
    </tr>
    <tr>
      <th>1202</th>
      <td>Automatic_Vehicle</td>
    </tr>
    <tr>
      <th>1203</th>
      <td>Automatic_Vehicle</td>
    </tr>
    <tr>
      <th>1204</th>
      <td>Automatic_Vehicle</td>
    </tr>
  </tbody>
</table>
<p>1205 rows × 1 columns</p>
</div>




```python
auction_results['Transmission'] = 'Manual_Vehicle'

auction_results['Transmission'].to_frame()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Transmission</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Manual_Vehicle</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Manual_Vehicle</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Manual_Vehicle</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Manual_Vehicle</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Manual_Vehicle</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
    </tr>
    <tr>
      <th>1200</th>
      <td>Manual_Vehicle</td>
    </tr>
    <tr>
      <th>1201</th>
      <td>Manual_Vehicle</td>
    </tr>
    <tr>
      <th>1202</th>
      <td>Manual_Vehicle</td>
    </tr>
    <tr>
      <th>1203</th>
      <td>Manual_Vehicle</td>
    </tr>
    <tr>
      <th>1204</th>
      <td>Manual_Vehicle</td>
    </tr>
  </tbody>
</table>
<p>1205 rows × 1 columns</p>
</div>




```python
auction_results['Transmission'] = 'Container_Like'

auction_results['Transmission'].to_frame()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Transmission</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Container_Like</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Container_Like</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Container_Like</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Container_Like</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Container_Like</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
    </tr>
    <tr>
      <th>1200</th>
      <td>Container_Like</td>
    </tr>
    <tr>
      <th>1201</th>
      <td>Container_Like</td>
    </tr>
    <tr>
      <th>1202</th>
      <td>Container_Like</td>
    </tr>
    <tr>
      <th>1203</th>
      <td>Container_Like</td>
    </tr>
    <tr>
      <th>1204</th>
      <td>Container_Like</td>
    </tr>
  </tbody>
</table>
<p>1205 rows × 1 columns</p>
</div>




```python
# checking for isna values in the mileage column
auction_results['Mileage'].isna().values.any()
```




    True




```python
auction_results.loc[auction_results['Mileage'].isna()]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Unnamed: 0</th>
      <th>URL</th>
      <th>Reference Number</th>
      <th>Price</th>
      <th>Car Title</th>
      <th>Condition</th>
      <th>VIN</th>
      <th>Transmission</th>
      <th>Mileage</th>
      <th>Fuel Type</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>253</th>
      <td>253</td>
      <td>Container</td>
      <td>NCS/TCIP/OVT/03/2024/1</td>
      <td>₦25,000,000.00</td>
      <td>DFSU6276690</td>
      <td>Cont23456</td>
      <td>Used_Items_In_Container</td>
      <td>Container_Like</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>254</th>
      <td>254</td>
      <td>Container</td>
      <td>NCS/TCIP/OVT/03/2024/2</td>
      <td>₦19,000,500.00</td>
      <td>CSNU6062890</td>
      <td>Cont23456</td>
      <td>Used_Items_In_Container</td>
      <td>Container_Like</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>255</th>
      <td>255</td>
      <td>Container</td>
      <td>NCS/TCIP/OVT/03/2024/3</td>
      <td>₦9,000,000.00</td>
      <td>CBHU8708359</td>
      <td>Cont23456</td>
      <td>Used_Items_In_Container</td>
      <td>Container_Like</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>256</th>
      <td>256</td>
      <td>Container</td>
      <td>NCS/TCIP/OVT/03/2024/4</td>
      <td>₦8,700,000.00</td>
      <td>CSNU6999438</td>
      <td>Cont23456</td>
      <td>Used_Items_In_Container</td>
      <td>Container_Like</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>257</th>
      <td>257</td>
      <td>Container</td>
      <td>NCS/TCIP/OVT/03/2024/5</td>
      <td>₦29,000,000.00</td>
      <td>CBHU7069227</td>
      <td>Cont23456</td>
      <td>Used_Items_In_Container</td>
      <td>Container_Like</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>710</th>
      <td>710</td>
      <td>Container</td>
      <td>NCS/PTML/OVT/03/2024/109</td>
      <td>₦1,999,766.00</td>
      <td>CSNU6979220</td>
      <td>Cont23456</td>
      <td>Used_Items_In_Container</td>
      <td>Container_Like</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>711</th>
      <td>711</td>
      <td>Container</td>
      <td>NCS/PTML/OVT/03/2024/110</td>
      <td>₦1,700,000.00</td>
      <td>PCIU0169958</td>
      <td>Cont23456</td>
      <td>Used_Items_In_Container</td>
      <td>Container_Like</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>712</th>
      <td>712</td>
      <td>Container</td>
      <td>NCS/PTML/OVT/03/2024/111</td>
      <td>₦4,511,100.00</td>
      <td>ACLU9779415</td>
      <td>Cont23456</td>
      <td>Used_Items_In_Container</td>
      <td>Container_Like</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>713</th>
      <td>713</td>
      <td>Container</td>
      <td>NCS/PTML/OVT/03/2024/112</td>
      <td>₦3,677,777.00</td>
      <td>GCNU1220147</td>
      <td>Cont23456</td>
      <td>Used_Items_In_Container</td>
      <td>Container_Like</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>714</th>
      <td>714</td>
      <td>Container</td>
      <td>NCS/PTML/OVT/03/2024/113</td>
      <td>₦4,500,000.00</td>
      <td>ACLU9699006</td>
      <td>Cont23456</td>
      <td>Used_Items_In_Container</td>
      <td>Container_Like</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
  </tbody>
</table>
<p>81 rows × 10 columns</p>
</div>




```python
# Give the values in the Mileage Column some meaning

auction_results['Mileage'].replace({'0.00KM': 'Kilometers'}, inplace=True)

auction_results
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Unnamed: 0</th>
      <th>URL</th>
      <th>Reference Number</th>
      <th>Price</th>
      <th>Car Title</th>
      <th>Condition</th>
      <th>VIN</th>
      <th>Transmission</th>
      <th>Mileage</th>
      <th>Fuel Type</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0</td>
      <td>Vehicle</td>
      <td>NCS/PTML/OVT/01/24/1</td>
      <td>₦892,000.00</td>
      <td>TOYOTA CAMRY HYBRID LE 4DR SEDAN 2006</td>
      <td>Cont23456</td>
      <td>Used_Items_In_Container</td>
      <td>Container_Like</td>
      <td>Kilometers</td>
      <td>Petrol</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1</td>
      <td>Vehicle</td>
      <td>NCS/PTML/OVT/01/24/2</td>
      <td>₦500,000.00</td>
      <td>ACURA TL 2004</td>
      <td>Cont23456</td>
      <td>Used_Items_In_Container</td>
      <td>Container_Like</td>
      <td>Kilometers</td>
      <td>Petrol</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2</td>
      <td>Vehicle</td>
      <td>NCS/PTML/OVT/01/24/3</td>
      <td>₦420,000.00</td>
      <td>HONDA ACCORD EX 1.5T 4DR SEDAN 2004</td>
      <td>Cont23456</td>
      <td>Used_Items_In_Container</td>
      <td>Container_Like</td>
      <td>Kilometers</td>
      <td>Petrol</td>
    </tr>
    <tr>
      <th>3</th>
      <td>3</td>
      <td>Vehicle</td>
      <td>NCS/PTML/OVT/01/24/4</td>
      <td>₦800,000.00</td>
      <td>TOYOTA COROLLA L 4DR SEDAN 2007</td>
      <td>Cont23456</td>
      <td>Used_Items_In_Container</td>
      <td>Container_Like</td>
      <td>Kilometers</td>
      <td>Petrol</td>
    </tr>
    <tr>
      <th>4</th>
      <td>4</td>
      <td>Vehicle</td>
      <td>NCS/PTML/OVT/01/24/5</td>
      <td>₦715,000.00</td>
      <td>PEUGEOT 307 2008</td>
      <td>Cont23456</td>
      <td>Used_Items_In_Container</td>
      <td>Container_Like</td>
      <td>Kilometers</td>
      <td>Petrol</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>1200</th>
      <td>1200</td>
      <td>Vehicle</td>
      <td>NCS/TCIP/OVT/08/2024/1178</td>
      <td>₦648,000.00</td>
      <td>FORD  FREESTAR 2004</td>
      <td>Cont23456</td>
      <td>Used_Items_In_Container</td>
      <td>Container_Like</td>
      <td>Kilometers</td>
      <td>Petrol</td>
    </tr>
    <tr>
      <th>1201</th>
      <td>1201</td>
      <td>Vehicle</td>
      <td>NCS/TCIP/OVT/08/2024/1179</td>
      <td>₦1,200,000.00</td>
      <td>TOYOTA  HIGHLANDER 2012</td>
      <td>Cont23456</td>
      <td>Used_Items_In_Container</td>
      <td>Container_Like</td>
      <td>Kilometers</td>
      <td>Petrol</td>
    </tr>
    <tr>
      <th>1202</th>
      <td>1202</td>
      <td>Vehicle</td>
      <td>NCS/TCIP/OVT/08/2024/1180</td>
      <td>₦1,626,898.00</td>
      <td>HONDA  CROSSTOUR 2014</td>
      <td>Cont23456</td>
      <td>Used_Items_In_Container</td>
      <td>Container_Like</td>
      <td>Kilometers</td>
      <td>Petrol</td>
    </tr>
    <tr>
      <th>1203</th>
      <td>1203</td>
      <td>Vehicle</td>
      <td>NCS/TCIP/OVT/08/2024/1181</td>
      <td>₦533,333.00</td>
      <td>HYUNDAI  SANTA FE 2004</td>
      <td>Cont23456</td>
      <td>Used_Items_In_Container</td>
      <td>Container_Like</td>
      <td>Kilometers</td>
      <td>Petrol</td>
    </tr>
    <tr>
      <th>1204</th>
      <td>1204</td>
      <td>Vehicle</td>
      <td>NCS/TCIP/OVT/08/2024/1182</td>
      <td>₦520,000.00</td>
      <td>TOYOTA CAMRY 1996</td>
      <td>Cont23456</td>
      <td>Used_Items_In_Container</td>
      <td>Container_Like</td>
      <td>Kilometers</td>
      <td>Petrol</td>
    </tr>
  </tbody>
</table>
<p>1205 rows × 10 columns</p>
</div>




```python
# Replacing NaN values
auction_results['Mileage'] = auction_results['Mileage'].fillna('None').replace('NaN', 'None')

auction_results
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Unnamed: 0</th>
      <th>URL</th>
      <th>Reference Number</th>
      <th>Price</th>
      <th>Car Title</th>
      <th>Condition</th>
      <th>VIN</th>
      <th>Transmission</th>
      <th>Mileage</th>
      <th>Fuel Type</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0</td>
      <td>Vehicle</td>
      <td>NCS/PTML/OVT/01/24/1</td>
      <td>₦892,000.00</td>
      <td>TOYOTA CAMRY HYBRID LE 4DR SEDAN 2006</td>
      <td>Cont23456</td>
      <td>Used_Items_In_Container</td>
      <td>Container_Like</td>
      <td>Kilometers</td>
      <td>Petrol</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1</td>
      <td>Vehicle</td>
      <td>NCS/PTML/OVT/01/24/2</td>
      <td>₦500,000.00</td>
      <td>ACURA TL 2004</td>
      <td>Cont23456</td>
      <td>Used_Items_In_Container</td>
      <td>Container_Like</td>
      <td>Kilometers</td>
      <td>Petrol</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2</td>
      <td>Vehicle</td>
      <td>NCS/PTML/OVT/01/24/3</td>
      <td>₦420,000.00</td>
      <td>HONDA ACCORD EX 1.5T 4DR SEDAN 2004</td>
      <td>Cont23456</td>
      <td>Used_Items_In_Container</td>
      <td>Container_Like</td>
      <td>Kilometers</td>
      <td>Petrol</td>
    </tr>
    <tr>
      <th>3</th>
      <td>3</td>
      <td>Vehicle</td>
      <td>NCS/PTML/OVT/01/24/4</td>
      <td>₦800,000.00</td>
      <td>TOYOTA COROLLA L 4DR SEDAN 2007</td>
      <td>Cont23456</td>
      <td>Used_Items_In_Container</td>
      <td>Container_Like</td>
      <td>Kilometers</td>
      <td>Petrol</td>
    </tr>
    <tr>
      <th>4</th>
      <td>4</td>
      <td>Vehicle</td>
      <td>NCS/PTML/OVT/01/24/5</td>
      <td>₦715,000.00</td>
      <td>PEUGEOT 307 2008</td>
      <td>Cont23456</td>
      <td>Used_Items_In_Container</td>
      <td>Container_Like</td>
      <td>Kilometers</td>
      <td>Petrol</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>1200</th>
      <td>1200</td>
      <td>Vehicle</td>
      <td>NCS/TCIP/OVT/08/2024/1178</td>
      <td>₦648,000.00</td>
      <td>FORD  FREESTAR 2004</td>
      <td>Cont23456</td>
      <td>Used_Items_In_Container</td>
      <td>Container_Like</td>
      <td>Kilometers</td>
      <td>Petrol</td>
    </tr>
    <tr>
      <th>1201</th>
      <td>1201</td>
      <td>Vehicle</td>
      <td>NCS/TCIP/OVT/08/2024/1179</td>
      <td>₦1,200,000.00</td>
      <td>TOYOTA  HIGHLANDER 2012</td>
      <td>Cont23456</td>
      <td>Used_Items_In_Container</td>
      <td>Container_Like</td>
      <td>Kilometers</td>
      <td>Petrol</td>
    </tr>
    <tr>
      <th>1202</th>
      <td>1202</td>
      <td>Vehicle</td>
      <td>NCS/TCIP/OVT/08/2024/1180</td>
      <td>₦1,626,898.00</td>
      <td>HONDA  CROSSTOUR 2014</td>
      <td>Cont23456</td>
      <td>Used_Items_In_Container</td>
      <td>Container_Like</td>
      <td>Kilometers</td>
      <td>Petrol</td>
    </tr>
    <tr>
      <th>1203</th>
      <td>1203</td>
      <td>Vehicle</td>
      <td>NCS/TCIP/OVT/08/2024/1181</td>
      <td>₦533,333.00</td>
      <td>HYUNDAI  SANTA FE 2004</td>
      <td>Cont23456</td>
      <td>Used_Items_In_Container</td>
      <td>Container_Like</td>
      <td>Kilometers</td>
      <td>Petrol</td>
    </tr>
    <tr>
      <th>1204</th>
      <td>1204</td>
      <td>Vehicle</td>
      <td>NCS/TCIP/OVT/08/2024/1182</td>
      <td>₦520,000.00</td>
      <td>TOYOTA CAMRY 1996</td>
      <td>Cont23456</td>
      <td>Used_Items_In_Container</td>
      <td>Container_Like</td>
      <td>Kilometers</td>
      <td>Petrol</td>
    </tr>
  </tbody>
</table>
<p>1205 rows × 10 columns</p>
</div>




```python
auction_results.loc[auction_results['Mileage'].isna()]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Unnamed: 0</th>
      <th>URL</th>
      <th>Reference Number</th>
      <th>Price</th>
      <th>Car Title</th>
      <th>Condition</th>
      <th>VIN</th>
      <th>Transmission</th>
      <th>Mileage</th>
      <th>Fuel Type</th>
    </tr>
  </thead>
  <tbody>
  </tbody>
</table>
</div>




```python
auction_results['Mileage'].to_frame()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Mileage</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Kilometers</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Kilometers</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Kilometers</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Kilometers</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Kilometers</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
    </tr>
    <tr>
      <th>1200</th>
      <td>Kilometers</td>
    </tr>
    <tr>
      <th>1201</th>
      <td>Kilometers</td>
    </tr>
    <tr>
      <th>1202</th>
      <td>Kilometers</td>
    </tr>
    <tr>
      <th>1203</th>
      <td>Kilometers</td>
    </tr>
    <tr>
      <th>1204</th>
      <td>Kilometers</td>
    </tr>
  </tbody>
</table>
<p>1205 rows × 1 columns</p>
</div>




```python
auction_results['Mileage'] = 'None'

auction_results['Mileage'].to_frame()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Mileage</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>None</td>
    </tr>
    <tr>
      <th>1</th>
      <td>None</td>
    </tr>
    <tr>
      <th>2</th>
      <td>None</td>
    </tr>
    <tr>
      <th>3</th>
      <td>None</td>
    </tr>
    <tr>
      <th>4</th>
      <td>None</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
    </tr>
    <tr>
      <th>1200</th>
      <td>None</td>
    </tr>
    <tr>
      <th>1201</th>
      <td>None</td>
    </tr>
    <tr>
      <th>1202</th>
      <td>None</td>
    </tr>
    <tr>
      <th>1203</th>
      <td>None</td>
    </tr>
    <tr>
      <th>1204</th>
      <td>None</td>
    </tr>
  </tbody>
</table>
<p>1205 rows × 1 columns</p>
</div>




```python
# checking if there are NaN values in the fuel type column
auction_results.loc[auction_results['Fuel Type'].isna()]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Unnamed: 0</th>
      <th>URL</th>
      <th>Reference Number</th>
      <th>Price</th>
      <th>Car Title</th>
      <th>Condition</th>
      <th>VIN</th>
      <th>Transmission</th>
      <th>Mileage</th>
      <th>Fuel Type</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>14</th>
      <td>14</td>
      <td>Vehicle</td>
      <td>NCS/PTML/OVT/01/24/18</td>
      <td>₦550,000.00</td>
      <td>MERCEDES-BENZ C240 2005</td>
      <td>Cont23456</td>
      <td>Used_Items_In_Container</td>
      <td>Container_Like</td>
      <td>None</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>18</th>
      <td>18</td>
      <td>Vehicle</td>
      <td>NCS/PTML/OVT/01/24/22</td>
      <td>₦1,800,000.00</td>
      <td>TOYOTA YARIS SEDAN L 4DR SEDAN 2007</td>
      <td>Cont23456</td>
      <td>Used_Items_In_Container</td>
      <td>Container_Like</td>
      <td>None</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>20</th>
      <td>20</td>
      <td>Vehicle</td>
      <td>NCS/PTML/OVT/01/24/25</td>
      <td>₦425,000.00</td>
      <td>MERCEDES-BENZ C180 2002</td>
      <td>Cont23456</td>
      <td>Used_Items_In_Container</td>
      <td>Container_Like</td>
      <td>None</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>46</th>
      <td>46</td>
      <td>Vehicle</td>
      <td>NCS/PTML/OVT/01/24/55</td>
      <td>₦660,000.00</td>
      <td>MERCEDES-BENZ C200 2002</td>
      <td>Cont23456</td>
      <td>Used_Items_In_Container</td>
      <td>Container_Like</td>
      <td>None</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>55</th>
      <td>55</td>
      <td>Vehicle</td>
      <td>NCS/PTML/OVT/01/24/66</td>
      <td>₦430,000.00</td>
      <td>MERCEDES-BENZ C180 2006</td>
      <td>Cont23456</td>
      <td>Used_Items_In_Container</td>
      <td>Container_Like</td>
      <td>None</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>710</th>
      <td>710</td>
      <td>Container</td>
      <td>NCS/PTML/OVT/03/2024/109</td>
      <td>₦1,999,766.00</td>
      <td>CSNU6979220</td>
      <td>Cont23456</td>
      <td>Used_Items_In_Container</td>
      <td>Container_Like</td>
      <td>None</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>711</th>
      <td>711</td>
      <td>Container</td>
      <td>NCS/PTML/OVT/03/2024/110</td>
      <td>₦1,700,000.00</td>
      <td>PCIU0169958</td>
      <td>Cont23456</td>
      <td>Used_Items_In_Container</td>
      <td>Container_Like</td>
      <td>None</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>712</th>
      <td>712</td>
      <td>Container</td>
      <td>NCS/PTML/OVT/03/2024/111</td>
      <td>₦4,511,100.00</td>
      <td>ACLU9779415</td>
      <td>Cont23456</td>
      <td>Used_Items_In_Container</td>
      <td>Container_Like</td>
      <td>None</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>713</th>
      <td>713</td>
      <td>Container</td>
      <td>NCS/PTML/OVT/03/2024/112</td>
      <td>₦3,677,777.00</td>
      <td>GCNU1220147</td>
      <td>Cont23456</td>
      <td>Used_Items_In_Container</td>
      <td>Container_Like</td>
      <td>None</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>714</th>
      <td>714</td>
      <td>Container</td>
      <td>NCS/PTML/OVT/03/2024/113</td>
      <td>₦4,500,000.00</td>
      <td>ACLU9699006</td>
      <td>Cont23456</td>
      <td>Used_Items_In_Container</td>
      <td>Container_Like</td>
      <td>None</td>
      <td>NaN</td>
    </tr>
  </tbody>
</table>
<p>87 rows × 10 columns</p>
</div>




```python
# Give the values in the Fuel Type Column some meaning
auction_results['Fuel Type'].replace({ 'Petrol': 'Petrol_Vehicle', 'PETROL': 'Petrol_Vehicle', 'NIL': 'Petrol_Vehicle'},
                                     inplace=True)
auction_results
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Unnamed: 0</th>
      <th>URL</th>
      <th>Reference Number</th>
      <th>Price</th>
      <th>Car Title</th>
      <th>Condition</th>
      <th>VIN</th>
      <th>Transmission</th>
      <th>Mileage</th>
      <th>Fuel Type</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0</td>
      <td>Vehicle</td>
      <td>NCS/PTML/OVT/01/24/1</td>
      <td>₦892,000.00</td>
      <td>TOYOTA CAMRY HYBRID LE 4DR SEDAN 2006</td>
      <td>Cont23456</td>
      <td>Used_Items_In_Container</td>
      <td>Container_Like</td>
      <td>None</td>
      <td>Petrol_Vehicle</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1</td>
      <td>Vehicle</td>
      <td>NCS/PTML/OVT/01/24/2</td>
      <td>₦500,000.00</td>
      <td>ACURA TL 2004</td>
      <td>Cont23456</td>
      <td>Used_Items_In_Container</td>
      <td>Container_Like</td>
      <td>None</td>
      <td>Petrol_Vehicle</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2</td>
      <td>Vehicle</td>
      <td>NCS/PTML/OVT/01/24/3</td>
      <td>₦420,000.00</td>
      <td>HONDA ACCORD EX 1.5T 4DR SEDAN 2004</td>
      <td>Cont23456</td>
      <td>Used_Items_In_Container</td>
      <td>Container_Like</td>
      <td>None</td>
      <td>Petrol_Vehicle</td>
    </tr>
    <tr>
      <th>3</th>
      <td>3</td>
      <td>Vehicle</td>
      <td>NCS/PTML/OVT/01/24/4</td>
      <td>₦800,000.00</td>
      <td>TOYOTA COROLLA L 4DR SEDAN 2007</td>
      <td>Cont23456</td>
      <td>Used_Items_In_Container</td>
      <td>Container_Like</td>
      <td>None</td>
      <td>Petrol_Vehicle</td>
    </tr>
    <tr>
      <th>4</th>
      <td>4</td>
      <td>Vehicle</td>
      <td>NCS/PTML/OVT/01/24/5</td>
      <td>₦715,000.00</td>
      <td>PEUGEOT 307 2008</td>
      <td>Cont23456</td>
      <td>Used_Items_In_Container</td>
      <td>Container_Like</td>
      <td>None</td>
      <td>Petrol_Vehicle</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>1200</th>
      <td>1200</td>
      <td>Vehicle</td>
      <td>NCS/TCIP/OVT/08/2024/1178</td>
      <td>₦648,000.00</td>
      <td>FORD  FREESTAR 2004</td>
      <td>Cont23456</td>
      <td>Used_Items_In_Container</td>
      <td>Container_Like</td>
      <td>None</td>
      <td>Petrol_Vehicle</td>
    </tr>
    <tr>
      <th>1201</th>
      <td>1201</td>
      <td>Vehicle</td>
      <td>NCS/TCIP/OVT/08/2024/1179</td>
      <td>₦1,200,000.00</td>
      <td>TOYOTA  HIGHLANDER 2012</td>
      <td>Cont23456</td>
      <td>Used_Items_In_Container</td>
      <td>Container_Like</td>
      <td>None</td>
      <td>Petrol_Vehicle</td>
    </tr>
    <tr>
      <th>1202</th>
      <td>1202</td>
      <td>Vehicle</td>
      <td>NCS/TCIP/OVT/08/2024/1180</td>
      <td>₦1,626,898.00</td>
      <td>HONDA  CROSSTOUR 2014</td>
      <td>Cont23456</td>
      <td>Used_Items_In_Container</td>
      <td>Container_Like</td>
      <td>None</td>
      <td>Petrol_Vehicle</td>
    </tr>
    <tr>
      <th>1203</th>
      <td>1203</td>
      <td>Vehicle</td>
      <td>NCS/TCIP/OVT/08/2024/1181</td>
      <td>₦533,333.00</td>
      <td>HYUNDAI  SANTA FE 2004</td>
      <td>Cont23456</td>
      <td>Used_Items_In_Container</td>
      <td>Container_Like</td>
      <td>None</td>
      <td>Petrol_Vehicle</td>
    </tr>
    <tr>
      <th>1204</th>
      <td>1204</td>
      <td>Vehicle</td>
      <td>NCS/TCIP/OVT/08/2024/1182</td>
      <td>₦520,000.00</td>
      <td>TOYOTA CAMRY 1996</td>
      <td>Cont23456</td>
      <td>Used_Items_In_Container</td>
      <td>Container_Like</td>
      <td>None</td>
      <td>Petrol_Vehicle</td>
    </tr>
  </tbody>
</table>
<p>1205 rows × 10 columns</p>
</div>




```python
# Used indexing starting from 0 to fill blanks at specified rows

auction_results.at[14, 'Fuel Type']= 'Diesel_Vehicle'
auction_results.at[18, 'Fuel Type']= 'Diesel_Vehicle'
auction_results.at[20, 'Fuel Type']= 'Diesel_Vehicle'
auction_results.at[46, 'Fuel Type']= 'Diesel_Vehicle'
auction_results.at[55, 'Fuel Type']= 'Diesel_Vehicle'
auction_results.at[71, 'Fuel Type']= 'Diesel_Vehicle'


auction_results
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Bidding_Item</th>
      <th>Reference_Number</th>
      <th>Bid_Winning_Price</th>
      <th>Bidding_Item_Title</th>
      <th>Bid_Item_Identification_Number</th>
      <th>Condition</th>
      <th>Transmission_Type</th>
      <th>Mileage</th>
      <th>Fuel_Type</th>
      <th>Fuel Type</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Vehicle</td>
      <td>NCS/PTML/OVT/01/24/1</td>
      <td>892000.0</td>
      <td>TOYOTA CAMRY HYBRID LE 4DR SEDAN 2006</td>
      <td>4T1BE32K86U111063</td>
      <td>Used_Vehicle</td>
      <td>Automatic_Vehicle</td>
      <td>Kilometers</td>
      <td>Petrol_Vehicle</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Vehicle</td>
      <td>NCS/PTML/OVT/01/24/2</td>
      <td>500000.0</td>
      <td>ACURA TL 2004</td>
      <td>19UUA66214A013030</td>
      <td>Used_Vehicle</td>
      <td>Automatic_Vehicle</td>
      <td>Kilometers</td>
      <td>Petrol_Vehicle</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Vehicle</td>
      <td>NCS/PTML/OVT/01/24/3</td>
      <td>420000.0</td>
      <td>HONDA ACCORD EX 1.5T 4DR SEDAN 2004</td>
      <td>1HGCM66554A098192</td>
      <td>Used_Vehicle</td>
      <td>Automatic_Vehicle</td>
      <td>Kilometers</td>
      <td>Petrol_Vehicle</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Vehicle</td>
      <td>NCS/PTML/OVT/01/24/4</td>
      <td>800000.0</td>
      <td>TOYOTA COROLLA L 4DR SEDAN 2007</td>
      <td>2T1BR32E27C777272</td>
      <td>Used_Vehicle</td>
      <td>Automatic_Vehicle</td>
      <td>Kilometers</td>
      <td>Petrol_Vehicle</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Vehicle</td>
      <td>NCS/PTML/OVT/01/24/5</td>
      <td>715000.0</td>
      <td>PEUGEOT 307 2008</td>
      <td>VF33CNFUL84568049</td>
      <td>Used_Vehicle</td>
      <td>Automatic_Vehicle</td>
      <td>Kilometers</td>
      <td>Petrol_Vehicle</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>1200</th>
      <td>Vehicle</td>
      <td>NCS/TCIP/OVT/08/2024/1178</td>
      <td>648000.0</td>
      <td>FORD  FREESTAR 2004</td>
      <td>B29970</td>
      <td>Used_Vehicle</td>
      <td>Automatic_Vehicle</td>
      <td>Kilometers</td>
      <td>Petrol_Vehicle</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>1201</th>
      <td>Vehicle</td>
      <td>NCS/TCIP/OVT/08/2024/1179</td>
      <td>1200000.0</td>
      <td>TOYOTA  HIGHLANDER 2012</td>
      <td>5TDYK3EH5CS070513</td>
      <td>Used_Vehicle</td>
      <td>Automatic_Vehicle</td>
      <td>Kilometers</td>
      <td>Petrol_Vehicle</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>1202</th>
      <td>Vehicle</td>
      <td>NCS/TCIP/OVT/08/2024/1180</td>
      <td>1626898.0</td>
      <td>HONDA  CROSSTOUR 2014</td>
      <td>000016</td>
      <td>Used_Vehicle</td>
      <td>Automatic_Vehicle</td>
      <td>Kilometers</td>
      <td>Petrol_Vehicle</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>1203</th>
      <td>Vehicle</td>
      <td>NCS/TCIP/OVT/08/2024/1181</td>
      <td>533333.0</td>
      <td>HYUNDAI  SANTA FE 2004</td>
      <td>U572121</td>
      <td>Used_Vehicle</td>
      <td>Automatic_Vehicle</td>
      <td>Kilometers</td>
      <td>Petrol_Vehicle</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>1204</th>
      <td>Vehicle</td>
      <td>NCS/TCIP/OVT/08/2024/1182</td>
      <td>520000.0</td>
      <td>TOYOTA CAMRY 1996</td>
      <td>824426</td>
      <td>Used_Vehicle</td>
      <td>Automatic_Vehicle</td>
      <td>Kilometers</td>
      <td>Petrol_Vehicle</td>
      <td>NaN</td>
    </tr>
  </tbody>
</table>
<p>1205 rows × 10 columns</p>
</div>




```python
# Replacing NaN values
auction_results['Fuel Type'] = auction_results['Fuel Type'].fillna('None').replace('NaN', 'None')

auction_results
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Unnamed: 0</th>
      <th>URL</th>
      <th>Reference Number</th>
      <th>Price</th>
      <th>Car Title</th>
      <th>Condition</th>
      <th>VIN</th>
      <th>Transmission</th>
      <th>Mileage</th>
      <th>Fuel Type</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0</td>
      <td>Vehicle</td>
      <td>NCS/PTML/OVT/01/24/1</td>
      <td>₦892,000.00</td>
      <td>TOYOTA CAMRY HYBRID LE 4DR SEDAN 2006</td>
      <td>Cont23456</td>
      <td>Used_Items_In_Container</td>
      <td>Container_Like</td>
      <td>None</td>
      <td>Petrol_Vehicle</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1</td>
      <td>Vehicle</td>
      <td>NCS/PTML/OVT/01/24/2</td>
      <td>₦500,000.00</td>
      <td>ACURA TL 2004</td>
      <td>Cont23456</td>
      <td>Used_Items_In_Container</td>
      <td>Container_Like</td>
      <td>None</td>
      <td>Petrol_Vehicle</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2</td>
      <td>Vehicle</td>
      <td>NCS/PTML/OVT/01/24/3</td>
      <td>₦420,000.00</td>
      <td>HONDA ACCORD EX 1.5T 4DR SEDAN 2004</td>
      <td>Cont23456</td>
      <td>Used_Items_In_Container</td>
      <td>Container_Like</td>
      <td>None</td>
      <td>Petrol_Vehicle</td>
    </tr>
    <tr>
      <th>3</th>
      <td>3</td>
      <td>Vehicle</td>
      <td>NCS/PTML/OVT/01/24/4</td>
      <td>₦800,000.00</td>
      <td>TOYOTA COROLLA L 4DR SEDAN 2007</td>
      <td>Cont23456</td>
      <td>Used_Items_In_Container</td>
      <td>Container_Like</td>
      <td>None</td>
      <td>Petrol_Vehicle</td>
    </tr>
    <tr>
      <th>4</th>
      <td>4</td>
      <td>Vehicle</td>
      <td>NCS/PTML/OVT/01/24/5</td>
      <td>₦715,000.00</td>
      <td>PEUGEOT 307 2008</td>
      <td>Cont23456</td>
      <td>Used_Items_In_Container</td>
      <td>Container_Like</td>
      <td>None</td>
      <td>Petrol_Vehicle</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>1200</th>
      <td>1200</td>
      <td>Vehicle</td>
      <td>NCS/TCIP/OVT/08/2024/1178</td>
      <td>₦648,000.00</td>
      <td>FORD  FREESTAR 2004</td>
      <td>Cont23456</td>
      <td>Used_Items_In_Container</td>
      <td>Container_Like</td>
      <td>None</td>
      <td>Petrol_Vehicle</td>
    </tr>
    <tr>
      <th>1201</th>
      <td>1201</td>
      <td>Vehicle</td>
      <td>NCS/TCIP/OVT/08/2024/1179</td>
      <td>₦1,200,000.00</td>
      <td>TOYOTA  HIGHLANDER 2012</td>
      <td>Cont23456</td>
      <td>Used_Items_In_Container</td>
      <td>Container_Like</td>
      <td>None</td>
      <td>Petrol_Vehicle</td>
    </tr>
    <tr>
      <th>1202</th>
      <td>1202</td>
      <td>Vehicle</td>
      <td>NCS/TCIP/OVT/08/2024/1180</td>
      <td>₦1,626,898.00</td>
      <td>HONDA  CROSSTOUR 2014</td>
      <td>Cont23456</td>
      <td>Used_Items_In_Container</td>
      <td>Container_Like</td>
      <td>None</td>
      <td>Petrol_Vehicle</td>
    </tr>
    <tr>
      <th>1203</th>
      <td>1203</td>
      <td>Vehicle</td>
      <td>NCS/TCIP/OVT/08/2024/1181</td>
      <td>₦533,333.00</td>
      <td>HYUNDAI  SANTA FE 2004</td>
      <td>Cont23456</td>
      <td>Used_Items_In_Container</td>
      <td>Container_Like</td>
      <td>None</td>
      <td>Petrol_Vehicle</td>
    </tr>
    <tr>
      <th>1204</th>
      <td>1204</td>
      <td>Vehicle</td>
      <td>NCS/TCIP/OVT/08/2024/1182</td>
      <td>₦520,000.00</td>
      <td>TOYOTA CAMRY 1996</td>
      <td>Cont23456</td>
      <td>Used_Items_In_Container</td>
      <td>Container_Like</td>
      <td>None</td>
      <td>Petrol_Vehicle</td>
    </tr>
  </tbody>
</table>
<p>1205 rows × 10 columns</p>
</div>




```python
auction_results.loc[auction_results['Fuel Type'].isna()]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Unnamed: 0</th>
      <th>URL</th>
      <th>Reference Number</th>
      <th>Price</th>
      <th>Car Title</th>
      <th>Condition</th>
      <th>VIN</th>
      <th>Transmission</th>
      <th>Mileage</th>
      <th>Fuel Type</th>
    </tr>
  </thead>
  <tbody>
  </tbody>
</table>
</div>




```python
# Giving the values in the fuel type column some meaning
auction_results['Fuel Type'] = auction_results['Fuel Type'].replace(('Diesel_Vehicle',), 'Diesel_Vehicle', inplace=True)

auction_results
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Unnamed: 0</th>
      <th>URL</th>
      <th>Reference Number</th>
      <th>Price</th>
      <th>Car Title</th>
      <th>Condition</th>
      <th>VIN</th>
      <th>Transmission</th>
      <th>Mileage</th>
      <th>Fuel Type</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0</td>
      <td>Vehicle</td>
      <td>NCS/PTML/OVT/01/24/1</td>
      <td>₦892,000.00</td>
      <td>TOYOTA CAMRY HYBRID LE 4DR SEDAN 2006</td>
      <td>Cont23456</td>
      <td>Used_Items_In_Container</td>
      <td>Container_Like</td>
      <td>None</td>
      <td>None</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1</td>
      <td>Vehicle</td>
      <td>NCS/PTML/OVT/01/24/2</td>
      <td>₦500,000.00</td>
      <td>ACURA TL 2004</td>
      <td>Cont23456</td>
      <td>Used_Items_In_Container</td>
      <td>Container_Like</td>
      <td>None</td>
      <td>None</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2</td>
      <td>Vehicle</td>
      <td>NCS/PTML/OVT/01/24/3</td>
      <td>₦420,000.00</td>
      <td>HONDA ACCORD EX 1.5T 4DR SEDAN 2004</td>
      <td>Cont23456</td>
      <td>Used_Items_In_Container</td>
      <td>Container_Like</td>
      <td>None</td>
      <td>None</td>
    </tr>
    <tr>
      <th>3</th>
      <td>3</td>
      <td>Vehicle</td>
      <td>NCS/PTML/OVT/01/24/4</td>
      <td>₦800,000.00</td>
      <td>TOYOTA COROLLA L 4DR SEDAN 2007</td>
      <td>Cont23456</td>
      <td>Used_Items_In_Container</td>
      <td>Container_Like</td>
      <td>None</td>
      <td>None</td>
    </tr>
    <tr>
      <th>4</th>
      <td>4</td>
      <td>Vehicle</td>
      <td>NCS/PTML/OVT/01/24/5</td>
      <td>₦715,000.00</td>
      <td>PEUGEOT 307 2008</td>
      <td>Cont23456</td>
      <td>Used_Items_In_Container</td>
      <td>Container_Like</td>
      <td>None</td>
      <td>None</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>1200</th>
      <td>1200</td>
      <td>Vehicle</td>
      <td>NCS/TCIP/OVT/08/2024/1178</td>
      <td>₦648,000.00</td>
      <td>FORD  FREESTAR 2004</td>
      <td>Cont23456</td>
      <td>Used_Items_In_Container</td>
      <td>Container_Like</td>
      <td>None</td>
      <td>None</td>
    </tr>
    <tr>
      <th>1201</th>
      <td>1201</td>
      <td>Vehicle</td>
      <td>NCS/TCIP/OVT/08/2024/1179</td>
      <td>₦1,200,000.00</td>
      <td>TOYOTA  HIGHLANDER 2012</td>
      <td>Cont23456</td>
      <td>Used_Items_In_Container</td>
      <td>Container_Like</td>
      <td>None</td>
      <td>None</td>
    </tr>
    <tr>
      <th>1202</th>
      <td>1202</td>
      <td>Vehicle</td>
      <td>NCS/TCIP/OVT/08/2024/1180</td>
      <td>₦1,626,898.00</td>
      <td>HONDA  CROSSTOUR 2014</td>
      <td>Cont23456</td>
      <td>Used_Items_In_Container</td>
      <td>Container_Like</td>
      <td>None</td>
      <td>None</td>
    </tr>
    <tr>
      <th>1203</th>
      <td>1203</td>
      <td>Vehicle</td>
      <td>NCS/TCIP/OVT/08/2024/1181</td>
      <td>₦533,333.00</td>
      <td>HYUNDAI  SANTA FE 2004</td>
      <td>Cont23456</td>
      <td>Used_Items_In_Container</td>
      <td>Container_Like</td>
      <td>None</td>
      <td>None</td>
    </tr>
    <tr>
      <th>1204</th>
      <td>1204</td>
      <td>Vehicle</td>
      <td>NCS/TCIP/OVT/08/2024/1182</td>
      <td>₦520,000.00</td>
      <td>TOYOTA CAMRY 1996</td>
      <td>Cont23456</td>
      <td>Used_Items_In_Container</td>
      <td>Container_Like</td>
      <td>None</td>
      <td>None</td>
    </tr>
  </tbody>
</table>
<p>1205 rows × 10 columns</p>
</div>




```python
auction_results['Fuel Type'] = 'None'

auction_results['Fuel Type'].to_frame()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Fuel Type</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>None</td>
    </tr>
    <tr>
      <th>1</th>
      <td>None</td>
    </tr>
    <tr>
      <th>2</th>
      <td>None</td>
    </tr>
    <tr>
      <th>3</th>
      <td>None</td>
    </tr>
    <tr>
      <th>4</th>
      <td>None</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
    </tr>
    <tr>
      <th>1200</th>
      <td>None</td>
    </tr>
    <tr>
      <th>1201</th>
      <td>None</td>
    </tr>
    <tr>
      <th>1202</th>
      <td>None</td>
    </tr>
    <tr>
      <th>1203</th>
      <td>None</td>
    </tr>
    <tr>
      <th>1204</th>
      <td>None</td>
    </tr>
  </tbody>
</table>
<p>1205 rows × 1 columns</p>
</div>




```python
auction_results['Fuel Type'] = 'Diesel_Vehicle'

auction_results['Fuel Type'].to_frame()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Fuel Type</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Diesel_Vehicle</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Diesel_Vehicle</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Diesel_Vehicle</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Diesel_Vehicle</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Diesel_Vehicle</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
    </tr>
    <tr>
      <th>1200</th>
      <td>Diesel_Vehicle</td>
    </tr>
    <tr>
      <th>1201</th>
      <td>Diesel_Vehicle</td>
    </tr>
    <tr>
      <th>1202</th>
      <td>Diesel_Vehicle</td>
    </tr>
    <tr>
      <th>1203</th>
      <td>Diesel_Vehicle</td>
    </tr>
    <tr>
      <th>1204</th>
      <td>Diesel_Vehicle</td>
    </tr>
  </tbody>
</table>
<p>1205 rows × 1 columns</p>
</div>




```python
auction_results['Fuel Type'] = 'Petrol_Vehicle'

auction_results['Fuel Type'].to_frame()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Fuel Type</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Petrol_Vehicle</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Petrol_Vehicle</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Petrol_Vehicle</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Petrol_Vehicle</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Petrol_Vehicle</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
    </tr>
    <tr>
      <th>1200</th>
      <td>Petrol_Vehicle</td>
    </tr>
    <tr>
      <th>1201</th>
      <td>Petrol_Vehicle</td>
    </tr>
    <tr>
      <th>1202</th>
      <td>Petrol_Vehicle</td>
    </tr>
    <tr>
      <th>1203</th>
      <td>Petrol_Vehicle</td>
    </tr>
    <tr>
      <th>1204</th>
      <td>Petrol_Vehicle</td>
    </tr>
  </tbody>
</table>
<p>1205 rows × 1 columns</p>
</div>




```python
# Change the columnn names to make it corresepond to the column values changes made
auction_results.rename(columns={'URL':'Bidding_Item', 'Reference Number':'Reference_Number', 
                            'Price':'Bid_Winning_Price', 'Car Title':'Bidding_Item_Title',
                            'Condition':'Bid_Item_Identification_Number', 'VIN':'Condition',
                            'Transmission':'Transmission_Type', 'Fuel Type':'Fuel_Type'}, inplace=True)

auction_results
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Unnamed: 0</th>
      <th>Bidding_Item</th>
      <th>Reference_Number</th>
      <th>Bid_Winning_Price</th>
      <th>Bidding_Item_Title</th>
      <th>Bid_Item_Identification_Number</th>
      <th>Condition</th>
      <th>Transmission_Type</th>
      <th>Mileage</th>
      <th>Fuel_Type</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0</td>
      <td>Vehicle</td>
      <td>NCS/PTML/OVT/01/24/1</td>
      <td>₦892,000.00</td>
      <td>TOYOTA CAMRY HYBRID LE 4DR SEDAN 2006</td>
      <td>Cont23456</td>
      <td>Used_Items_In_Container</td>
      <td>Container_Like</td>
      <td>None</td>
      <td>Petrol_Vehicle</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1</td>
      <td>Vehicle</td>
      <td>NCS/PTML/OVT/01/24/2</td>
      <td>₦500,000.00</td>
      <td>ACURA TL 2004</td>
      <td>Cont23456</td>
      <td>Used_Items_In_Container</td>
      <td>Container_Like</td>
      <td>None</td>
      <td>Petrol_Vehicle</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2</td>
      <td>Vehicle</td>
      <td>NCS/PTML/OVT/01/24/3</td>
      <td>₦420,000.00</td>
      <td>HONDA ACCORD EX 1.5T 4DR SEDAN 2004</td>
      <td>Cont23456</td>
      <td>Used_Items_In_Container</td>
      <td>Container_Like</td>
      <td>None</td>
      <td>Petrol_Vehicle</td>
    </tr>
    <tr>
      <th>3</th>
      <td>3</td>
      <td>Vehicle</td>
      <td>NCS/PTML/OVT/01/24/4</td>
      <td>₦800,000.00</td>
      <td>TOYOTA COROLLA L 4DR SEDAN 2007</td>
      <td>Cont23456</td>
      <td>Used_Items_In_Container</td>
      <td>Container_Like</td>
      <td>None</td>
      <td>Petrol_Vehicle</td>
    </tr>
    <tr>
      <th>4</th>
      <td>4</td>
      <td>Vehicle</td>
      <td>NCS/PTML/OVT/01/24/5</td>
      <td>₦715,000.00</td>
      <td>PEUGEOT 307 2008</td>
      <td>Cont23456</td>
      <td>Used_Items_In_Container</td>
      <td>Container_Like</td>
      <td>None</td>
      <td>Petrol_Vehicle</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>1200</th>
      <td>1200</td>
      <td>Vehicle</td>
      <td>NCS/TCIP/OVT/08/2024/1178</td>
      <td>₦648,000.00</td>
      <td>FORD  FREESTAR 2004</td>
      <td>Cont23456</td>
      <td>Used_Items_In_Container</td>
      <td>Container_Like</td>
      <td>None</td>
      <td>Petrol_Vehicle</td>
    </tr>
    <tr>
      <th>1201</th>
      <td>1201</td>
      <td>Vehicle</td>
      <td>NCS/TCIP/OVT/08/2024/1179</td>
      <td>₦1,200,000.00</td>
      <td>TOYOTA  HIGHLANDER 2012</td>
      <td>Cont23456</td>
      <td>Used_Items_In_Container</td>
      <td>Container_Like</td>
      <td>None</td>
      <td>Petrol_Vehicle</td>
    </tr>
    <tr>
      <th>1202</th>
      <td>1202</td>
      <td>Vehicle</td>
      <td>NCS/TCIP/OVT/08/2024/1180</td>
      <td>₦1,626,898.00</td>
      <td>HONDA  CROSSTOUR 2014</td>
      <td>Cont23456</td>
      <td>Used_Items_In_Container</td>
      <td>Container_Like</td>
      <td>None</td>
      <td>Petrol_Vehicle</td>
    </tr>
    <tr>
      <th>1203</th>
      <td>1203</td>
      <td>Vehicle</td>
      <td>NCS/TCIP/OVT/08/2024/1181</td>
      <td>₦533,333.00</td>
      <td>HYUNDAI  SANTA FE 2004</td>
      <td>Cont23456</td>
      <td>Used_Items_In_Container</td>
      <td>Container_Like</td>
      <td>None</td>
      <td>Petrol_Vehicle</td>
    </tr>
    <tr>
      <th>1204</th>
      <td>1204</td>
      <td>Vehicle</td>
      <td>NCS/TCIP/OVT/08/2024/1182</td>
      <td>₦520,000.00</td>
      <td>TOYOTA CAMRY 1996</td>
      <td>Cont23456</td>
      <td>Used_Items_In_Container</td>
      <td>Container_Like</td>
      <td>None</td>
      <td>Petrol_Vehicle</td>
    </tr>
  </tbody>
</table>
<p>1205 rows × 10 columns</p>
</div>




```python
auction_results.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 1205 entries, 0 to 1204
    Data columns (total 10 columns):
     #   Column                          Non-Null Count  Dtype 
    ---  ------                          --------------  ----- 
     0   Unnamed: 0                      1205 non-null   int64 
     1   Bidding_Item                    1205 non-null   object
     2   Reference_Number                1205 non-null   object
     3   Bid_Winning_Price               1205 non-null   object
     4   Bidding_Item_Title              1205 non-null   object
     5   Bid_Item_Identification_Number  1205 non-null   object
     6   Condition                       1205 non-null   object
     7   Transmission_Type               1205 non-null   object
     8   Mileage                         1205 non-null   object
     9   Fuel_Type                       1205 non-null   object
    dtypes: int64(1), object(9)
    memory usage: 94.3+ KB
    


```python
auction_results.dtypes
```




    Unnamed: 0                         int64
    Bidding_Item                      object
    Reference_Number                  object
    Bid_Winning_Price                 object
    Bidding_Item_Title                object
    Bid_Item_Identification_Number    object
    Condition                         object
    Transmission_Type                 object
    Mileage                           object
    Fuel_Type                         object
    dtype: object




```python
# checked if the the reference number column have strictly unique rows
auction_results['Reference_Number'].value_counts()
```




    Reference_Number
    NCS/01TC/OVT/02/2024/522     2
    NCS/PTML/OVT/04/2024/856     2
    NCS/PTML/OVT/02/2024/363     2
    NCS/PTML/OVT/01/2024/258     2
    NCS/01TC/OVT/02/2024/442     2
                                ..
    NCS/PTML/OVT/01/2024/290     1
    NCS/PTML/OVT/01/2024/287     1
    NCS/PTML/OVT/01/2024/286     1
    NCS/PTML/OVT/01/2024/284     1
    NCS/TCIP/OVT/08/2024/1182    1
    Name: count, Length: 1198, dtype: int64




```python
auction_results['Reference_Number'].unique()
```




    array(['NCS/PTML/OVT/01/24/1', 'NCS/PTML/OVT/01/24/2',
           'NCS/PTML/OVT/01/24/3', ..., 'NCS/TCIP/OVT/08/2024/1180',
           'NCS/TCIP/OVT/08/2024/1181', 'NCS/TCIP/OVT/08/2024/1182'],
          dtype=object)




```python
# compare the number of unique values in the reference column to the length of the table
auction_results['Reference_Number'].nunique() == len(auction_results)
```




    False




```python
# Made the unnamed column an index
auction_results.index = auction_results['Unnamed: 0']
auction_results
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Unnamed: 0</th>
      <th>Bidding_Item</th>
      <th>Reference_Number</th>
      <th>Bid_Winning_Price</th>
      <th>Bidding_Item_Title</th>
      <th>Bid_Item_Identification_Number</th>
      <th>Condition</th>
      <th>Transmission_Type</th>
      <th>Mileage</th>
      <th>Fuel_Type</th>
    </tr>
    <tr>
      <th>Unnamed: 0</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0</td>
      <td>Vehicle</td>
      <td>NCS/PTML/OVT/01/24/1</td>
      <td>₦892,000.00</td>
      <td>TOYOTA CAMRY HYBRID LE 4DR SEDAN 2006</td>
      <td>Cont23456</td>
      <td>Used_Items_In_Container</td>
      <td>Container_Like</td>
      <td>None</td>
      <td>Petrol_Vehicle</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1</td>
      <td>Vehicle</td>
      <td>NCS/PTML/OVT/01/24/2</td>
      <td>₦500,000.00</td>
      <td>ACURA TL 2004</td>
      <td>Cont23456</td>
      <td>Used_Items_In_Container</td>
      <td>Container_Like</td>
      <td>None</td>
      <td>Petrol_Vehicle</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2</td>
      <td>Vehicle</td>
      <td>NCS/PTML/OVT/01/24/3</td>
      <td>₦420,000.00</td>
      <td>HONDA ACCORD EX 1.5T 4DR SEDAN 2004</td>
      <td>Cont23456</td>
      <td>Used_Items_In_Container</td>
      <td>Container_Like</td>
      <td>None</td>
      <td>Petrol_Vehicle</td>
    </tr>
    <tr>
      <th>3</th>
      <td>3</td>
      <td>Vehicle</td>
      <td>NCS/PTML/OVT/01/24/4</td>
      <td>₦800,000.00</td>
      <td>TOYOTA COROLLA L 4DR SEDAN 2007</td>
      <td>Cont23456</td>
      <td>Used_Items_In_Container</td>
      <td>Container_Like</td>
      <td>None</td>
      <td>Petrol_Vehicle</td>
    </tr>
    <tr>
      <th>4</th>
      <td>4</td>
      <td>Vehicle</td>
      <td>NCS/PTML/OVT/01/24/5</td>
      <td>₦715,000.00</td>
      <td>PEUGEOT 307 2008</td>
      <td>Cont23456</td>
      <td>Used_Items_In_Container</td>
      <td>Container_Like</td>
      <td>None</td>
      <td>Petrol_Vehicle</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>1200</th>
      <td>1200</td>
      <td>Vehicle</td>
      <td>NCS/TCIP/OVT/08/2024/1178</td>
      <td>₦648,000.00</td>
      <td>FORD  FREESTAR 2004</td>
      <td>Cont23456</td>
      <td>Used_Items_In_Container</td>
      <td>Container_Like</td>
      <td>None</td>
      <td>Petrol_Vehicle</td>
    </tr>
    <tr>
      <th>1201</th>
      <td>1201</td>
      <td>Vehicle</td>
      <td>NCS/TCIP/OVT/08/2024/1179</td>
      <td>₦1,200,000.00</td>
      <td>TOYOTA  HIGHLANDER 2012</td>
      <td>Cont23456</td>
      <td>Used_Items_In_Container</td>
      <td>Container_Like</td>
      <td>None</td>
      <td>Petrol_Vehicle</td>
    </tr>
    <tr>
      <th>1202</th>
      <td>1202</td>
      <td>Vehicle</td>
      <td>NCS/TCIP/OVT/08/2024/1180</td>
      <td>₦1,626,898.00</td>
      <td>HONDA  CROSSTOUR 2014</td>
      <td>Cont23456</td>
      <td>Used_Items_In_Container</td>
      <td>Container_Like</td>
      <td>None</td>
      <td>Petrol_Vehicle</td>
    </tr>
    <tr>
      <th>1203</th>
      <td>1203</td>
      <td>Vehicle</td>
      <td>NCS/TCIP/OVT/08/2024/1181</td>
      <td>₦533,333.00</td>
      <td>HYUNDAI  SANTA FE 2004</td>
      <td>Cont23456</td>
      <td>Used_Items_In_Container</td>
      <td>Container_Like</td>
      <td>None</td>
      <td>Petrol_Vehicle</td>
    </tr>
    <tr>
      <th>1204</th>
      <td>1204</td>
      <td>Vehicle</td>
      <td>NCS/TCIP/OVT/08/2024/1182</td>
      <td>₦520,000.00</td>
      <td>TOYOTA CAMRY 1996</td>
      <td>Cont23456</td>
      <td>Used_Items_In_Container</td>
      <td>Container_Like</td>
      <td>None</td>
      <td>Petrol_Vehicle</td>
    </tr>
  </tbody>
</table>
<p>1205 rows × 10 columns</p>
</div>




```python
# Dropped the unnamed column 
auction_results = auction_results.drop(['Unnamed: 0'], axis=1)
auction_results
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Bidding_Item</th>
      <th>Reference_Number</th>
      <th>Bid_Winning_Price</th>
      <th>Bidding_Item_Title</th>
      <th>Bid_Item_Identification_Number</th>
      <th>Condition</th>
      <th>Transmission_Type</th>
      <th>Mileage</th>
      <th>Fuel_Type</th>
    </tr>
    <tr>
      <th>Unnamed: 0</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Vehicle</td>
      <td>NCS/PTML/OVT/01/24/1</td>
      <td>₦892,000.00</td>
      <td>TOYOTA CAMRY HYBRID LE 4DR SEDAN 2006</td>
      <td>Cont23456</td>
      <td>Used_Items_In_Container</td>
      <td>Container_Like</td>
      <td>None</td>
      <td>Petrol_Vehicle</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Vehicle</td>
      <td>NCS/PTML/OVT/01/24/2</td>
      <td>₦500,000.00</td>
      <td>ACURA TL 2004</td>
      <td>Cont23456</td>
      <td>Used_Items_In_Container</td>
      <td>Container_Like</td>
      <td>None</td>
      <td>Petrol_Vehicle</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Vehicle</td>
      <td>NCS/PTML/OVT/01/24/3</td>
      <td>₦420,000.00</td>
      <td>HONDA ACCORD EX 1.5T 4DR SEDAN 2004</td>
      <td>Cont23456</td>
      <td>Used_Items_In_Container</td>
      <td>Container_Like</td>
      <td>None</td>
      <td>Petrol_Vehicle</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Vehicle</td>
      <td>NCS/PTML/OVT/01/24/4</td>
      <td>₦800,000.00</td>
      <td>TOYOTA COROLLA L 4DR SEDAN 2007</td>
      <td>Cont23456</td>
      <td>Used_Items_In_Container</td>
      <td>Container_Like</td>
      <td>None</td>
      <td>Petrol_Vehicle</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Vehicle</td>
      <td>NCS/PTML/OVT/01/24/5</td>
      <td>₦715,000.00</td>
      <td>PEUGEOT 307 2008</td>
      <td>Cont23456</td>
      <td>Used_Items_In_Container</td>
      <td>Container_Like</td>
      <td>None</td>
      <td>Petrol_Vehicle</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>1200</th>
      <td>Vehicle</td>
      <td>NCS/TCIP/OVT/08/2024/1178</td>
      <td>₦648,000.00</td>
      <td>FORD  FREESTAR 2004</td>
      <td>Cont23456</td>
      <td>Used_Items_In_Container</td>
      <td>Container_Like</td>
      <td>None</td>
      <td>Petrol_Vehicle</td>
    </tr>
    <tr>
      <th>1201</th>
      <td>Vehicle</td>
      <td>NCS/TCIP/OVT/08/2024/1179</td>
      <td>₦1,200,000.00</td>
      <td>TOYOTA  HIGHLANDER 2012</td>
      <td>Cont23456</td>
      <td>Used_Items_In_Container</td>
      <td>Container_Like</td>
      <td>None</td>
      <td>Petrol_Vehicle</td>
    </tr>
    <tr>
      <th>1202</th>
      <td>Vehicle</td>
      <td>NCS/TCIP/OVT/08/2024/1180</td>
      <td>₦1,626,898.00</td>
      <td>HONDA  CROSSTOUR 2014</td>
      <td>Cont23456</td>
      <td>Used_Items_In_Container</td>
      <td>Container_Like</td>
      <td>None</td>
      <td>Petrol_Vehicle</td>
    </tr>
    <tr>
      <th>1203</th>
      <td>Vehicle</td>
      <td>NCS/TCIP/OVT/08/2024/1181</td>
      <td>₦533,333.00</td>
      <td>HYUNDAI  SANTA FE 2004</td>
      <td>Cont23456</td>
      <td>Used_Items_In_Container</td>
      <td>Container_Like</td>
      <td>None</td>
      <td>Petrol_Vehicle</td>
    </tr>
    <tr>
      <th>1204</th>
      <td>Vehicle</td>
      <td>NCS/TCIP/OVT/08/2024/1182</td>
      <td>₦520,000.00</td>
      <td>TOYOTA CAMRY 1996</td>
      <td>Cont23456</td>
      <td>Used_Items_In_Container</td>
      <td>Container_Like</td>
      <td>None</td>
      <td>Petrol_Vehicle</td>
    </tr>
  </tbody>
</table>
<p>1205 rows × 9 columns</p>
</div>




```python
# reset the entire index
auction_results.reset_index(drop=True, inplace=True)
auction_results
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Bidding_Item</th>
      <th>Reference_Number</th>
      <th>Bid_Winning_Price</th>
      <th>Bidding_Item_Title</th>
      <th>Bid_Item_Identification_Number</th>
      <th>Condition</th>
      <th>Transmission_Type</th>
      <th>Mileage</th>
      <th>Fuel_Type</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Vehicle</td>
      <td>NCS/PTML/OVT/01/24/1</td>
      <td>₦892,000.00</td>
      <td>TOYOTA CAMRY HYBRID LE 4DR SEDAN 2006</td>
      <td>Cont23456</td>
      <td>Used_Items_In_Container</td>
      <td>Container_Like</td>
      <td>None</td>
      <td>Petrol_Vehicle</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Vehicle</td>
      <td>NCS/PTML/OVT/01/24/2</td>
      <td>₦500,000.00</td>
      <td>ACURA TL 2004</td>
      <td>Cont23456</td>
      <td>Used_Items_In_Container</td>
      <td>Container_Like</td>
      <td>None</td>
      <td>Petrol_Vehicle</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Vehicle</td>
      <td>NCS/PTML/OVT/01/24/3</td>
      <td>₦420,000.00</td>
      <td>HONDA ACCORD EX 1.5T 4DR SEDAN 2004</td>
      <td>Cont23456</td>
      <td>Used_Items_In_Container</td>
      <td>Container_Like</td>
      <td>None</td>
      <td>Petrol_Vehicle</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Vehicle</td>
      <td>NCS/PTML/OVT/01/24/4</td>
      <td>₦800,000.00</td>
      <td>TOYOTA COROLLA L 4DR SEDAN 2007</td>
      <td>Cont23456</td>
      <td>Used_Items_In_Container</td>
      <td>Container_Like</td>
      <td>None</td>
      <td>Petrol_Vehicle</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Vehicle</td>
      <td>NCS/PTML/OVT/01/24/5</td>
      <td>₦715,000.00</td>
      <td>PEUGEOT 307 2008</td>
      <td>Cont23456</td>
      <td>Used_Items_In_Container</td>
      <td>Container_Like</td>
      <td>None</td>
      <td>Petrol_Vehicle</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>1200</th>
      <td>Vehicle</td>
      <td>NCS/TCIP/OVT/08/2024/1178</td>
      <td>₦648,000.00</td>
      <td>FORD  FREESTAR 2004</td>
      <td>Cont23456</td>
      <td>Used_Items_In_Container</td>
      <td>Container_Like</td>
      <td>None</td>
      <td>Petrol_Vehicle</td>
    </tr>
    <tr>
      <th>1201</th>
      <td>Vehicle</td>
      <td>NCS/TCIP/OVT/08/2024/1179</td>
      <td>₦1,200,000.00</td>
      <td>TOYOTA  HIGHLANDER 2012</td>
      <td>Cont23456</td>
      <td>Used_Items_In_Container</td>
      <td>Container_Like</td>
      <td>None</td>
      <td>Petrol_Vehicle</td>
    </tr>
    <tr>
      <th>1202</th>
      <td>Vehicle</td>
      <td>NCS/TCIP/OVT/08/2024/1180</td>
      <td>₦1,626,898.00</td>
      <td>HONDA  CROSSTOUR 2014</td>
      <td>Cont23456</td>
      <td>Used_Items_In_Container</td>
      <td>Container_Like</td>
      <td>None</td>
      <td>Petrol_Vehicle</td>
    </tr>
    <tr>
      <th>1203</th>
      <td>Vehicle</td>
      <td>NCS/TCIP/OVT/08/2024/1181</td>
      <td>₦533,333.00</td>
      <td>HYUNDAI  SANTA FE 2004</td>
      <td>Cont23456</td>
      <td>Used_Items_In_Container</td>
      <td>Container_Like</td>
      <td>None</td>
      <td>Petrol_Vehicle</td>
    </tr>
    <tr>
      <th>1204</th>
      <td>Vehicle</td>
      <td>NCS/TCIP/OVT/08/2024/1182</td>
      <td>₦520,000.00</td>
      <td>TOYOTA CAMRY 1996</td>
      <td>Cont23456</td>
      <td>Used_Items_In_Container</td>
      <td>Container_Like</td>
      <td>None</td>
      <td>Petrol_Vehicle</td>
    </tr>
  </tbody>
</table>
<p>1205 rows × 9 columns</p>
</div>




```python
# Changing the data types of the neccesary columns 
auction_results.dtypes
```




    Bidding_Item                      object
    Reference_Number                  object
    Bid_Winning_Price                 object
    Bidding_Item_Title                object
    Bid_Item_Identification_Number    object
    Condition                         object
    Transmission_Type                 object
    Mileage                           object
    Fuel_Type                         object
    dtype: object




```python
# Was having issues changing the data type of the Bid winning 
#price therefore i had to replace the naira signs and commas to empty spaces
auction_results['Bid_Winning_Price'] = auction_results['Bid_Winning_Price'].replace({'₦': '', ',': ''},
                                       regex=True).astype(float)

auction_results

```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Bidding_Item</th>
      <th>Reference_Number</th>
      <th>Bid_Winning_Price</th>
      <th>Bidding_Item_Title</th>
      <th>Bid_Item_Identification_Number</th>
      <th>Condition</th>
      <th>Transmission_Type</th>
      <th>Mileage</th>
      <th>Fuel_Type</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Vehicle</td>
      <td>NCS/PTML/OVT/01/24/1</td>
      <td>892000.0</td>
      <td>TOYOTA CAMRY HYBRID LE 4DR SEDAN 2006</td>
      <td>Cont23456</td>
      <td>Used_Items_In_Container</td>
      <td>Container_Like</td>
      <td>None</td>
      <td>Petrol_Vehicle</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Vehicle</td>
      <td>NCS/PTML/OVT/01/24/2</td>
      <td>500000.0</td>
      <td>ACURA TL 2004</td>
      <td>Cont23456</td>
      <td>Used_Items_In_Container</td>
      <td>Container_Like</td>
      <td>None</td>
      <td>Petrol_Vehicle</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Vehicle</td>
      <td>NCS/PTML/OVT/01/24/3</td>
      <td>420000.0</td>
      <td>HONDA ACCORD EX 1.5T 4DR SEDAN 2004</td>
      <td>Cont23456</td>
      <td>Used_Items_In_Container</td>
      <td>Container_Like</td>
      <td>None</td>
      <td>Petrol_Vehicle</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Vehicle</td>
      <td>NCS/PTML/OVT/01/24/4</td>
      <td>800000.0</td>
      <td>TOYOTA COROLLA L 4DR SEDAN 2007</td>
      <td>Cont23456</td>
      <td>Used_Items_In_Container</td>
      <td>Container_Like</td>
      <td>None</td>
      <td>Petrol_Vehicle</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Vehicle</td>
      <td>NCS/PTML/OVT/01/24/5</td>
      <td>715000.0</td>
      <td>PEUGEOT 307 2008</td>
      <td>Cont23456</td>
      <td>Used_Items_In_Container</td>
      <td>Container_Like</td>
      <td>None</td>
      <td>Petrol_Vehicle</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>1200</th>
      <td>Vehicle</td>
      <td>NCS/TCIP/OVT/08/2024/1178</td>
      <td>648000.0</td>
      <td>FORD  FREESTAR 2004</td>
      <td>Cont23456</td>
      <td>Used_Items_In_Container</td>
      <td>Container_Like</td>
      <td>None</td>
      <td>Petrol_Vehicle</td>
    </tr>
    <tr>
      <th>1201</th>
      <td>Vehicle</td>
      <td>NCS/TCIP/OVT/08/2024/1179</td>
      <td>1200000.0</td>
      <td>TOYOTA  HIGHLANDER 2012</td>
      <td>Cont23456</td>
      <td>Used_Items_In_Container</td>
      <td>Container_Like</td>
      <td>None</td>
      <td>Petrol_Vehicle</td>
    </tr>
    <tr>
      <th>1202</th>
      <td>Vehicle</td>
      <td>NCS/TCIP/OVT/08/2024/1180</td>
      <td>1626898.0</td>
      <td>HONDA  CROSSTOUR 2014</td>
      <td>Cont23456</td>
      <td>Used_Items_In_Container</td>
      <td>Container_Like</td>
      <td>None</td>
      <td>Petrol_Vehicle</td>
    </tr>
    <tr>
      <th>1203</th>
      <td>Vehicle</td>
      <td>NCS/TCIP/OVT/08/2024/1181</td>
      <td>533333.0</td>
      <td>HYUNDAI  SANTA FE 2004</td>
      <td>Cont23456</td>
      <td>Used_Items_In_Container</td>
      <td>Container_Like</td>
      <td>None</td>
      <td>Petrol_Vehicle</td>
    </tr>
    <tr>
      <th>1204</th>
      <td>Vehicle</td>
      <td>NCS/TCIP/OVT/08/2024/1182</td>
      <td>520000.0</td>
      <td>TOYOTA CAMRY 1996</td>
      <td>Cont23456</td>
      <td>Used_Items_In_Container</td>
      <td>Container_Like</td>
      <td>None</td>
      <td>Petrol_Vehicle</td>
    </tr>
  </tbody>
</table>
<p>1205 rows × 9 columns</p>
</div>




```python
# changed the datatype of this column to a float
auction_results.dtypes['Bid_Winning_Price']
```




    dtype('float64')




```python
auction_results.dtypes
```




    Bidding_Item                       object
    Reference_Number                   object
    Bid_Winning_Price                 float64
    Bidding_Item_Title                 object
    Bid_Item_Identification_Number     object
    Condition                          object
    Transmission_Type                  object
    Mileage                            object
    Fuel_Type                          object
    dtype: object




```python
auction_results
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Bidding_Item</th>
      <th>Reference_Number</th>
      <th>Bid_Winning_Price</th>
      <th>Bidding_Item_Title</th>
      <th>Bid_Item_Identification_Number</th>
      <th>Condition</th>
      <th>Transmission_Type</th>
      <th>Mileage</th>
      <th>Fuel_Type</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Vehicle</td>
      <td>NCS/PTML/OVT/01/24/1</td>
      <td>892000.0</td>
      <td>TOYOTA CAMRY HYBRID LE 4DR SEDAN 2006</td>
      <td>Cont23456</td>
      <td>Used_Items_In_Container</td>
      <td>Container_Like</td>
      <td>None</td>
      <td>Petrol_Vehicle</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Vehicle</td>
      <td>NCS/PTML/OVT/01/24/2</td>
      <td>500000.0</td>
      <td>ACURA TL 2004</td>
      <td>Cont23456</td>
      <td>Used_Items_In_Container</td>
      <td>Container_Like</td>
      <td>None</td>
      <td>Petrol_Vehicle</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Vehicle</td>
      <td>NCS/PTML/OVT/01/24/3</td>
      <td>420000.0</td>
      <td>HONDA ACCORD EX 1.5T 4DR SEDAN 2004</td>
      <td>Cont23456</td>
      <td>Used_Items_In_Container</td>
      <td>Container_Like</td>
      <td>None</td>
      <td>Petrol_Vehicle</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Vehicle</td>
      <td>NCS/PTML/OVT/01/24/4</td>
      <td>800000.0</td>
      <td>TOYOTA COROLLA L 4DR SEDAN 2007</td>
      <td>Cont23456</td>
      <td>Used_Items_In_Container</td>
      <td>Container_Like</td>
      <td>None</td>
      <td>Petrol_Vehicle</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Vehicle</td>
      <td>NCS/PTML/OVT/01/24/5</td>
      <td>715000.0</td>
      <td>PEUGEOT 307 2008</td>
      <td>Cont23456</td>
      <td>Used_Items_In_Container</td>
      <td>Container_Like</td>
      <td>None</td>
      <td>Petrol_Vehicle</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>1200</th>
      <td>Vehicle</td>
      <td>NCS/TCIP/OVT/08/2024/1178</td>
      <td>648000.0</td>
      <td>FORD  FREESTAR 2004</td>
      <td>Cont23456</td>
      <td>Used_Items_In_Container</td>
      <td>Container_Like</td>
      <td>None</td>
      <td>Petrol_Vehicle</td>
    </tr>
    <tr>
      <th>1201</th>
      <td>Vehicle</td>
      <td>NCS/TCIP/OVT/08/2024/1179</td>
      <td>1200000.0</td>
      <td>TOYOTA  HIGHLANDER 2012</td>
      <td>Cont23456</td>
      <td>Used_Items_In_Container</td>
      <td>Container_Like</td>
      <td>None</td>
      <td>Petrol_Vehicle</td>
    </tr>
    <tr>
      <th>1202</th>
      <td>Vehicle</td>
      <td>NCS/TCIP/OVT/08/2024/1180</td>
      <td>1626898.0</td>
      <td>HONDA  CROSSTOUR 2014</td>
      <td>Cont23456</td>
      <td>Used_Items_In_Container</td>
      <td>Container_Like</td>
      <td>None</td>
      <td>Petrol_Vehicle</td>
    </tr>
    <tr>
      <th>1203</th>
      <td>Vehicle</td>
      <td>NCS/TCIP/OVT/08/2024/1181</td>
      <td>533333.0</td>
      <td>HYUNDAI  SANTA FE 2004</td>
      <td>Cont23456</td>
      <td>Used_Items_In_Container</td>
      <td>Container_Like</td>
      <td>None</td>
      <td>Petrol_Vehicle</td>
    </tr>
    <tr>
      <th>1204</th>
      <td>Vehicle</td>
      <td>NCS/TCIP/OVT/08/2024/1182</td>
      <td>520000.0</td>
      <td>TOYOTA CAMRY 1996</td>
      <td>Cont23456</td>
      <td>Used_Items_In_Container</td>
      <td>Container_Like</td>
      <td>None</td>
      <td>Petrol_Vehicle</td>
    </tr>
  </tbody>
</table>
<p>1205 rows × 9 columns</p>
</div>




```python
# Bringing everything together
import pandas as pd
import numpy as np

# import the scraped table from a csv file
auction_results = pd.read_csv('C:\\Users\\HP\\Desktop\\Phyton for everybody with Dr Chuck\\Scrapped_Data\\
                                Unclean_Raw_Scrapped_bidding_data.csv')

# split the URL column using a delimiter to get the bidding item  
auction_results['URL'] = auction_results['URL'].apply(lambda a: a.split('=')[-1])

# Give the vaues in the Condition column with VIN column values somes meaning
auction_results['Condition'].replace({'Nigeria': 'Cont23456'}, inplace=True)

# Give the vaues in the VIN column with Condition column values somes meaning
auction_results['VIN'].replace({'Used': 'Used_Vehicle', 'Accidented': 'Used_Vehicle', '0KG': 'Used_Items_In_Container', 
                                  '1,020KG': 'Used_items_In_Container', '19,958KG': 'Used_Items_In_Container'}, inplace=True)



# Give the values in the Transmission Column some meaning
auction_results['Transmission'].replace({'AUTOMATIC': 'Automatic_Vehicle', 'Automatic': 'Automatic_Vehicle', 
                                         'Manual': 'Manual_Vehicle'}, inplace=True)

auction_results['Transmission'] = auction_results['Transmission'].fillna('Container_Like').replace('NaN', 'Container_Like')


# Give the values in the Mileage Column some meaning
auction_results['Mileage'].replace({'0.00KM': 'Kilometers'}, inplace=True)
auction_results['Mileage'] = auction_results['Mileage'].fillna('None').replace('NaN', 'None')



# Give the values in the Fuel Type Column some meaning
auction_results['Fuel Type'].replace({ 'Petrol': 'Petrol_Vehicle', 'PETROL': 'Petrol_Vehicle', 'NIL': 'Petrol_Vehicle'}, 
                                     inplace=True)


# Used indexing starting from 0 replacing values at specified rows
auction_results.at[14, 'Fuel Type']= 'Diesel_Vehicle'
auction_results.at[18, 'Fuel Type']= 'Diesel_Vehicle'
auction_results.at[20, 'Fuel Type']= 'Diesel_Vehicle'
auction_results.at[46, 'Fuel Type']= 'Diesel_Vehicle'
auction_results.at[55, 'Fuel Type']= 'Diesel_Vehicle'
auction_results.at[71, 'Fuel Type']= 'Diesel_Vehicle'


# replace NaN with None
auction_results['Fuel Type'] = auction_results['Fuel Type'].fillna('None').replace('NaN', 'None')

auction_results['Fuel Type'] = auction_results['Fuel Type'].replace("('Diesel_Vehicle',)", 'Diesel_Vehicle')

# Change Column names
auction_results.rename(columns={'URL':'Bidding_Item', 'Reference Number':'Reference_Number', 
                            'Price':'Bid_Winning_Price', 'Car Title':'Bidding_Item_Title',
                            'Condition':'Bid_Item_Identification_Number', 'VIN':'Condition',
                            'Transmission':'Transmission_Type', 'Fuel Type':'Fuel_Type'}, inplace=True)

# set the unnamed column as an index
auction_results.index = auction_results['Unnamed: 0']

# drop the unnamed column
auction_results = auction_results.drop(['Unnamed: 0'], axis=1)

# drop the unnamed column as an index and create a new index
auction_results.reset_index(drop=True, inplace=True)

# Was having issues changing the data type of the Bid winning 
# price therefore i had to replace the naira signs and commas to empty spaces
auction_results['Bid_Winning_Price'] = auction_results['Bid_Winning_Price'].replace({'₦': '', ',': ''},
                                       regex=True).astype(float)



auction_results
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Bidding_Item</th>
      <th>Reference_Number</th>
      <th>Bid_Winning_Price</th>
      <th>Bidding_Item_Title</th>
      <th>Bid_Item_Identification_Number</th>
      <th>Condition</th>
      <th>Transmission_Type</th>
      <th>Mileage</th>
      <th>Fuel_Type</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Vehicle</td>
      <td>NCS/PTML/OVT/01/24/1</td>
      <td>892000.0</td>
      <td>TOYOTA CAMRY HYBRID LE 4DR SEDAN 2006</td>
      <td>4T1BE32K86U111063</td>
      <td>Used_Vehicle</td>
      <td>Automatic_Vehicle</td>
      <td>Kilometers</td>
      <td>Petrol_Vehicle</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Vehicle</td>
      <td>NCS/PTML/OVT/01/24/2</td>
      <td>500000.0</td>
      <td>ACURA TL 2004</td>
      <td>19UUA66214A013030</td>
      <td>Used_Vehicle</td>
      <td>Automatic_Vehicle</td>
      <td>Kilometers</td>
      <td>Petrol_Vehicle</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Vehicle</td>
      <td>NCS/PTML/OVT/01/24/3</td>
      <td>420000.0</td>
      <td>HONDA ACCORD EX 1.5T 4DR SEDAN 2004</td>
      <td>1HGCM66554A098192</td>
      <td>Used_Vehicle</td>
      <td>Automatic_Vehicle</td>
      <td>Kilometers</td>
      <td>Petrol_Vehicle</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Vehicle</td>
      <td>NCS/PTML/OVT/01/24/4</td>
      <td>800000.0</td>
      <td>TOYOTA COROLLA L 4DR SEDAN 2007</td>
      <td>2T1BR32E27C777272</td>
      <td>Used_Vehicle</td>
      <td>Automatic_Vehicle</td>
      <td>Kilometers</td>
      <td>Petrol_Vehicle</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Vehicle</td>
      <td>NCS/PTML/OVT/01/24/5</td>
      <td>715000.0</td>
      <td>PEUGEOT 307 2008</td>
      <td>VF33CNFUL84568049</td>
      <td>Used_Vehicle</td>
      <td>Automatic_Vehicle</td>
      <td>Kilometers</td>
      <td>Petrol_Vehicle</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>1200</th>
      <td>Vehicle</td>
      <td>NCS/TCIP/OVT/08/2024/1178</td>
      <td>648000.0</td>
      <td>FORD  FREESTAR 2004</td>
      <td>B29970</td>
      <td>Used_Vehicle</td>
      <td>Automatic_Vehicle</td>
      <td>Kilometers</td>
      <td>Petrol_Vehicle</td>
    </tr>
    <tr>
      <th>1201</th>
      <td>Vehicle</td>
      <td>NCS/TCIP/OVT/08/2024/1179</td>
      <td>1200000.0</td>
      <td>TOYOTA  HIGHLANDER 2012</td>
      <td>5TDYK3EH5CS070513</td>
      <td>Used_Vehicle</td>
      <td>Automatic_Vehicle</td>
      <td>Kilometers</td>
      <td>Petrol_Vehicle</td>
    </tr>
    <tr>
      <th>1202</th>
      <td>Vehicle</td>
      <td>NCS/TCIP/OVT/08/2024/1180</td>
      <td>1626898.0</td>
      <td>HONDA  CROSSTOUR 2014</td>
      <td>000016</td>
      <td>Used_Vehicle</td>
      <td>Automatic_Vehicle</td>
      <td>Kilometers</td>
      <td>Petrol_Vehicle</td>
    </tr>
    <tr>
      <th>1203</th>
      <td>Vehicle</td>
      <td>NCS/TCIP/OVT/08/2024/1181</td>
      <td>533333.0</td>
      <td>HYUNDAI  SANTA FE 2004</td>
      <td>U572121</td>
      <td>Used_Vehicle</td>
      <td>Automatic_Vehicle</td>
      <td>Kilometers</td>
      <td>Petrol_Vehicle</td>
    </tr>
    <tr>
      <th>1204</th>
      <td>Vehicle</td>
      <td>NCS/TCIP/OVT/08/2024/1182</td>
      <td>520000.0</td>
      <td>TOYOTA CAMRY 1996</td>
      <td>824426</td>
      <td>Used_Vehicle</td>
      <td>Automatic_Vehicle</td>
      <td>Kilometers</td>
      <td>Petrol_Vehicle</td>
    </tr>
  </tbody>
</table>
<p>1205 rows × 9 columns</p>
</div>




```python
# saving my table to a csv file in my desktop
auction_results.to_csv(
    'C:\\Users\\HP\\Desktop\\Phyton for everybody with Dr Chuck\\Scrapped_Data\\Cleaned_Scrapped_bidding_data.csv', index=False)
print('Table saved')
```

    Table saved
    


```python

```

# VISUALIZING WITH MATPLOTLIB


```python
# import the neccessary libraries
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
```


```python
# import the scraped table from a csv file in my laptop
auction_visual = pd.read_csv('C:\\Users\\HP\\Desktop\\Phyton for everybody with Dr Chuck\\Scrapped_Data\\Cleaned_Scrapped_bidding_data.csv')
print(auction_visual)
```

         Bidding_Item           Reference_Number  Bid_Winning_Price  \
    0         Vehicle       NCS/PTML/OVT/01/24/1           892000.0   
    1         Vehicle       NCS/PTML/OVT/01/24/2           500000.0   
    2         Vehicle       NCS/PTML/OVT/01/24/3           420000.0   
    3         Vehicle       NCS/PTML/OVT/01/24/4           800000.0   
    4         Vehicle       NCS/PTML/OVT/01/24/5           715000.0   
    ...           ...                        ...                ...   
    1200      Vehicle  NCS/TCIP/OVT/08/2024/1178           648000.0   
    1201      Vehicle  NCS/TCIP/OVT/08/2024/1179          1200000.0   
    1202      Vehicle  NCS/TCIP/OVT/08/2024/1180          1626898.0   
    1203      Vehicle  NCS/TCIP/OVT/08/2024/1181           533333.0   
    1204      Vehicle  NCS/TCIP/OVT/08/2024/1182           520000.0   
    
                             Bidding_Item_Title Bid_Item_Identification_Number  \
    0     TOYOTA CAMRY HYBRID LE 4DR SEDAN 2006              4T1BE32K86U111063   
    1                             ACURA TL 2004              19UUA66214A013030   
    2       HONDA ACCORD EX 1.5T 4DR SEDAN 2004              1HGCM66554A098192   
    3           TOYOTA COROLLA L 4DR SEDAN 2007              2T1BR32E27C777272   
    4                          PEUGEOT 307 2008              VF33CNFUL84568049   
    ...                                     ...                            ...   
    1200                    FORD  FREESTAR 2004                         B29970   
    1201                TOYOTA  HIGHLANDER 2012              5TDYK3EH5CS070513   
    1202                  HONDA  CROSSTOUR 2014                         000016   
    1203                 HYUNDAI  SANTA FE 2004                        U572121   
    1204                      TOYOTA CAMRY 1996                         824426   
    
             Condition  Transmission_Type     Mileage       Fuel_Type  
    0     Used_Vehicle  Automatic_Vehicle  Kilometers  Petrol_Vehicle  
    1     Used_Vehicle  Automatic_Vehicle  Kilometers  Petrol_Vehicle  
    2     Used_Vehicle  Automatic_Vehicle  Kilometers  Petrol_Vehicle  
    3     Used_Vehicle  Automatic_Vehicle  Kilometers  Petrol_Vehicle  
    4     Used_Vehicle  Automatic_Vehicle  Kilometers  Petrol_Vehicle  
    ...            ...                ...         ...             ...  
    1200  Used_Vehicle  Automatic_Vehicle  Kilometers  Petrol_Vehicle  
    1201  Used_Vehicle  Automatic_Vehicle  Kilometers  Petrol_Vehicle  
    1202  Used_Vehicle  Automatic_Vehicle  Kilometers  Petrol_Vehicle  
    1203  Used_Vehicle  Automatic_Vehicle  Kilometers  Petrol_Vehicle  
    1204  Used_Vehicle  Automatic_Vehicle  Kilometers  Petrol_Vehicle  
    
    [1205 rows x 9 columns]
    


```python
# import the neccessary libraries
from IPython.display import display
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

# import the scraped table from a csv file and put it in a table
auction_visual = pd.read_csv('C:\\Users\\HP\\Desktop\\Phyton for everybody with Dr Chuck\\Scrapped_Data\\Cleaned_Scrapped_bidding_data.csv')
display(auction_visual)

```


<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Bidding_Item</th>
      <th>Reference_Number</th>
      <th>Bid_Winning_Price</th>
      <th>Bidding_Item_Title</th>
      <th>Bid_Item_Identification_Number</th>
      <th>Condition</th>
      <th>Transmission_Type</th>
      <th>Mileage</th>
      <th>Fuel_Type</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Vehicle</td>
      <td>NCS/PTML/OVT/01/24/1</td>
      <td>892000.0</td>
      <td>TOYOTA CAMRY HYBRID LE 4DR SEDAN 2006</td>
      <td>4T1BE32K86U111063</td>
      <td>Used_Vehicle</td>
      <td>Automatic_Vehicle</td>
      <td>Kilometers</td>
      <td>Petrol_Vehicle</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Vehicle</td>
      <td>NCS/PTML/OVT/01/24/2</td>
      <td>500000.0</td>
      <td>ACURA TL 2004</td>
      <td>19UUA66214A013030</td>
      <td>Used_Vehicle</td>
      <td>Automatic_Vehicle</td>
      <td>Kilometers</td>
      <td>Petrol_Vehicle</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Vehicle</td>
      <td>NCS/PTML/OVT/01/24/3</td>
      <td>420000.0</td>
      <td>HONDA ACCORD EX 1.5T 4DR SEDAN 2004</td>
      <td>1HGCM66554A098192</td>
      <td>Used_Vehicle</td>
      <td>Automatic_Vehicle</td>
      <td>Kilometers</td>
      <td>Petrol_Vehicle</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Vehicle</td>
      <td>NCS/PTML/OVT/01/24/4</td>
      <td>800000.0</td>
      <td>TOYOTA COROLLA L 4DR SEDAN 2007</td>
      <td>2T1BR32E27C777272</td>
      <td>Used_Vehicle</td>
      <td>Automatic_Vehicle</td>
      <td>Kilometers</td>
      <td>Petrol_Vehicle</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Vehicle</td>
      <td>NCS/PTML/OVT/01/24/5</td>
      <td>715000.0</td>
      <td>PEUGEOT 307 2008</td>
      <td>VF33CNFUL84568049</td>
      <td>Used_Vehicle</td>
      <td>Automatic_Vehicle</td>
      <td>Kilometers</td>
      <td>Petrol_Vehicle</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>1200</th>
      <td>Vehicle</td>
      <td>NCS/TCIP/OVT/08/2024/1178</td>
      <td>648000.0</td>
      <td>FORD  FREESTAR 2004</td>
      <td>B29970</td>
      <td>Used_Vehicle</td>
      <td>Automatic_Vehicle</td>
      <td>Kilometers</td>
      <td>Petrol_Vehicle</td>
    </tr>
    <tr>
      <th>1201</th>
      <td>Vehicle</td>
      <td>NCS/TCIP/OVT/08/2024/1179</td>
      <td>1200000.0</td>
      <td>TOYOTA  HIGHLANDER 2012</td>
      <td>5TDYK3EH5CS070513</td>
      <td>Used_Vehicle</td>
      <td>Automatic_Vehicle</td>
      <td>Kilometers</td>
      <td>Petrol_Vehicle</td>
    </tr>
    <tr>
      <th>1202</th>
      <td>Vehicle</td>
      <td>NCS/TCIP/OVT/08/2024/1180</td>
      <td>1626898.0</td>
      <td>HONDA  CROSSTOUR 2014</td>
      <td>000016</td>
      <td>Used_Vehicle</td>
      <td>Automatic_Vehicle</td>
      <td>Kilometers</td>
      <td>Petrol_Vehicle</td>
    </tr>
    <tr>
      <th>1203</th>
      <td>Vehicle</td>
      <td>NCS/TCIP/OVT/08/2024/1181</td>
      <td>533333.0</td>
      <td>HYUNDAI  SANTA FE 2004</td>
      <td>U572121</td>
      <td>Used_Vehicle</td>
      <td>Automatic_Vehicle</td>
      <td>Kilometers</td>
      <td>Petrol_Vehicle</td>
    </tr>
    <tr>
      <th>1204</th>
      <td>Vehicle</td>
      <td>NCS/TCIP/OVT/08/2024/1182</td>
      <td>520000.0</td>
      <td>TOYOTA CAMRY 1996</td>
      <td>824426</td>
      <td>Used_Vehicle</td>
      <td>Automatic_Vehicle</td>
      <td>Kilometers</td>
      <td>Petrol_Vehicle</td>
    </tr>
  </tbody>
</table>
<p>1205 rows × 9 columns</p>
</div>



```python
# the total amount made in naira by the nigerian customs since the start of the auction 
auction_visual['Bid_Winning_Price'].sum()
```




    1615464232.42




```python
# Highest amount paid for a bid is 29 million naira
auction_visual['Bid_Winning_Price'].max()
```




    29000000.0




```python
# Highest amount paid for an item
auction_visual.groupby('Bidding_Item')['Bid_Winning_Price'].max()
```




    Bidding_Item
    Container    29000000.0
    Vehicle      11500000.0
    Name: Bid_Winning_Price, dtype: float64




```python
# Lowest amount paid for a bid is 3 hundred thousand naira
auction_visual['Bid_Winning_Price'].min()
```




    300000.0




```python
# Lowest amount paid for an item
auction_visual.groupby('Bidding_Item')['Bid_Winning_Price'].min()
```




    Bidding_Item
    Container    1500001.0
    Vehicle       300000.0
    Name: Bid_Winning_Price, dtype: float64




```python
# IT SHOWS THAT THE NIGERIAN CUSTOMS MADE OVER THREE HUNDRED MILLION NAIRA FROM THE AUCTION OF CONTAINERS
# AND OVER A BILLION IN THE AUCTION OF USED VEHICLES

# Showing the price comparision by bidding items
# grouping all the items in the bidding item column by the bid winning price 
grouped_items = auction_visual.groupby('Bidding_Item')['Bid_Winning_Price'].sum().reset_index()

# Plotting the bar chart by specifying it size
plt.figure(figsize=(8, 6))

# Plotting the bars with different colors and labels
bars = plt.bar(grouped_items['Bidding_Item'], grouped_items['Bid_Winning_Price'])
bars[0].set_color('red')
font1 = {'family':'serif','color':'blue','size':25}


# Add labels on top of each bar showing the sum of prices of each bidding item
for bar in bars:
    yval = bar.get_height()
    plt.text(bar.get_x() + bar.get_width()/2, yval, int(yval), ha='center', va='bottom')

# Add labels and title to the different axis
plt.xlabel('Bidding_Item')
plt.ylabel('Bid_Winning_Price')
plt.title('Price Comparison by Bidding Item', fontdict = font1)

# Show the plot
plt.tight_layout()
plt.show()
```


    
![png](output_76_0.png)
    



```python
# Show the unique counts of each bidding item
auction_visual['Bidding_Item'].value_counts()
```




    Bidding_Item
    Vehicle      1124
    Container      81
    Name: count, dtype: int64




```python
# THE TOTAL VEHICLE AUCTIONED IS AT 1,124 AND CONTAINERS IS AT 81

# Get the count of each bidding item
bidding_counts = auction_visual['Bidding_Item'].value_counts().reset_index()
bidding_counts.columns = ['Bidding_Item', 'Count'] # count the different items in the bidding item column

# Plotting the bar chart by specifying it size
plt.figure(figsize=(8, 6))

# plot a bar chart
bars = plt.bar(bidding_counts['Bidding_Item'], bidding_counts['Count'])
bars[1].set_color('red')
font1 = {'family':'serif','color':'blue','size':25}

# Add labels on top of each bar showing the count of each bidding item
for bar in bars:
    yval = bar.get_height()
    plt.text(bar.get_x() + bar.get_width()/2, yval, int(yval), ha='center', va='bottom')

#  Add labels and title to the different axis
plt.xlabel('Bidding_Item')
plt.ylabel('Bid_Winning_Price')
plt.title('Bidding Items by Counts', fontdict = font1)

# Show the plot
plt.tight_layout()
plt.show()
```


    
![png](output_78_0.png)
    



```python
# Show the unique counts of each transmission type
auction_visual['Transmission_Type'].value_counts()
```




    Transmission_Type
    Automatic_Vehicle    1111
    Container_Like         81
    Manual_Vehicle         13
    Name: count, dtype: int64




```python
# WE CAN SEE THAT MOST OF THE VEHICLES IMPORTED INTO NIGERIA ARE AUTOMATIC VEHICLES


# Use value_counts to get the counts of each category
transmission_counts = auction_visual['Transmission_Type'].value_counts()

# Function to format the autopct to show the count instead of a percentage and to get the unique count (absolute value)
# of each item in the Transmission type column in a pie chart
def absolute_value(val):
    t = int(val / 100 * transmission_counts.sum())
    return f'{t}'

# give your slices colors
colors = ['skyblue', 'red', 'green']
# format the headers
font1 = {'family':'serif','color':'blue','size':25}

# Create the pie chart
plt.pie(transmission_counts, labels = transmission_counts.index, autopct=absolute_value, colors=colors)

# title
plt.title('Transmission',  fontdict = font1)

# Show the plot
plt.show()
```


    
![png](output_80_0.png)
    



```python
# Show the unique counts of each Reference Number
auction_visual['Reference_Number'].value_counts()
```




    Reference_Number
    NCS/01TC/OVT/02/2024/522     2
    NCS/PTML/OVT/04/2024/856     2
    NCS/PTML/OVT/02/2024/363     2
    NCS/PTML/OVT/01/2024/258     2
    NCS/01TC/OVT/02/2024/442     2
                                ..
    NCS/PTML/OVT/01/2024/290     1
    NCS/PTML/OVT/01/2024/287     1
    NCS/PTML/OVT/01/2024/286     1
    NCS/PTML/OVT/01/2024/284     1
    NCS/TCIP/OVT/08/2024/1182    1
    Name: count, Length: 1198, dtype: int64




```python
# FROM THE REFERENCE NUMBER COLUMN COUNT, I CAN SEE THAT THE BID IS ACTUALLY A TOUGH AND TRUE ONE
# ONLY SEVEN REFERENCE NUMBERS HAVE ACTUALLY WON A BID TWICE
# WITH THE REMAINING REFERENCE NUMBERS HAVING JUST WON JUST ONCE.
# DUE TO ANNOYMITY, REFERENCE NUMBERS ARE UNIQUE NUMBERS ISSUED TO EACH WINNING BIDDER THE FIRST TIME
# IF I WIN A BID FOR EXAMPLE, THEN I WILL BE GIVEN A REFERENCE NUMBER.
# FOR EXAMPLE THE VERY FIRST WINNER OF THE AUCTION WAS GIVEN A REFERENCE NUMBER OF NCS/PTML/OVT/01/24/1
# ONLY WINNERS HAVE REFERENCE NUMBERS

# Get the count of each bidding item
reference_counts = auction_visual['Reference_Number'].value_counts()


# Create a bar plot
plt.figure(figsize=(10,6))
plt.table(cellText = reference_counts.values.reshape(-1,1), rowLabels = reference_counts.index, 
          colLabels = ['reference_counts'], loc ='center')

plt.axis('off')

# Show the plot with the table
plt.show()
```


    
![png](output_82_0.png)
    



```python
reference_counts = auction_visual.groupby(['Bidding_Item'])['Reference_Number'].value_counts()


# Create a bar plot
plt.figure(figsize=(10,6))
plt.table(cellText = reference_counts.values.reshape(-1,1), rowLabels = reference_counts.index, 
          colLabels = ['reference_counts'], loc ='center')

plt.axis('off')

# Show the plot with the table
plt.show()
```


    
![png](output_83_0.png)
    



```python
# Show the unique counts of each Reference Number
# Lesson learned, Do not name a column value 'None' because it is
# A python function and python cannot identify it
# But it would not affect the values count of your column
# but it wont also show it.

# CHANGE THE NONE TO NON_VEHICLE IN THE FUEL TYPE COLUMN TO SEE THE NON_VEHICLE COUNT
# BEFORE RUNNING THE CODE BELOW TO MAKE A CORRECTION

auction_visual['Fuel_Type'].value_counts()
```




    Fuel_Type
    Petrol_Vehicle    1118
    Diesel_Vehicle       6
    Name: count, dtype: int64




```python
# WE CAN SEE THAT MOST OF THE VEHICLES THAT ARE BEING WON ARE VEHICLES THAT USE PETROL
# RATHER THAN DIESEL WHICH CAN BE ATTRIBUTED TO THE CHEAPER COST OF FUEL PURCHASE FOR THE FORMER
# DIESEL IS VERY EXPENSIVE IN NIGERIA

# Do not name a column value 'None' when using python.

# Use value_counts to get the counts of each category
Vehicle_Type_Counts = auction_visual['Fuel_Type'].value_counts()

# Function to format the autopct to show the count instead of a percentage and to get the unique count (absolute value)
# of each item in the Transmission type column in a pie chart
def absolute_value(val):
    v = int(val / 100 * Vehicle_Type_Counts.sum())
    return f'{v}'

# give your slices colors
colors = ['skyblue', 'green']
# format the headers
font1 = {'family':'serif','color':'blue','size':25}

# Create the pie chart
plt.pie(Vehicle_Type_Counts, labels = Vehicle_Type_Counts.index, autopct=absolute_value, colors=colors)

# title
plt.title('Petrol Vs Diesel Vehicles',  fontdict = font1)

# Show the plot
plt.show()
```


    
![png](output_85_0.png)
    


# AFTER MAKIING THE NECESSARY CHANGES IN THE FUEL TYPE COLUMN RUN THE CODES BELOW


```python
# Make the neccesarry changes in the fuel type column before running

# auction_visual['Fuel_Type'].value_counts()
```


```python
# MAKE THE CHANGES IN THE FUEL TYPE (NONE TO NON_VEHICLE) COLUMN BEFORE RUNNING THIS CODE


# WE CAN SEE THAT MOST OF THE VEHICLES THAT ARE BEING WON ARE VEHICLES THAT USE PETROL
# RATHER THAN DIESEL WHICH CAN BE ATTRIBUTED TO THE CHEAPER COST OF FUEL PURCHASE FOR THE FORMER
# DIESEL IS VERY EXPENSIVE IN NIGERIA

# Do not name a column value 'None' when using python.

# Use value_counts to get the counts of each category
# Vehicle_Type_Counts = auction_visual['Fuel_Type'].value_counts()

# Function to format the autopct to show the count instead of a percentage and to get the unique count (absolute value)
# of each item in the Transmission type column in a pie chart
# def absolute_value(val):
 #   v = int(val / 100 * Vehicle_Type_Counts.sum())
 #   return f'{v}'

# give your slices colors
#colors = ['skyblue', 'red', 'green']
# format the headers
# font1 = {'family':'serif','color':'blue','size':25}

# Create the pie chart
# plt.pie(Vehicle_Type_Counts, labels = Vehicle_Type_Counts.index, autopct=absolute_value, colors=colors)

# title
# plt.title('Petrol Vs Diesel Vehicles',  fontdict = font1)

# Show the plot
# plt.show()
```
